import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.io.File;
import java.io.InputStream;
import java.lang.invoke.MethodHandles;
import java.util.Properties;
import com.pexto.monedero.apidto.utils.PGP;
import org.junit.jupiter.api.Test;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

class LibraryDTOUnitTest {

    ClassLoader classLoader;
    PathMatchingResourcePatternResolver resolver;
    Properties properties;

    public LibraryDTOUnitTest() throws Exception {
        properties = new Properties();
        classLoader = MethodHandles.lookup().getClass().getClassLoader();
        resolver = new PathMatchingResourcePatternResolver(classLoader);
        Resource[] res = resolver.getResources("classpath:pgp.properties");
        if (res.length > 0) {
            InputStream inputStream = res[0].getInputStream();
            properties.load(inputStream);
            if (properties.getProperty("profile.active") == null) {
                properties.setProperty("profile.active", "dev");
            }
        }
    }

    @Test
    void testEncryptAndDecryptText() throws Exception {
        Boolean isProd = properties.getProperty("profile.active").equals("prod");

        PGP pgp = new PGP(true);
        String textToEncrypt = "TESTING DECRYPT PGP BY CODE";

        String textEncrypted = pgp.encrypt(textToEncrypt, isProd ? "4E0A8150" : "094B3185");

        System.out.println("ENCRYPTED TEXT: ".concat(textEncrypted));

        String mensajeDecrypt =
                pgp.decrypt(textEncrypted, isProd ? "C0m3rc10@Sup3rg1r0s" : "PextoComercio@2019");

        System.out.println("DECRYPTED TEXT: ".concat(mensajeDecrypt));

        assertEquals(textToEncrypt, mensajeDecrypt);
    }
    
    @Test
    void testDecryptFile() throws Exception {
        Boolean isProd = properties.getProperty("profile.active").equals("prod");
        PGP pgp = new PGP(true);
        String fileDecrypt = System.getProperty("user.dir")
                .concat(File.separator.concat("src").concat(File.separator).concat("test")
                        .concat(File.separator).concat("resources").concat(File.separator))
                .concat("test_decrypt"+(isProd ? "_prod" : "_dev")+".txt.gpg");
        File mensajeDecrypt = pgp.decryptFromFile(new File(fileDecrypt), "test_decrypt.txt.gpg",
                isProd ? "Em1s0r@C0mf3n4lc0" : "ComfenalcoPublica");
        assertNotNull(mensajeDecrypt);
        mensajeDecrypt.delete();
    }
}
