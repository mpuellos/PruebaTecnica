package co.cobre.billetera.dto.errors;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

class ErrorResponseTest {

  @Test
  void test() throws JsonMappingException, JsonProcessingException {
    String jsonObjectToString = "{\"help\":\"\",\"errorCode\":\"503\",\"location\":\"co.cobre.util.otp.adapter.persistence.OtpPersistenceAdapter\",\"message\":\"No se ha encontrado el objeto\",\"moreInfo\":[{\"location\":\"Details\",\"message\":\"[]\"}]}";
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    objectMapper.setVisibility(PropertyAccessor.ALL, Visibility.NONE);
    objectMapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
    objectMapper.setVisibility(PropertyAccessor.CREATOR, Visibility.ANY);
    
    ErrorResponse errorResponse = objectMapper.readValue(jsonObjectToString, ErrorResponse.class);

    assertEquals("503", errorResponse.getErrorCode());
    assertEquals("No se ha encontrado el objeto", errorResponse.getMessage());
  }

}
