package co.cobre.billetera.dto.movil.v3.registro;

import java.io.Serializable;

import com.pexto.monedero.apidto.integrador.comfenalco.ValidacionClienteResponse;
import com.pexto.monedero.apidto.integrador.comfenalco.ValidacionClienteResponseV;

public class RegistroEstadoClienteResponse<T> implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	private String error_code;
	private String estado_registro;
	private ValidacionClienteResponse cliente_emisor;
	private T data;

	public String getError_code() {
		return error_code;
	}

	public void setError_code(String error_code) {
		this.error_code = error_code;
	}

	public ValidacionClienteResponse getCliente_emisor() {
		return cliente_emisor;
	}

	public void setCliente_emisor(ValidacionClienteResponse cliente_emisor) {
		this.cliente_emisor = cliente_emisor;
	}
	
	public void setCliente_emisor(ValidacionClienteResponseV cliente_emisor) {
		this.cliente_emisor = new ValidacionClienteResponse();
		
		this.cliente_emisor.setNombres(cliente_emisor.getNombres());
		this.cliente_emisor.setApellidos(cliente_emisor.getApellidos());
		this.cliente_emisor.setFechaNacimiento(cliente_emisor.getFechaNacimiento());
		this.cliente_emisor.setCelular(cliente_emisor.getCelular());
		this.cliente_emisor.setTelefono(cliente_emisor.getTelefono());
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	public String getEstado_registro() {
		return estado_registro;
	}

	public void setEstado_registro(String estado_registro) {
		this.estado_registro = estado_registro;
	}

}
