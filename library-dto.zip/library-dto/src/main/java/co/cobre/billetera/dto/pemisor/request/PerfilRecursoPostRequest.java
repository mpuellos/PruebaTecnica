package co.cobre.billetera.dto.pemisor.request;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class PerfilRecursoPostRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long idPerfil;
	private Long idRecurso;

	public Long getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(Long idPerfil) {
		this.idPerfil = idPerfil;
	}

	public Long getIdRecurso() {
		return idRecurso;
	}

	public void setIdRecurso(Long idRecurso) {
		this.idRecurso = idRecurso;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.idPerfil == null) || (String.valueOf(this.idPerfil).isEmpty())) {
			throw new Exception("El campo id perfil esta vacio o errado!");
		}

		if ((this.idRecurso == null) || (String.valueOf(this.idRecurso).isEmpty())) {
			throw new Exception("El campo id recurso esta vacio o errado!");
		}

		return valid;
	}

}