package co.cobre.billetera.dto.movil.v3.transactional;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CommerceConfigurationResponse {

  Long id;
  String uuid;
  String name;
  String status;
  String otpGenerationField;
  String types;
  String terminalUuid;
  Long terminalId;
  Double tariff;
  Integer transactionQuantityLimit;
  Integer transactionQuatityLimitFee;
  Integer monthlyCustomerTransactionsQuantity;
  String configuration;
  Double upperLimit;
  Double lowerLimit;
  
}
