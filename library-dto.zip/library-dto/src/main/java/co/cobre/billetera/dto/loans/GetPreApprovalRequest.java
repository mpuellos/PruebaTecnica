package co.cobre.billetera.dto.loans;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetPreApprovalRequest {
    private String clientDocument;
    private String documentType;
}
