package co.cobre.billetera.dto.movil.v3.otp;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class OneTimePasswordResponse {
  
  String uuid;
  String workplaceBankCode;
  String validityTime;
  String contextCode;
  String otpHash;
  String otpValue;
  
}
