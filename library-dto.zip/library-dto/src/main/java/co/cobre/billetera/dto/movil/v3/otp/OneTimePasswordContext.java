package co.cobre.billetera.dto.movil.v3.otp;

import static java.time.temporal.ChronoUnit.MINUTES;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public enum OneTimePasswordContext {

  //@formatter:off
  ONBOARDING("ON", MINUTES.toString(), 60),
  SIGNATURE("SG", MINUTES.toString(), 60),
  PURCHASE("CO", MINUTES.toString(), 60),
  WITHDRAWAL("RE", MINUTES.toString(), 60),
  QR_PURCHASE("CQ", MINUTES.toString(), 60),
  QR_WITHDRAWAL("RQ", MINUTES.toString(), 60),
  TRANSFER_OUT("TO", MINUTES.toString(), 60),
  LOGIN("LG", MINUTES.toString(), 10);
  //@formatter:on

  private static final Map<String, OneTimePasswordContext> BY_CODE = new HashMap<>();

  static {
    for (OneTimePasswordContext e : values()) {
      BY_CODE.put(e.code, e);
    }
  }

  private final String code;

  private final String validityType;

  private final Integer validityAmount;

  private OneTimePasswordContext(String code, String validityType, Integer validityAmount) {
    this.code = code;
    this.validityType = validityType;
    this.validityAmount = validityAmount;
  }

  public String getCode() {
    return code;
  }

  public String getValidityType() {
    return validityType;
  }

  public Integer getValidityAmount() {
    return validityAmount;
  }

  public static OneTimePasswordContext valueOfCode(String label) {
    return BY_CODE.get(label);
  }

  public static String valuesAsString() {
    return BY_CODE.keySet().stream().map(key -> key + "=" + BY_CODE.get(key))
        .collect(Collectors.joining(", ", "{", "}"));
  }
}
