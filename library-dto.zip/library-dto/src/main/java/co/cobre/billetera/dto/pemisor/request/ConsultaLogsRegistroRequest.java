package co.cobre.billetera.dto.pemisor.request;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class ConsultaLogsRegistroRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String tipoDocumento;
	private String numeroDocumento;

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.tipoDocumento == null) || (this.tipoDocumento.isEmpty())
				|| (this.tipoDocumento.trim().length() != 1)) {
			throw new Exception("El campo tipo de documento esta vacio o errado!");
		}

		if ((this.numeroDocumento == null) || (this.numeroDocumento.isEmpty())
				|| (this.numeroDocumento.trim().length() > 15)
				|| (!Parametros.validateOnlyDigits(this.numeroDocumento))) {
			throw new Exception("El campo numero de documento esta vacio o errado!");
		}

		return valid;
	}

}