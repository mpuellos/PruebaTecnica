package co.cobre.billetera.dto.lib.logging;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggableAspect {
  
  @Before("@annotation(co.cobre.billetera.dto.lib.logging.Loggable)")
  public void beforeMethod(JoinPoint joinPoint) {
    Logger logger = LoggerFactory.getLogger(joinPoint.getTarget().getClass().getName());
    if (logger.isInfoEnabled())
        logger.info(String.format(LogConstants.INIT_LOG_PATTERN,
            joinPoint.getSignature().getDeclaringType().getSimpleName(), joinPoint.getSignature().getName()));
  }

  @After("@annotation(co.cobre.billetera.dto.lib.logging.Loggable)")
  public void afterMethod(JoinPoint joinPoint) {
    Logger logger = LoggerFactory.getLogger(joinPoint.getTarget().getClass().getName());
    if (logger.isInfoEnabled())
        logger.info(String.format(LogConstants.FINISH_LOG_PATTERN,
            joinPoint.getSignature().getDeclaringType().getSimpleName(), joinPoint.getSignature().getName()));
  }
}
