package co.cobre.billetera.dto.movil.v3.event;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import co.cobre.billetera.dto.errors.ErrorCode;
import co.cobre.billetera.dto.errors.builder.ServiceExceptionBuilder;
import co.cobre.billetera.dto.errors.builder.ValidationExceptionBuilder;
import software.amazon.awssdk.services.sns.model.MessageAttributeValue;
import software.amazon.awssdk.services.sns.model.PublishRequest;

public class SnsRequestBuilder {

  MessageEvent messageEvent;
  String topicArn;
  Map<String, MessageAttributeValue> attributes = new HashMap<>();

  public static SnsRequestBuilder builder() {
    return new SnsRequestBuilder();
  }

  public SnsRequestBuilder messageAttribute(String key, String value, String dataType) {
    attributes.put(key, buildAttribute(value, dataType));
    return this;
  }

  public SnsRequestBuilder messageEvent(String topicArn, MessageEvent messageEvent) {
    this.topicArn = topicArn;
    this.messageEvent = messageEvent;
    return this;
  }

  public PublishRequest build() {

    if (messageEvent == null) {
      throw ValidationExceptionBuilder.builder().exceptionCode(ErrorCode.VALIDATION_ERROR.getId())
          .message("MessageEvent cannot be null")
          .location(SnsRequestBuilder.class.getCanonicalName()).build();
    }

    if (StringUtils.isBlank(topicArn)) {
      throw ValidationExceptionBuilder.builder().exceptionCode(ErrorCode.VALIDATION_ERROR.getId())
          .message("Sns Topic cannot be null").location(SnsRequestBuilder.class.getCanonicalName())
          .build();
    }

    ObjectMapper objetMapper = new ObjectMapper();
    String jsonStr = StringUtils.EMPTY;
    try {
      jsonStr = objetMapper.writeValueAsString(messageEvent);
    }

    catch (IOException e) {
      throw ServiceExceptionBuilder.builder().exceptionCode(ErrorCode.UNEXPECTED_ERROR.getId())
          .message("There was an error parsing the Event to Json")
          .location(SnsRequestBuilder.class.getCanonicalName()).cause(e).build();
    }

    return PublishRequest.builder().topicArn(topicArn).message(jsonStr)
        .messageDeduplicationId(DigestUtils.sha1Hex(jsonStr))
        .messageGroupId(messageEvent.getMessageGroupId()).messageAttributes(attributes).build();

  }

  private MessageAttributeValue buildAttribute(String value, String dataType) {
    return MessageAttributeValue.builder().dataType(dataType).stringValue(value).build();
  }
}
