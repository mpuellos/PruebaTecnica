package co.cobre.billetera.dto.errors;

public class NotFoundException extends BaseException {

  private static final long serialVersionUID = 3325180189474835276L;

  public NotFoundException(Throwable cause, String message, String exceptionCode, String location,
      String moreInfo) {
    super(cause, message, exceptionCode, location, moreInfo);
  }
}
