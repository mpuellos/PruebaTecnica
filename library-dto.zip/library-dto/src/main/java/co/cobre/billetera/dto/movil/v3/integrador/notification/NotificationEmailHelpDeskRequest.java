package co.cobre.billetera.dto.movil.v3.integrador.notification;

import java.io.Serializable;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class NotificationEmailHelpDeskRequest implements Serializable, IRequestValidator {
	private static final long serialVersionUID = 1L;

	/*
	 * Datos requeridos para identificar al emisor
	 */

	private Long idEmisor;
	private String tokenEmmisor;
	private String codigoEmisor;

	/*
	 * Datos no requeridos por el servicio
	 */

	private String tipoDocumento;
	private String numeroDocumento;

	/*
	 * Datos requeridos por el servicio
	 */

	private String nombreContacto;
	private String numeroContacto;
	private String correoContacto;
	private String mensajeSolicitud;

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getTokenEmmisor() {
		return tokenEmmisor;
	}

	public void setTokenEmmisor(String tokenEmmisor) {
		this.tokenEmmisor = tokenEmmisor;
	}

	public String getCodigoEmisor() {
		return codigoEmisor;
	}

	public void setCodigoEmisor(String codigoEmisor) {
		this.codigoEmisor = codigoEmisor;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombreContacto() {
		return nombreContacto;
	}

	public void setNombreContacto(String nombreContacto) {
		this.nombreContacto = nombreContacto;
	}

	public String getNumeroContacto() {
		return numeroContacto;
	}

	public void setNumeroContacto(String numeroContacto) {
		this.numeroContacto = numeroContacto;
	}

	public String getCorreoContacto() {
		return correoContacto;
	}

	public void setCorreoContacto(String correoContacto) {
		this.correoContacto = correoContacto;
	}

	public String getMensajeSolicitud() {
		return mensajeSolicitud;
	}

	public void setMensajeSolicitud(String mensajeSolicitud) {
		this.mensajeSolicitud = mensajeSolicitud;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		/*
		 * Validacion de campos requeridos para el emisor
		 */
        if(this.idEmisor == null){
            this.idEmisor = 1L;
        }

		if (!Parametros.validateOnlyDigits(String.valueOf(this.idEmisor))) {
			throw new Exception("El campo id emisor esta vacio o errado!");
		}

		/*
		 * Validacion de campos requeridos
		 */

		if ((this.nombreContacto == null) || (this.nombreContacto.isEmpty())) {
			throw new Exception("El campo nombre de contacto esta vacio o errado!");
		}

		if ((this.numeroContacto == null) || (this.numeroContacto.isEmpty())
				|| (this.numeroContacto.trim().length() != 10)
				|| (!Parametros.validateOnlyDigits(this.numeroContacto))) {
			throw new Exception("El campo numero de celular de contacto esta vacio o errado!");
		}

		if ((this.correoContacto == null) || (this.correoContacto.isEmpty())) {
			throw new Exception("El campo correo electronico esta vacio o errado!");
		}
		
		try {
			InternetAddress emailAddr = new InternetAddress(this.correoContacto);
			emailAddr.validate();
		} catch (AddressException ex) {
			throw new Exception("El campo correo electronico no es valido!");
		}
		
		if ((this.mensajeSolicitud == null) || (this.mensajeSolicitud.isEmpty())) {
			throw new Exception("El campo mensaje esta vacio o errado!");
		}

		/*
		 * Validacion de campos no requeridos
		 */

		if (this.tipoDocumento != null) {
			if (this.tipoDocumento.isEmpty() || (this.tipoDocumento.trim().length() != 1)
					|| (!Parametros.validateOnlyDigits(this.tipoDocumento))) {
				throw new Exception("El campo tipo de documento esta vacio o errado!");
			}
		}

		if (this.numeroDocumento != null) {
			if (this.numeroDocumento.isEmpty() || (this.numeroDocumento.trim().length() > 15)
					|| (!Parametros.validateOnlyDigits(this.numeroDocumento))) {
				throw new Exception("El campo numero de documento esta vacio o errado!");
			}
		}

		return valid;
	}

}