package co.cobre.billetera.dto.movil.v3.registro.v3;

import java.io.Serializable;
import com.pexto.monedero.apidto.negocio.ClienteDTO;
import com.pexto.monedero.apidto.negocio.CuentaDTO;
import co.cobre.billetera.dto.movil.v3.registro.NovedadRegistroDTO;

public class InternalClienteInscritoResponse implements Serializable {

	/**
	 *
	 */
	private static final long serialVersionUID = -3600018828058690742L;

	private String estado;
	private String mensaje;
	private ValidacionAfiliadoResponse clienteEmisor;
	private NovedadRegistroDTO novedadRegistro;
	private ClienteDTO cliente;
	private CuentaDTO cuenta;
	private Long clientId;
	private String name;
	private String surname;
	private String documentId;
	private String documentType;
	private String processDate;
	private String registerDate;
	private String email;
	private String phone;
	private String direction;
	private String workplace;

	public ValidacionAfiliadoResponse getClienteEmisor() {
		return clienteEmisor;
	}

	public void setClienteEmisor(ValidacionAfiliadoResponse clienteEmisor) {
		this.clienteEmisor = clienteEmisor;
	}

	public NovedadRegistroDTO getNovedadRegistro() {
		return novedadRegistro;
	}

	public void setNovedadRegistro(NovedadRegistroDTO novedadRegistro) {
		this.novedadRegistro = novedadRegistro;
	}

	public ClienteDTO getCliente() {
		return cliente;
	}

	public void setCliente(ClienteDTO cliente) {
		this.cliente = cliente;
	}

	public CuentaDTO getCuenta() {
		return cuenta;
	}

	public void setCuenta(CuentaDTO cuenta) {
		this.cuenta = cuenta;
	}

	public Long getClientId() {
		return clientId;
	}

	public void setClientId(Long clientId) {
		this.clientId = clientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getProcessDate() {
		return processDate;
	}

	public void setProcessDate(String processDate) {
		this.processDate = processDate;
	}

	public String getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public InternalClienteInscritoResponse() {
		this.estado = "99";
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getDirection() {
		return direction;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public String getWorkplace() {
		return workplace;
	}

	public void setWorkplace(String workplace) {
		this.workplace = workplace;
	}

}
