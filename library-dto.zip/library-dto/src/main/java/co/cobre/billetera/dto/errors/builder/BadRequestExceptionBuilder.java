package co.cobre.billetera.dto.errors.builder;

import co.cobre.billetera.dto.errors.BadRequestException;

public class BadRequestExceptionBuilder extends ExceptionBuilder<BadRequestException> {

    @Override
    public BadRequestException internalBuild() {
        return new BadRequestException(getCause(), getMessage(), getErrorCode(), getLocation(),
                getMoreInfo());
    }

    public static ExceptionBuilder<BadRequestException> builder() {
        return new BadRequestExceptionBuilder();
    }
}
