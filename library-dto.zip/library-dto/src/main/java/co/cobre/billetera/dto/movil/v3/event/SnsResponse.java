package co.cobre.billetera.dto.movil.v3.event;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class SnsResponse {

  Integer statusCode;
  String message;
  String publishedMessageId;
}
