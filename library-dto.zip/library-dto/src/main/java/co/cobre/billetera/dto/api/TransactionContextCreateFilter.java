package co.cobre.billetera.dto.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

@Component
public class TransactionContextCreateFilter implements HandlerInterceptor {

  /**
   * Executed before actual handler is executed
   **/
  @Override
  public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response,
      final Object handler) throws Exception {
    request.setAttribute(ApiCommonConstants.TRANSACTION_CONTEXT_KEY,
        TransactionContext.builder()
            .deviceUUID(request.getHeader(ApiCommonConstants.DEVICE_ID_HEADER_KEY))
            .tenantId(ApiCommonConstants.TENANT_ID_HEADER_KEY)
            .authorization(request.getHeader(ApiCommonConstants.AUTHORIZATION))
            .workplaceBankCode(request.getHeader(ApiCommonConstants.WORKPLACE_BANK_CODE_HEADER_KEY))
            .transactionId(request.getHeader(ApiCommonConstants.TRANSACTION_ID)).build());

    return true;
  }



}
