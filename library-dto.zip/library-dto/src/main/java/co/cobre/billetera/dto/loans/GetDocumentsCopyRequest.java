package co.cobre.billetera.dto.loans;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetDocumentsCopyRequest {
    private String preApprovalId;
    private boolean prefilled;
}
