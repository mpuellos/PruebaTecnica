package co.cobre.billetera.dto.errors;

public enum ErrorCode {

    VALIDATION_ERROR("501", "Validation Errors Found"),
    UNEXPECTED_CLIENT_ERROR("502", "Rest Client Error"),
    RESOURCE_NOT_FOUND_ERROR("503", "Resource Not Found"),
    UNEXPECTED_ERROR("504", "Unexpected Server Error Found"),
    AUTHORIZATION_ERROR("046", "The authorization header is empty or invalid");


    private final String id;
    private final String description;


    private ErrorCode(String id, String description) {
        this.id = id;
        this.description = description;
    }

    public static ErrorCode findById(String id) {
        for (ErrorCode value : values()) {
            if (value.getId().equals(id)) {
                return value;
            }
        }
        return null;
    }

    public String getId() {
        return id;
    }


    public String getDescription() {
        return description;
    }

}
