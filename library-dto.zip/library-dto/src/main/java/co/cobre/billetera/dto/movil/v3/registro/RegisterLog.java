package co.cobre.billetera.dto.movil.v3.registro;

public class RegisterLog {
    // SCREEN 1-1-3
    public static final LogData EVENT_77_P = new LogData("77", "Celular No Coincide");
    public static final LogData EVENT_77_E = new LogData("77", "Email No Coincide");
    public static final LogData EVENT_77_B = new LogData("77", "Celular y Email No Coincide");
    public static final LogData EVENT_81 = new LogData("81", "Bypass de estado I para activar pin");
    public static final LogData EVENT_82 = new LogData("82", "Cambio de estado I a C para reexpedicion");
    public static final LogData EVENT_83 = new LogData("83", "Consultando Cliente Existente");
    public static final LogData EVENT_84 = new LogData("84", "Creando Novedad Registro con estado C");

    
    // SCREEN 1-1-6
    public static final LogData EVENT_85 = new LogData("85", "Intentó subir documento frontal en estado diferente de C,P,Q,R");
    public static final LogData EVENT_86 = new LogData("86", "Intentó enviar el documento frontal nulo");
    public static final LogData EVENT_87 = new LogData("87", "Procesando documento frontal");
    public static final LogData EVENT_88 = new LogData("88", "Validando documento frontal como fotocopia");
    public static final LogData EVENT_89 = new LogData("89", "Documento frontal detectado como fotocopia!");
    public static final LogData EVENT_90 = new LogData("90", "Error validando documento frontal como fotocopia");
    public static final LogData EVENT_91 = new LogData("91", "Subiendo documento frontal S3");
    public static final LogData EVENT_92 = new LogData("92", "Error subiendo documento frontal a S3");

    
    // SCREEN 1-1-8
    public static final LogData EVENT_93 = new LogData("93", "Intentó subir documento trasero en estado diferente de C,P,Q,R");
    public static final LogData EVENT_94 = new LogData("94", "Intentó enviar el documento trasero nulo");
    public static final LogData EVENT_95 = new LogData("95", "Procesando documento trasero");
    public static final LogData EVENT_96 = new LogData("96", "Validando documento trasero como fotocopia");
    public static final LogData EVENT_97 = new LogData("97", "Documento trasero detectado como fotocopia!");
    public static final LogData EVENT_98 = new LogData("98", "Error validando documento trasero como fotocopia");
    public static final LogData EVENT_99 = new LogData("99", "Subiendo documento trasero S3");
    public static final LogData EVENT_100 = new LogData("100", "Error subiendo documento trasero a S3");
    
    
    // SCREEN 1-1-10-SEND
    public static final LogData EVENT_101 = new LogData("101", "Validando nombres y apellidos en cualquier orden");
    public static final LogData EVENT_102 = new LogData("102", "Validando nombre y apellidos especificos");
    public static final LogData EVENT_103 = new LogData("103", "No se pudo validar nombres y apellidos en cualquier orden");
    public static final LogData EVENT_104 = new LogData("104", "No se pudo validar nombres y apellidos especificos");
    public static final LogData EVENT_105 = new LogData("105", "Intento de envio de otp y se ha cambiado el estado a P");
    public static final LogData EVENT_106 = new LogData("106", "No se pudo enviar el otp");
    public static final LogData EVENT_124 = new LogData("124", "Intento de envio de otp y sin cambiar estado");
    
    
    // SCREEN 1-1-10-RESEND
    public static final LogData EVENT_107 = new LogData("107", "Intento de reenviar el otp");
    public static final LogData EVENT_108 = new LogData("108", "No se pudo reenviar el otp");
    
    
    // SCREEN 1-1-10-SENDED
    public static final LogData EVENT_109 = new LogData("109", "OTP no es valido");
    public static final LogData EVENT_110 = new LogData("110", "OTP vigencia expirada");
    public static final LogData EVENT_111 = new LogData("111", "OTP validado exitosamente");
    public static final LogData EVENT_125 = new LogData("125", "No se pudo activar la cuenta");
    
    
    // SCREEN 1-1-12
    public static final LogData EVENT_112 = new LogData("112", "Intentó subir selfie en estado diferente de C,P,Q,R");
    public static final LogData EVENT_113 = new LogData("113", "Intento enviar el selfie nulo");
    public static final LogData EVENT_114 = new LogData("114", "Procesando selfie");
    public static final LogData EVENT_115 = new LogData("115", "Subiendo selfie S3");
    public static final LogData EVENT_116 = new LogData("116", "Error subiendo selfie a S3");
    public static final LogData EVENT_117 = new LogData("117", "Confirmando solicitud de registro");
    public static final LogData EVENT_118 = new LogData("118", "Aprobando solicitud de registro");
    public static final LogData EVENT_119 = new LogData("119", "Inscribiendo solicitud de registro");
    public static final LogData EVENT_120 = new LogData("120", "Error inscribiendo solicitud de registro");
    public static final LogData EVENT_121 = new LogData("121", "Realizando cambio de via de pago");
    public static final LogData EVENT_122 = new LogData("122", "Cambio de via de pago exitosa");
    public static final LogData EVENT_123 = new LogData("123", "Error cambiando la via de pago");

    // NEW SYSTEM OF REGISTER
    public static final LogData EVENT_126 = new LogData("126", "Creando registro desde utilitarios");
    public static final LogData EVENT_127 = new LogData("127", "Aprobación exitosa");
}
