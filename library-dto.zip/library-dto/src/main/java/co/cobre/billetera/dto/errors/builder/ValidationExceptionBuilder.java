package co.cobre.billetera.dto.errors.builder;

import co.cobre.billetera.dto.errors.ValidationException;

public class ValidationExceptionBuilder extends ExceptionBuilder<ValidationException> {

  @Override
  public ValidationException internalBuild() {
    return new ValidationException(getCause(), getMessage(), getErrorCode(), getLocation(), getMoreInfo());
  }

  public static ExceptionBuilder<ValidationException> builder() {
    return new ValidationExceptionBuilder();
  }
}
