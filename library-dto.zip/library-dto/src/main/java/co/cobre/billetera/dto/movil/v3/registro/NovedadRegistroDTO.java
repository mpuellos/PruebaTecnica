package co.cobre.billetera.dto.movil.v3.registro;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NovedadRegistroDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;

    private String tipoDocumento;

    private String numeroDocumento;

    private String nombre1;

    private String nombre2;

    private String apellido1;

    private String apellido2;

    private Date fechaNacimiento;

    private Date fechaExpedicion;

    private String correo;

    private String sexo;

    private String grupoSanguineo;

    private String numeroCelular;

    private String estado;

    private String estadoSolicitudRegistro;

    private String motivo;

    private String nroReferido;

    private String nroReferente;

    private String numeroOtp;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getNombre1() {
        return nombre1;
    }

    public void setNombre1(String nombre1) {
        this.nombre1 = nombre1;
    }

    public String getNombre2() {
        return nombre2;
    }

    public void setNombre2(String nombre2) {
        this.nombre2 = nombre2;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public Date getFechaExpedicion() {
        return fechaExpedicion;
    }

    public void setFechaExpedicion(Date fechaExpedicion) {
        this.fechaExpedicion = fechaExpedicion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getGrupoSanguineo() {
        return grupoSanguineo;
    }

    public void setGrupoSanguineo(String grupoSanguineo) {
        this.grupoSanguineo = grupoSanguineo;
    }

    public String getNumeroCelular() {
        return numeroCelular;
    }

    public void setNumeroCelular(String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getEstadoSolicitudRegistro() {
        return estadoSolicitudRegistro;
    }

    public void setEstadoSolicitudRegistro(String estadoSolicitudRegistro) {
        this.estadoSolicitudRegistro = estadoSolicitudRegistro;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getNroReferido() {
        return nroReferido;
    }

    public void setNroReferido(String nroReferido) {
        this.nroReferido = nroReferido;
    }

    public String getNroReferente() {
        return nroReferente;
    }

    public void setNroReferente(String nroReferente) {
        this.nroReferente = nroReferente;
    }

    public String getNumeroOtp() {
        return numeroOtp;
    }

    public void setNumeroOtp(String numeroOtp) {
        this.numeroOtp = numeroOtp;
    }
}