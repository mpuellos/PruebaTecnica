package co.cobre.billetera.dto.movil.v3.registro;

public class LogData {
    private String code;
    private String msg;
    
    public LogData(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getMsg() {
        return msg;
    }
    public void setMsg(String msg) {
        this.msg = msg;
    }
    public String[] data(){
        return new String[]{this.code, this.msg};
    }
}