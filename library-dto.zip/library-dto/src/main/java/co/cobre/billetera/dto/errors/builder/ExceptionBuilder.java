package co.cobre.billetera.dto.errors.builder;

import co.cobre.billetera.dto.errors.BaseException;

public abstract class ExceptionBuilder<T extends BaseException> {

  private String errorCode;

  private String message;

  private String location;

  private Throwable cause;

  private String moreInfo;

  public ExceptionBuilder<T> exceptionCode(String exceptionCode) {
    this.errorCode = exceptionCode;
    return this;
  }

  public ExceptionBuilder<T> message(String message) {
    this.message = message;
    return this;
  }

  public ExceptionBuilder<T> location(String location) {
    this.location = location;
    return this;
  }

  public ExceptionBuilder<T> cause(Throwable cause) {
    this.cause = cause;
    return this;
  }

  public ExceptionBuilder<T> moreInfo(String moreInfo) {
    this.moreInfo = moreInfo;
    return this;
  }

  public T build() {
    return internalBuild();
  }

  public abstract T internalBuild();

  public String getErrorCode() {
    return errorCode;
  }

  public String getMessage() {
    return message;
  }

  public String getLocation() {
    return location;
  }

  public Throwable getCause() {
    return cause;
  }

  public String getMoreInfo() {
    return moreInfo;
  }
}
