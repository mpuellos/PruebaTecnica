package co.cobre.billetera.dto.loans;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetPreApprovalResponse {
    private Long preApprovalAmount;
    private String preApprovalId;
    private LoansClientData preApprovalsClientData;
}
