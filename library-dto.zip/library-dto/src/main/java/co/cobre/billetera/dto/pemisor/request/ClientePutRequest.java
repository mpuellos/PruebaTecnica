package co.cobre.billetera.dto.pemisor.request;

import java.io.Serializable;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class ClientePutRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Datos requeridos
	private Long id;
	private String uuid;
	private String correo;
	private String fechaExpedicion;
	
	// Datos no requeridos
	private String numeroDocumento;
	private String nombres;
	private String apellidos;
	private String fechaNacimiento;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(String fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.id == null) || (String.valueOf(this.id).isEmpty())) {
			throw new Exception("El campo id esta vacio o errado!");
		}

		if ((this.uuid == null) || (this.uuid.isEmpty())) {
			throw new Exception("El campo uuid esta vacio o errado!");
		}
		
		if ((this.numeroDocumento == null) || (this.numeroDocumento.isEmpty())) {
			throw new Exception("El campo numero de documento esta vacio o errado!");
		}

		if ((this.fechaExpedicion == null) || (this.fechaExpedicion.isEmpty())
				|| (this.fechaExpedicion.length() != 10)) {
			throw new Exception("El campo fecha de expedicion esta vacio o errado!");
		}

		if ((this.correo == null) || (this.correo.isEmpty())) {
			throw new Exception("El campo correo electronico esta vacio o errado!");
		}

		try {
			InternetAddress emailAddr = new InternetAddress(this.correo);
			emailAddr.validate();
		} catch (AddressException ex) {
			throw new Exception("El campo correo electronico no es valido!");
		}

		return valid;
	}

}