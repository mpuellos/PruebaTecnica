package co.cobre.billetera.dto.entertainmentPurchases;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EntertainmentResponse {
	private  String workplaceBankAuthorizationNumber;
	private  String cobreAuthorizationNumber;
	private  String providerTxAuthorization;
	private  String authorizationDate;
	private  String authorizationAmount;
}
