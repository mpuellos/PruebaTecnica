package co.cobre.billetera.dto.loans;

public class AcceptLoanResponse {

}
