package co.cobre.billetera.dto.loans;

public enum DocumentTypeDto {
    PROMISSORY_NOTE, CONTRACT, INSTRUCTIONS, FGA
}
