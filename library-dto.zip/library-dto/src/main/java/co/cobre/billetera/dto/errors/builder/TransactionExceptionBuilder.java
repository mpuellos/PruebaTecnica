package co.cobre.billetera.dto.errors.builder;

import co.cobre.billetera.dto.errors.TransactionException;

public class TransactionExceptionBuilder extends ExceptionBuilder<TransactionException> {

  private Object transaction;

  public ExceptionBuilder<TransactionException> transaction(Object transaction) {
    this.transaction = transaction;
    return this;
  }

  @Override
  public TransactionException internalBuild() {
    return new TransactionException(getCause(), getMessage(), getErrorCode(), getLocation(),
        getMoreInfo(), transaction);
  }

  public static TransactionExceptionBuilder builder() {
    return new TransactionExceptionBuilder();
  }

}
