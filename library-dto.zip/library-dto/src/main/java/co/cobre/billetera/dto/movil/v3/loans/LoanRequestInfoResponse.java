package co.cobre.billetera.dto.movil.v3.loans;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LoanRequestInfoResponse {

  String loanRequestUUID;
  String loanRequestStatus;
  Integer loanRequestAmount;
  String loanRequestDate;
  Integer promissoryNoteNumber;
}
