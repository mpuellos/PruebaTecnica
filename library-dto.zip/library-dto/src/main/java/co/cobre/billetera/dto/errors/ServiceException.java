package co.cobre.billetera.dto.errors;

public class ServiceException extends BaseException {

  private static final long serialVersionUID = 7718828512143293558L;

  public ServiceException(Throwable cause, String message, String exceptionCode, String location,
      String moreInfo) {
    super(cause, message, exceptionCode, location, moreInfo);
  }

}
