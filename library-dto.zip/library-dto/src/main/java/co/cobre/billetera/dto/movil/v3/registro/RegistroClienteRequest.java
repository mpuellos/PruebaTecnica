package co.cobre.billetera.dto.movil.v3.registro;

import java.io.Serializable;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.pexto.monedero.apidto.exceptions.FieldException;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class RegistroClienteRequest implements Serializable, IRequestValidator {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * Nuevos atributos para la super APP, con esto podemos identificar el registro
	 * de que emisor corresponde
	 */
	private Long idEmisor;
	private String codigoEmisor;
	private String tokenEmisor;

	private Boolean terminosCondiciones;

	private String tipoDocumento;
	private String numeroDocumento;
	private String numeroCelular;
	private String correoElectronico;
	private String fechaNacimiento;
	private String fechaExpedicion;
	private String nombre1;
	private String nombre2;
	private String apellido1;
	private String apellido2;
	private String grupoSanguineoRH;
	private String sexo;
	private String codigoVerificacion1;
	private String codigoVeriricacion2;
	private String nroReferente;
	private String uuidDispositivo;
	private String appCodeVersion;

	private String scanType;

	// Datos del front pero en la vista de Confirmacion
	private String numeroOtp;

	// Este dato se asigna en la API-Movil
	private String ipOrigen;

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		if (this.idEmisor == null) {
			this.idEmisor = 1L;
		}

		if ((this.idEmisor == null) || (String.valueOf(this.idEmisor).isEmpty())) {
			throw new FieldException("El campo Id Emisor esta vacio!", "idEmisor");
		}

		if ((this.ipOrigen == null) || (this.ipOrigen.isEmpty())) {
			throw new FieldException("El campo Ip Origen esta vacio!", "ipOrigen");
		}

		if ((this.tipoDocumento == null) || (this.tipoDocumento.isEmpty())
				|| (this.tipoDocumento.trim().length() != 1)) {
			throw new FieldException("El campo tipo de documento esta vacio o errado!", "tipoDocumento");
		}

		if ((this.numeroDocumento == null) || (this.numeroDocumento.isEmpty())
				|| (this.numeroDocumento.trim().length() > 15)
				|| (!Parametros.validateOnlyDigits(this.numeroDocumento))) {
			throw new FieldException("El campo numero de documento esta vacio o errado!", "numeroDocumento");
		}

		if ((this.numeroCelular == null) || (this.numeroCelular.isEmpty()) || (this.numeroCelular.trim().length() != 10)
				|| (!Parametros.validateOnlyDigits(this.numeroCelular))) {
			throw new FieldException("El campo numero de celular esta vacio o errado!", "numeroCelular");
		}

		if ((this.correoElectronico == null) || (this.correoElectronico.isEmpty())) {
			throw new FieldException("El campo correo electronico esta vacio o errado!", "correoElectronico");
		}

		try {
			InternetAddress emailAddr = new InternetAddress(this.correoElectronico);
			emailAddr.validate();
		} catch (AddressException ex) {
			throw new FieldException("El campo correo electronico no es valido!", "correoElectronico");
		}

		if ((this.fechaNacimiento == null) || (this.fechaNacimiento.isEmpty()) || (this.fechaNacimiento.length() != 8)
				|| (!Parametros.validateOnlyDigits(this.fechaNacimiento))) {
			throw new FieldException("El campo fecha de nacimiento esta vacio o errado!", "fechaNacimiento");
		}

		if ((this.fechaExpedicion == null) || (this.fechaExpedicion.isEmpty()) || (this.fechaExpedicion.length() != 8)
				|| (!Parametros.validateOnlyDigits(this.fechaExpedicion))) {
			throw new FieldException("El campo fecha de expedicion esta vacio o errado!", "fechaExpedicion");
		}

		if ((this.nombre1 == null) || (this.nombre1.isEmpty())) {
			throw new FieldException("El campo nombre1 esta vacio o errado!", "nombre1");
		}

		if ((this.apellido1 == null) || (this.apellido1.isEmpty())) {
			throw new FieldException("El campo apellido1 esta vacio o errado!", "apellido1");
		}

		if ((this.grupoSanguineoRH != null) && (this.grupoSanguineoRH.length() > 10)) {
			throw new FieldException("El campo grupo sanguineo esta errado!", "grupoSanguineoRH");
		}

		if ((this.sexo != null) && (this.sexo.length() > 10)) {
			throw new FieldException("El campo sexo esta errado!", "sexo");
		}

		if ((this.uuidDispositivo == null) || (this.uuidDispositivo.isEmpty())) {
			throw new FieldException("El campo Uuid Dispositivo esta vacio o errado!", "uuidDispositivo");
		}

		if ((this.appCodeVersion == null) || (this.appCodeVersion.isEmpty())) {
			throw new FieldException("El campo App Code Version esta vacio o errado!", "appCodeVersion");
		}

		if ((this.numeroOtp != null) && (this.numeroOtp.length() != 6)
				&& (!Parametros.validateOnlyDigits(this.numeroOtp))) {
			throw new FieldException("El campo numero OTP esta errado!", "numeroOtp");
		}
        if(this.nroReferente != null){
            this.nroReferente = this.nroReferente.trim().replace("-", "").toUpperCase();
        }
		if (this.terminosCondiciones == null) {
			this.terminosCondiciones = true;
		}

		return valid;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getCodigoEmisor() {
		return codigoEmisor;
	}

	public void setCodigoEmisor(String codigoEmisor) {
		this.codigoEmisor = codigoEmisor;
	}

	public String getTokenEmisor() {
		return tokenEmisor;
	}

	public void setTokenEmisor(String tokenEmisor) {
		this.tokenEmisor = tokenEmisor;
	}

	public Boolean getTerminosCondiciones() {
		return terminosCondiciones;
	}

	public void setTerminosCondiciones(Boolean terminosCondiciones) {
		this.terminosCondiciones = terminosCondiciones;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(String fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getNombre1() {
		return nombre1;
	}

	public void setNombre1(String nombre1) {
		this.nombre1 = nombre1;
	}

	public String getNombre2() {
		return nombre2;
	}

	public void setNombre2(String nombre2) {
		this.nombre2 = nombre2;
	}

	public String getApellido1() {
		return apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public String getGrupoSanguineoRH() {
		return grupoSanguineoRH;
	}

	public void setGrupoSanguineoRH(String grupoSanguineoRH) {
		this.grupoSanguineoRH = grupoSanguineoRH;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getCodigoVerificacion1() {
		return codigoVerificacion1;
	}

	public void setCodigoVerificacion1(String codigoVerificacion1) {
		this.codigoVerificacion1 = codigoVerificacion1;
	}

	public String getCodigoVeriricacion2() {
		return codigoVeriricacion2;
	}

	public void setCodigoVeriricacion2(String codigoVeriricacion2) {
		this.codigoVeriricacion2 = codigoVeriricacion2;
	}

	public String getNroReferente() {
		return nroReferente;
	}

	public void setNroReferente(String nroReferente) {
		this.nroReferente = nroReferente;
	}

	public String getUuidDispositivo() {
		return uuidDispositivo;
	}

	public void setUuidDispositivo(String uuidDispositivo) {
		this.uuidDispositivo = uuidDispositivo;
	}

	public String getAppCodeVersion() {
		return appCodeVersion;
	}

	public void setAppCodeVersion(String appCodeVersion) {
		this.appCodeVersion = appCodeVersion;
	}

	public String getNumeroOtp() {
		return numeroOtp;
	}

	public void setNumeroOtp(String numeroOtp) {
		this.numeroOtp = numeroOtp;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public String getScanType() {
		return scanType;
	}

	public void setScanType(String scanType) {
		this.scanType = scanType;
	}
	
}