package co.cobre.billetera.dto.core.transaccional;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TransactionsTypes {
    
    // TYPES TRANSACTION
    public static final String TYPE_DEBIT = "DB";
    public static final String TYPE_CREDIT = "CR";
    public static final String TYPE_NA = "NA";


    // SHORT NAME TRANSACTION
    public static final String SHORT_NAME_PAYMENT = "AB";
    public static final String SHORT_NAME_CHARGE = "CA";
    
    public static final String SHORT_NAME_PURCHASE = "CO";
    public static final String SHORT_NAME_VIRTUAL_PURCHASE = "CV";
    public static final String SHORT_NAME_WITHDRAWAL = "RE";
    
    public static final String SHORT_NAME_PURCHASE_REVERSAL = "RC";
    public static final String SHORT_NAME_VIRTUAL_PURCHASE_REVERSAL = "RV";
    public static final String SHORT_NAME_WITHDRAWAL_REVERSAL = "RR";
    
    public static final String SHORT_NAME_PURCHASE_QR = "CQ";
    public static final String SHORT_NAME_WITHDRAWAL_QR = "RQ";
    
    public static final String SHORT_NAME_PURCHASE_QR_REVERSAL = "QC";
    public static final String SHORT_NAME_WITHDRAWAL_QR_REVERSAL = "QR";

    public static final String SHORT_NAME_DEBIT_ADJUSTMENT = "AD";
    public static final String SHORT_NAME_CREDIT_ADJUSTMENT = "AC";
    
    public static final String SHORT_NAME_COMMERCE_TARIFF = "TC";
    public static final String SHORT_NAME_COMMERCE_TARIFF_REVERSAL = "TR";
    
    public static final String SHORT_NAME_TRANSFER_IN = "T1";
    public static final String SHORT_NAME_TRANSFER_OUT = "T2";
    

    Long id;
    String shortName;
    String description;
    String typeTransaction;
}
