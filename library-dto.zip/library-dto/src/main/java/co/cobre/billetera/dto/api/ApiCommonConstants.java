package co.cobre.billetera.dto.api;

public class ApiCommonConstants {
    
    private ApiCommonConstants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String WORKPLACE_BANK_CODE_HEADER_KEY = "X-WorkplaceBankCode";
    public static final String DEVICE_ID_HEADER_KEY = "X-deviceUUID";
    public static final String TRANSACTION_ID = "X-TransactionId";
    public static final String TENANT_ID_HEADER_KEY = "X-TenantId";
    public static final String IPADDRESS_ID_HEADER_KEY = "X-IpAddress";
    public static final String SUPPER_APP_VERSION_HEADER_KEY = "X-SuperAppVersion";
    public static final String SUPPER_APP_PLATFORM_HEADER_KEY = "X-SuperAppPlatform";
    public static final String AUTHORIZATION_HEADER_KEY = "authorization";
    public static final String AUTHORIZATION = "authorization";
    public static final String START_TIME_HEADER_KEY = "X-StartTime";
    public static final String FORWARDED_FOR_HEADER_KEY = "X-FORWARDED-FOR";
    public static final String TRANSACTION_CONTEXT_KEY = "TransactionContext";
    public static final String AUTH_CONTEXT_KEY = "AuthContext";
    public static final String ORIGIN_WRAPPER = "Origin-Wrapper";
}
