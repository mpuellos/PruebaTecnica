package co.cobre.billetera.dto.loans;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LoansClientData {
    private String billingCycle;
    private String email;
    private LoansAddressData correspondenceData;
    private LoansAddressData residenceData;
}
