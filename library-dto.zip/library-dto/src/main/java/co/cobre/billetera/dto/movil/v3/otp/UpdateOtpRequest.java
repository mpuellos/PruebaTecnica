package co.cobre.billetera.dto.movil.v3.otp;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class UpdateOtpRequest {

  private final Long walletId;
  private final Long transactionId;
  private final String email;
  private final String phone;
  private final String status;
  
}
