package co.cobre.billetera.dto.movil.v3.event;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@ToString(callSuper=true, includeFieldNames=true)
@SuperBuilder
public final class PaymentNoveltyEvent extends MessageEvent {

  String documentNumber;
  String accountNumber;
  Long walletId;
  Double paymentAmount;

  @Override
  String getMessageGroupId() {
    return workplaceBankCode.concat("::").concat(PaymentNoveltyEvent.class.getSimpleName());
  }

  @JsonCreator
  public PaymentNoveltyEvent(String sender, String workplaceBankCode, Long workplaceBankId,
      String date, String documentNumber, String accountNumber, Long walletId,
      Double paymentAmount) {
    super(sender, workplaceBankCode, workplaceBankId, date);
    this.documentNumber = documentNumber;
    this.accountNumber = accountNumber;
    this.walletId = walletId;
    this.paymentAmount = paymentAmount;
  }


}
