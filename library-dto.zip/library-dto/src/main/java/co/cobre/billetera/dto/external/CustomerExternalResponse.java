package co.cobre.billetera.dto.external;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class CustomerExternalResponse {

  String uuid;
  String name;
  String lastName;
  String documentId;
  String accountNumber;
  String status;
  String documentType;
  String processDate;
  String registerDate;
  String birthdate;
  String email;
  String phone;
  
}
