package co.cobre.billetera.dto.errors.builder;

import co.cobre.billetera.dto.errors.NotFoundException;

public class NotFoundExceptionBuilder extends ExceptionBuilder<NotFoundException> {

    @Override
    public NotFoundException internalBuild() {
        return new NotFoundException(getCause(), getMessage(), getErrorCode(), getLocation(),
                getMoreInfo());
    }

    public static ExceptionBuilder<NotFoundException> builder() {
        return new NotFoundExceptionBuilder();
    }
}
