package co.cobre.billetera.dto.movil.v2;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class RegistroClienteDocumentoRequest implements IRequestValidator, Serializable {
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("tipoDocumento")
	private String tipoDocumento;
	
	@JsonProperty("documento")
	private String numeroDocumento;
	
	@JsonProperty("foto")
	private String foto;
	
	private String nombreFoto;
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getFoto() {
		return foto;
	}

	public void setFoto(String foto) {
		this.foto = foto;
	}

	public String getNombreFoto() {
		return nombreFoto;
	}

	public void setNombreFoto(String nombreFoto) {
		this.nombreFoto = nombreFoto;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((tipoDocumento == null) || (tipoDocumento.trim().length() == 0)
				|| (tipoDocumento.trim().length() != 1)) {
			throw new Exception ("El campo tipo de documento esta vacio o errado!");
		}
		
		if ((numeroDocumento == null) || (numeroDocumento.trim().length() == 0)
				|| (numeroDocumento.trim().length() > 15) || (!Parametros.validateOnlyDigits(numeroDocumento))) {
			throw new Exception ("El campo numero de documento esta vacio o errado!");
		}
		
		if ((foto == null) || (foto.trim().equals(""))) {
			throw new Exception ("El campo foto/documento esta vacio o errado!");
		}
		
		return valid;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RegistroClienteDocumentoRequest [tipoDocumento=");
		builder.append(tipoDocumento);
		builder.append(", numeroDocumento=");
		builder.append(numeroDocumento);
		builder.append(", foto=");
		builder.append(foto);
		builder.append(", nombreFoto=");
		builder.append(nombreFoto);
		builder.append("]");
		return builder.toString();
	}
	
}