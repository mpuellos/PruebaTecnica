package co.cobre.billetera.dto.lib.logging;

public class LogConstants {
  
  private LogConstants() {
    
  }

  public static final String ITOPS_LOG_NAME = "itopsLog";
  public static final String APPLICATION_LOG_NAME = "applicationLog";
  public static final String ITOPS_LOG_PATTERN = "%s::%s::%s";
  public static final String ITOPS_LOG_PATTERN_DETAIL = "%s::%s::%s::%s";
  public static final String INIT_LOG_PATTERN = "** %s-%s-Init **";
  public static final String FINISH_LOG_PATTERN = "** %s-%s-Finish **";
  public static final String WEB_INIT_LOG_PATTERN = "[preHandle] Request URL::%s";
  public static final String WEB_FINISH_LOG_PATTERN = "[postHandle] Request URL::%s::Time Taken=%sms";
  public static final String WEB_LOG_IP_PATTERN = "IP from proxy - X-FORWARDED-FOR : %s";
  public static final String TENANTS_LOADED_INFO = "The Following tenants datasources have been loaded: %s";
  public static final String EMPTY_AUTHORIZATION = "El header de autorizacion esta vacio";
  public static final String INVALID_AUTHORIZATION = "El header de autorizacion es invalido";
  public static final String WORKPLACE_BANK_CODE_REQUIRED = "El header %s esta esta vacio";

}
