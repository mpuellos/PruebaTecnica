package co.cobre.billetera.dto.movil.v3.event;

import org.json.JSONException;
import org.json.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import co.cobre.billetera.dto.errors.ErrorCode;
import co.cobre.billetera.dto.errors.builder.ServiceExceptionBuilder;
import co.cobre.billetera.dto.lib.ObjectMapperFactory;

public class EventParserUtil<T extends MessageEvent> {

  private static final String JSON_KEY = "Message";

  public T parseEvent(String event, Class<T> typeParameterClass) {

    try {
      String jsonMessageEvent = new JSONObject(event).getString(JSON_KEY);
      return ObjectMapperFactory.getInstance().readValue(jsonMessageEvent, typeParameterClass);

    } catch (JsonProcessingException | JSONException e) {
      throw ServiceExceptionBuilder.builder().exceptionCode(ErrorCode.UNEXPECTED_ERROR.getId())
          .message(String.format("Ocurrio un error en el mapeo del evento a la clase: %s.",
              typeParameterClass.getCanonicalName()))
          .location(this.getClass().getCanonicalName()).cause(e).build();
    }

  }

}
