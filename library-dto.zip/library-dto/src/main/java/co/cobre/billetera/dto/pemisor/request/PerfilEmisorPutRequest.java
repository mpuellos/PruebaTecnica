package co.cobre.billetera.dto.pemisor.request;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class PerfilEmisorPutRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;
	private String uuid;
	private String nombre;
	private String descripcion;
	private String estado;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.id == null) || (String.valueOf(this.id).isEmpty())) {
			throw new Exception("El campo id esta vacio o errado!");
		}

		if ((this.uuid == null) || (this.uuid.isEmpty())) {
			throw new Exception("El campo uuid esta vacio o errado!");
		}
		
		if ((this.nombre == null) || (this.nombre.isEmpty())) {
			throw new Exception("El campo nombre esta vacio o errado!");
		}

		if ((this.descripcion == null) || (this.descripcion.isEmpty())) {
			throw new Exception("El campo descripcion esta vacio o errado!");
		}
		
		if ((this.estado == null) || (this.estado.isEmpty())) {
			throw new Exception("El campo estado esta vacio o errado!");
		}

		return valid;
	}

}