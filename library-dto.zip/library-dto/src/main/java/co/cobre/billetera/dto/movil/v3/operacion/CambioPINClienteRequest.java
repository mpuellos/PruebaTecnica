package co.cobre.billetera.dto.movil.v3.operacion;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class CambioPINClienteRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * Nuevos atributos para la super APP, con esto podemos identificar el registro
	 * de que emisor corresponde
	 */
	private Long idEmisor;
	private String tokenEmisor;

	private String numeroCuenta;
	private String pin1;
	private String pin2;
	private String pin3;
	private String uuidDispositivo;

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getTokenEmisor() {
		return tokenEmisor;
	}

	public void setTokenEmisor(String tokenEmisor) {
		this.tokenEmisor = tokenEmisor;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getPin1() {
		return pin1;
	}

	public void setPin1(String pin1) {
		this.pin1 = pin1;
	}

	public String getPin2() {
		return pin2;
	}

	public void setPin2(String pin2) {
		this.pin2 = pin2;
	}

	public String getPin3() {
		return pin3;
	}

	public void setPin3(String pin3) {
		this.pin3 = pin3;
	}

	public String getUuidDispositivo() {
		return uuidDispositivo;
	}

	public void setUuidDispositivo(String uuidDispositivo) {
		this.uuidDispositivo = uuidDispositivo;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.numeroCuenta == null) || (this.numeroCuenta.isEmpty())
				|| (!Parametros.validateOnlyDigits(this.numeroCuenta))) {
			throw new Exception("El campo numero de cuenta esta vacio o errado!");
		}

		if ((this.pin1 == null) || (this.pin1.isEmpty()) || (!Parametros.validateOnlyDigits(this.pin1))) {
			throw new Exception("El campo pin1 esta vacio o errado!");
		}
		
		if ((this.pin2 == null) || (this.pin2.isEmpty()) || (!Parametros.validateOnlyDigits(this.pin2))) {
			throw new Exception("El campo pin2 esta vacio o errado!");
		}
		
		if ((this.pin3 == null) || (this.pin3.isEmpty()) || (!Parametros.validateOnlyDigits(this.pin3))) {
			throw new Exception("El campo pin3 esta vacio o errado!");
		}

		if ((this.uuidDispositivo == null) || (this.uuidDispositivo.isEmpty())) {
			throw new Exception("El campo uuidDispositivo esta vacio o errado!");
		}

		return valid;
	}

}