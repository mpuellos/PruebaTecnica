package co.cobre.billetera.dto.movil.v2;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.pexto.monedero.apidto.exceptions.FieldException;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class RegistroClienteRequest implements IRequestValidator {

	/*
	 * Nuevos atributos para la super APP, con esto podemos identificar el registro
	 * de que emisor corresponde
	 */
	private Long idEmisor;
	private String tokenEmisor;

	// Datos del Front (Android)
	private String tipoDocumento;
	private String numeroDocumento;
	private String numeroCelular;
	private String correoElectronico;
	private String fechaExpedicion;

	// Este dato se asigna en la API-Movil
	private String ipOrigen;

	// Datos del front pero en la vista de Confirmacion
	private String numeroOtp;

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getTokenEmisor() {
		return tokenEmisor;
	}

	public void setTokenEmisor(String tokenEmisor) {
		this.tokenEmisor = tokenEmisor;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public String getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(String fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getNumeroOtp() {
		return numeroOtp;
	}

	public void setNumeroOtp(String numeroOtp) {
		this.numeroOtp = numeroOtp;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.ipOrigen == null) || (this.ipOrigen.isEmpty())) {
			throw new FieldException("El campo Ip Origen esta vacio!", "ipOrigen");
		}

		if ((this.tipoDocumento == null) || (this.tipoDocumento.isEmpty())
				|| (this.tipoDocumento.trim().length() != 1)) {
			throw new FieldException("El campo tipo de documento esta vacio o errado!", "tipoDocumento");
		}

		if ((this.numeroDocumento == null) || (this.numeroDocumento.isEmpty())
				|| (this.numeroDocumento.trim().length() > 15)
				|| (!Parametros.validateOnlyDigits(this.numeroDocumento))) {
			throw new FieldException("El campo numero de documento esta vacio o errado!", "numeroDocumento");
		}

		if ((this.fechaExpedicion == null) || (this.fechaExpedicion.isEmpty()) || (this.fechaExpedicion.length() != 8)
				|| (!Parametros.validateOnlyDigits(this.fechaExpedicion))) {
			throw new FieldException("El campo fecha de expedicion esta vacio o errado!", "fechaExpedicion");
		}

		if ((this.numeroCelular == null) || (this.numeroCelular.isEmpty()) || (this.numeroCelular.trim().length() != 10)
				|| (!Parametros.validateOnlyDigits(this.numeroCelular))) {
			throw new FieldException("El campo numero de celular esta vacio o errado!", "numeroCelular");
		}

		if ((this.correoElectronico == null) || (this.correoElectronico.isEmpty())) {
			throw new FieldException("El campo correo electronico esta vacio o errado!", "correoElectronico");
		}

		try {
			InternetAddress emailAddr = new InternetAddress(this.correoElectronico);
			emailAddr.validate();
		} catch (AddressException ex) {
			throw new FieldException("El campo correo electronico no es valido!", "correoElectronico");
		}

		if ((this.numeroOtp != null) && (this.numeroOtp.length() != 6)
				&& (!Parametros.validateOnlyDigits(this.numeroOtp))) {
			throw new FieldException("El campo numero OTP esta errado!", "numeroOtp");
		}

		return valid;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RegistroClienteRequest [idEmisor=");
		builder.append(idEmisor);
		builder.append(", tokenEmisor=");
		builder.append(tokenEmisor);
		builder.append(", tipoDocumento=");
		builder.append(tipoDocumento);
		builder.append(", numeroDocumento=");
		builder.append(numeroDocumento);
		builder.append(", numeroCelular=");
		builder.append(numeroCelular);
		builder.append(", correoElectronico=");
		builder.append(correoElectronico);
		builder.append(", fechaExpedicion=");
		builder.append(fechaExpedicion);
		builder.append(", ipOrigen=");
		builder.append(ipOrigen);
		builder.append(", numeroOtp=");
		builder.append(numeroOtp);
		builder.append("]");
		return builder.toString();
	}

}