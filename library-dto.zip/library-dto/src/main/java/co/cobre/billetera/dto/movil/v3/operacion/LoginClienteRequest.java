package co.cobre.billetera.dto.movil.v3.operacion;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class LoginClienteRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * Nuevos atributos para la super APP, con esto podemos identificar el registro
	 * de que emisor corresponde
	 */
	private Long idEmisor;
	private String tokenEmisor;

	private String numeroCuenta;
	private String pin;
	private String uuidDispositivo;

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getTokenEmisor() {
		return tokenEmisor;
	}

	public void setTokenEmisor(String tokenEmisor) {
		this.tokenEmisor = tokenEmisor;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getPin() {
		return pin;
	}

	public void setPin(String pin) {
		this.pin = pin;
	}

	public String getUuidDispositivo() {
		return uuidDispositivo;
	}

	public void setUuidDispositivo(String uuidDispositivo) {
		this.uuidDispositivo = uuidDispositivo;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.numeroCuenta == null) || (this.numeroCuenta.isEmpty())
				|| (!Parametros.validateOnlyDigits(this.numeroCuenta))) {
			throw new Exception("El campo numero de cuenta esta vacio o errado!");
		}

		if ((this.pin == null) || (this.pin.isEmpty()) || (!Parametros.validateOnlyDigits(this.pin))) {
			throw new Exception("El campo pin esta vacio o errado!");
		}

		if ((this.uuidDispositivo == null) || (this.uuidDispositivo.isEmpty())) {
			throw new Exception("El campo uuidDispositivo esta vacio o errado!");
		}

		return valid;
	}

}