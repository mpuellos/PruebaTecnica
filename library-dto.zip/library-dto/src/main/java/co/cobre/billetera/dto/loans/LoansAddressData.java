package co.cobre.billetera.dto.loans;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class LoansAddressData {
    private String address;
    private String city;
    private String country;
    private String department;
}
