package co.cobre.billetera.dto.pemisor.request;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class RecursoEmisorPostRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String nombre;
	private String descripcion;
	private String url;
	private String tipo;

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.nombre == null) || (this.nombre.isEmpty())) {
			throw new Exception("El campo nombre esta vacio o errado!");
		}

		if ((this.descripcion == null) || (this.descripcion.isEmpty())) {
			throw new Exception("El campo descripcion esta vacio o errado!");
		}
		
		if ((this.url == null) || (this.url.isEmpty())) {
			throw new Exception("El campo url esta vacio o errado!");
		}

		if ((this.tipo == null) || (this.tipo.isEmpty())) {
			throw new Exception("El campo tipo esta vacio o errado!");
		}

		return valid;
	}

}