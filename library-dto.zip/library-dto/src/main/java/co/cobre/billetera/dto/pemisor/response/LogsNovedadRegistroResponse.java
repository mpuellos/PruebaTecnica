package co.cobre.billetera.dto.pemisor.response;

import java.io.Serializable;
import java.util.Date;

public class LogsNovedadRegistroResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	private String ipOrigen;
	private Date fechaRegistro;
	private String tipoDocumento;
	private String numeroDocumento;
	private String nombre1;
	private String nombre2;
	private String apellido1;
	private String apellido2;
	private Date fechaNacimiento;
	private Date fechaExpedicion;
	private String correo;
	private String sexo;
	private String grupoSanguineo;
	private String numeroCelular;
	private String numeroCelularHash;
	private String numeroCelularEncode;
	private String estado;
	private String motivo;
	private String numeroOtp;
	private Date vigenciaOtp;
	private String nroReferido;
	private String nroReferente;
	private String uuidDispositivo;
	private String appCodeVersion;
	private String apiCodeVersion;
	private String tipoDocumentoApp;
	private String numeroDocumentoApp;
	private String correoApp;
	private String numeroCelularApp;
	private String fechaExpedicionApp;
	private String tipoDocumentoEmisor;
	private String numeroDocumentoEmisor;
	private String nombre1Emisor;
	private String nombre2Emisor;
	private String apellido1Emisor;
	private String apellido2Emisor;
	private String fechaNacimientoEmisor;
	private String fechaExpedicionEmisor;
	private String correoEmisor;
	private String numeroCelularEmisor;
	private String numeroTelefonoEmisor;

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombre1() {
		return nombre1;
	}

	public void setNombre1(String nombre1) {
		this.nombre1 = nombre1;
	}

	public String getNombre2() {
		return nombre2;
	}

	public void setNombre2(String nombre2) {
		this.nombre2 = nombre2;
	}

	public String getApellido1() {
		return apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public Date getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(Date fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public String getGrupoSanguineo() {
		return grupoSanguineo;
	}

	public void setGrupoSanguineo(String grupoSanguineo) {
		this.grupoSanguineo = grupoSanguineo;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getNumeroCelularHash() {
		return numeroCelularHash;
	}

	public void setNumeroCelularHash(String numeroCelularHash) {
		this.numeroCelularHash = numeroCelularHash;
	}

	public String getNumeroCelularEncode() {
		return numeroCelularEncode;
	}

	public void setNumeroCelularEncode(String numeroCelularEncode) {
		this.numeroCelularEncode = numeroCelularEncode;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getNumeroOtp() {
		return numeroOtp;
	}

	public void setNumeroOtp(String numeroOtp) {
		this.numeroOtp = numeroOtp;
	}

	public Date getVigenciaOtp() {
		return vigenciaOtp;
	}

	public void setVigenciaOtp(Date vigenciaOtp) {
		this.vigenciaOtp = vigenciaOtp;
	}

	public String getUuidDispositivo() {
		return uuidDispositivo;
	}

	public void setUuidDispositivo(String uuidDispositivo) {
		this.uuidDispositivo = uuidDispositivo;
	}

	public String getAppCodeVersion() {
		return appCodeVersion;
	}

	public void setAppCodeVersion(String appCodeVersion) {
		this.appCodeVersion = appCodeVersion;
	}

	public String getTipoDocumentoApp() {
		return tipoDocumentoApp;
	}

	public void setTipoDocumentoApp(String tipoDocumentoApp) {
		this.tipoDocumentoApp = tipoDocumentoApp;
	}

	public String getNumeroDocumentoApp() {
		return numeroDocumentoApp;
	}

	public void setNumeroDocumentoApp(String numeroDocumentoApp) {
		this.numeroDocumentoApp = numeroDocumentoApp;
	}

	public String getCorreoApp() {
		return correoApp;
	}

	public void setCorreoApp(String correoApp) {
		this.correoApp = correoApp;
	}

	public String getNumeroCelularApp() {
		return numeroCelularApp;
	}

	public void setNumeroCelularApp(String numeroCelularApp) {
		this.numeroCelularApp = numeroCelularApp;
	}

	public String getFechaExpedicionApp() {
		return fechaExpedicionApp;
	}

	public void setFechaExpedicionApp(String fechaExpedicionApp) {
		this.fechaExpedicionApp = fechaExpedicionApp;
	}

	public String getTipoDocumentoEmisor() {
		return tipoDocumentoEmisor;
	}

	public void setTipoDocumentoEmisor(String tipoDocumentoEmisor) {
		this.tipoDocumentoEmisor = tipoDocumentoEmisor;
	}

	public String getNumeroDocumentoEmisor() {
		return numeroDocumentoEmisor;
	}

	public void setNumeroDocumentoEmisor(String numeroDocumentoEmisor) {
		this.numeroDocumentoEmisor = numeroDocumentoEmisor;
	}

	public String getNombre1Emisor() {
		return nombre1Emisor;
	}

	public void setNombre1Emisor(String nombre1Emisor) {
		this.nombre1Emisor = nombre1Emisor;
	}

	public String getNombre2Emisor() {
		return nombre2Emisor;
	}

	public void setNombre2Emisor(String nombre2Emisor) {
		this.nombre2Emisor = nombre2Emisor;
	}

	public String getApellido1Emisor() {
		return apellido1Emisor;
	}

	public void setApellido1Emisor(String apellido1Emisor) {
		this.apellido1Emisor = apellido1Emisor;
	}

	public String getApellido2Emisor() {
		return apellido2Emisor;
	}

	public void setApellido2Emisor(String apellido2Emisor) {
		this.apellido2Emisor = apellido2Emisor;
	}

	public String getFechaNacimientoEmisor() {
		return fechaNacimientoEmisor;
	}

	public void setFechaNacimientoEmisor(String fechaNacimientoEmisor) {
		this.fechaNacimientoEmisor = fechaNacimientoEmisor;
	}

	public String getFechaExpedicionEmisor() {
		return fechaExpedicionEmisor;
	}

	public void setFechaExpedicionEmisor(String fechaExpedicionEmisor) {
		this.fechaExpedicionEmisor = fechaExpedicionEmisor;
	}

	public String getCorreoEmisor() {
		return correoEmisor;
	}

	public void setCorreoEmisor(String correoEmisor) {
		this.correoEmisor = correoEmisor;
	}

	public String getNumeroCelularEmisor() {
		return numeroCelularEmisor;
	}

	public void setNumeroCelularEmisor(String numeroCelularEmisor) {
		this.numeroCelularEmisor = numeroCelularEmisor;
	}

	public String getNumeroTelefonoEmisor() {
		return numeroTelefonoEmisor;
	}

	public void setNumeroTelefonoEmisor(String numeroTelefonoEmisor) {
		this.numeroTelefonoEmisor = numeroTelefonoEmisor;
	}

	public String getNroReferido() {
		return nroReferido;
	}

	public void setNroReferido(String nroReferido) {
		this.nroReferido = nroReferido;
	}

	public String getNroReferente() {
		return nroReferente;
	}

	public void setNroReferente(String nroReferente) {
		this.nroReferente = nroReferente;
	}

	public String getApiCodeVersion() {
		return apiCodeVersion;
	}

	public void setApiCodeVersion(String apiCodeVersion) {
		this.apiCodeVersion = apiCodeVersion;
	}

}