package co.cobre.billetera.dto.movil.v3.operacion;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class WalletTransaction {

  String description;
  String branch;
  String date;
  String authorization;
  String commerceName;
  String commerceFullname;
  Double amount;
  String nature;
  String walletCode;
  String walletName;
  String typeCode;
  String typeDesc;

}
