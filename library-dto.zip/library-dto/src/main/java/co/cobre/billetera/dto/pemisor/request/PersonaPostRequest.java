package co.cobre.billetera.dto.pemisor.request;

import java.io.Serializable;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class PersonaPostRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String numeroDocumento;
	private String nombres;
	private String apellidos;
	private String correo;
	private String telefono;
	private String cargo;
	private String estado;
	private Long idTipoDocumento;

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Long getIdTipoDocumento() {
		return idTipoDocumento;
	}

	public void setIdTipoDocumento(Long idTipoDocumento) {
		this.idTipoDocumento = idTipoDocumento;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.numeroDocumento == null) || (this.numeroDocumento.isEmpty())
				|| !Parametros.validateOnlyDigits(this.numeroDocumento)) {
			throw new Exception("El campo numero de documento esta vacio o errado!");
		}

		if ((this.nombres == null) || (this.nombres.isEmpty())) {
			throw new Exception("El campo nombres esta vacio o errado!");
		}

		if ((this.apellidos == null) || (this.apellidos.isEmpty())) {
			throw new Exception("El campo apellidos esta vacio o errado!");
		}

		if ((this.correo == null) || (this.correo.isEmpty())) {
			throw new Exception("El campo correo electronico esta vacio o errado!");
		}

		try {
			InternetAddress emailAddr = new InternetAddress(this.correo);
			emailAddr.validate();
		} catch (AddressException ex) {
			throw new Exception("El campo correo electronico no es valido!");
		}

		if ((this.telefono == null) || (this.telefono.isEmpty())) {
			throw new Exception("El campo numero de telefono esta vacio o errado!");
		}

		if ((this.cargo == null) || (this.cargo.isEmpty())) {
			throw new Exception("El campo cargo esta vacio o errado!");
		}

		if ((this.estado == null) || (this.estado.isEmpty())) {
			throw new Exception("El campo estado esta vacio o errado!");
		}

		if ((this.idTipoDocumento == null) || (String.valueOf(this.idTipoDocumento).isEmpty())) {
			throw new Exception("El campo id tipo documento esta vacio o errado!");
		}

		return valid;
	}

}