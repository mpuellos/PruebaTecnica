package co.cobre.billetera.dto.external;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class CustomerOtpLoginResponse {

  String validity;
  String validityType;
  String validityAmount;
  String correlationId;
}
