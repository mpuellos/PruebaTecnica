package co.cobre.billetera.dto.core.transaccional;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CreateCreditWallet {
	
	String clientDocument;
	
	String documentType;
	 
	String walletCode;

}
