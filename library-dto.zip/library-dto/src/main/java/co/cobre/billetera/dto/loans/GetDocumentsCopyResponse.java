package co.cobre.billetera.dto.loans;

import lombok.*;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GetDocumentsCopyResponse {
    private int order;
    private DocumentTypeDto type;
    private String name;
    private String text;
}
