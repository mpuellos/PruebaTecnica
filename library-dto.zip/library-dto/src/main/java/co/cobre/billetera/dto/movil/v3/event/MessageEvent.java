package co.cobre.billetera.dto.movil.v3.event;

import java.util.UUID;
import lombok.Builder;
import lombok.Getter;
import lombok.ToString;
import lombok.experimental.SuperBuilder;

@Getter
@SuperBuilder
@ToString
public abstract class MessageEvent {

  @Builder.Default
  String uuid = UUID.randomUUID().toString();
  String sender;
  String workplaceBankCode;
  Long workplaceBankId;
  String date;

  protected MessageEvent(String sender, String workplaceBankCode, Long workplaceBankId, String date) {
    this.sender = sender;
    this.workplaceBankCode = workplaceBankCode;
    this.workplaceBankId = workplaceBankId;
    this.date = date;
  }
  
  abstract String getMessageGroupId();

}
