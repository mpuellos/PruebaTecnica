package co.cobre.billetera.dto.movil.v3.otp;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class ValidateOtpRequest {

  private final String correlationId;

  private final String otp;

  private final String contextCode;
  
}
