package co.cobre.billetera.dto.movil.v3.operacion;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class WalletResponse {

  String uuid;
  Long id;
  String accountNumber;
  String accountStatus;
  String workplaceBankCode;
  String validityFrom;
  String validityTo;
  Long walletId;
  String walletIssuer;
  String walletName;
  String walletCode;
  String walletStatus;
  String walletNature;
  Double balance;

}
