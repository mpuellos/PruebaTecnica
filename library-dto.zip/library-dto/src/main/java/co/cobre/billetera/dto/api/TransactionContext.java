package co.cobre.billetera.dto.api;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class TransactionContext {

  String deviceUUID;
  String transactionId;
  String tenantId;
  String authorization;
  String workplaceBankCode;
}
