package co.cobre.billetera.dto.movil.v3.registro;

import java.io.Serializable;
import com.pexto.monedero.apidto.exceptions.FieldException;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class InternalConsultaClienteInscrito implements Serializable, IRequestValidator {

    /**
    *
    */
    private static final long serialVersionUID = 2323094702599608519L;

    private String documentType;
    private String documentId;
    private String workplaceBankCode;

    // Este dato se asigna en la API-Movil
    private String ipOrigen;

    

    public String getIpOrigen() {
        return ipOrigen;
    }

    public void setIpOrigen(String ipOrigen) {
        this.ipOrigen = ipOrigen;
    }

    @Override
    public boolean validateProperties() throws Exception {
        boolean valid = true;

        if(this.documentType == null){
            this.documentType = "0";
        }
        
        if ((this.ipOrigen == null) || (this.ipOrigen.isEmpty())) {
            throw new FieldException("El campo Ip Origen esta vacio!", "ipOrigen");
        }
        
        if ((this.documentId == null) || (this.documentId.isEmpty())) {
            throw new FieldException("El campo Document Id esta vacio!", "documentId");
        }

        if ((this.workplaceBankCode == null) || (this.workplaceBankCode.isEmpty())) {
            throw new FieldException("El campo Workplace Bank Code esta vacio!", "workplaceBankCode");
        }

        return valid;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getWorkplaceBankCode() {
        return workplaceBankCode;
    }

    public void setWorkplaceBankCode(String workplaceBankCode) {
        this.workplaceBankCode = workplaceBankCode;
    }

}