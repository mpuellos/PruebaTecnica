package co.cobre.billetera.dto.errors.builder;

import co.cobre.billetera.dto.errors.ServiceException;

public class ServiceExceptionBuilder extends ExceptionBuilder<ServiceException>{

  @Override
  public ServiceException internalBuild() {
    return new ServiceException(getCause(), getMessage(), getErrorCode(), getLocation(), getMoreInfo());
  }

  public static ExceptionBuilder<ServiceException> builder() {
    return new ServiceExceptionBuilder();
  }

}
