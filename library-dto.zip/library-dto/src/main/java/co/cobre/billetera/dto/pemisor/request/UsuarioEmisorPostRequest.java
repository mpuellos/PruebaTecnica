package co.cobre.billetera.dto.pemisor.request;

import java.io.Serializable;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class UsuarioEmisorPostRequest implements Serializable, IRequestValidator {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * Datos del usuario 
	 */
	
	private String logon;
	private Long idPerfil;

	/*
	 * Datos de la tabla persona 
	 */
	
	private String numeroDocumento;
	private String nombres;
	private String apellidos;
	private String correo;
	private String nroCelular;
	private String cargo;
	private String estado;

	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}

	public Long getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(Long idPerfil) {
		this.idPerfil = idPerfil;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNroCelular() {
		return nroCelular;
	}

	public void setNroCelular(String nroCelular) {
		this.nroCelular = nroCelular;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((this.logon == null) || (this.logon.isEmpty())) {
			throw new Exception("El campo logon esta vacio o errado!");
		}

		if ((this.idPerfil == null) || (String.valueOf(this.idPerfil).isEmpty())) {
			throw new Exception("El campo id perfil esta vacio o errado!");
		}

		if ((this.numeroDocumento == null) || (this.numeroDocumento.isEmpty())) {
			throw new Exception("El campo numero de documento esta vacio o errado!");
		}

		if ((this.nombres == null) || (this.nombres.isEmpty())) {
			throw new Exception("El campo nombres esta vacio o errado!");
		}

		if ((this.apellidos == null) || (this.apellidos.isEmpty())) {
			throw new Exception("El campo apellidos esta vacio o errado!");
		}

		if ((this.correo == null) || (this.correo.isEmpty())) {
			throw new Exception("El campo correo electronico esta vacio o errado!");
		}

		try {
			InternetAddress emailAddr = new InternetAddress(this.correo);
			emailAddr.validate();
		} catch (AddressException ex) {
			throw new Exception("El campo correo electronico no es valido!");
		}

		if ((this.nroCelular == null) || (this.nroCelular.isEmpty())) {
			throw new Exception("El campo numero de celular esta vacio o errado!");
		}

		if ((this.cargo == null) || (this.cargo.isEmpty())) {
			throw new Exception("El campo cargo esta vacio o errado!");
		}

		if ((this.estado == null) || (this.estado.isEmpty())) {
			throw new Exception("El campo estado esta vacio o errado!");
		}

		return valid;
	}

}