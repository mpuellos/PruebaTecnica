package co.cobre.billetera.dto.entertainmentPurchases;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EntertainmentRequest {

	private Long walletId;
	private String clientAccountNumber;
	private Double walletPurchaseAmount;
	private boolean payWithPoints;
	private Long cobreWalletId;
	private Double cobrePurchaseAmount;
	private Double purchaseAmount;
	private String providerCode;
	private String providerId;
	private Long serviceId;
	private Long planId;
}
