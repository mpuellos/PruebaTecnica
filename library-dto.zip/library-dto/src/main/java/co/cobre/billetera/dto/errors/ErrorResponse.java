package co.cobre.billetera.dto.errors;

import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class ErrorResponse {

  private final String errorCode;

  private final String message;

  private final String help;

  private final String location;

  private final List<MoreInfo> moreInfo;


  @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
  public ErrorResponse(@JsonProperty("errorCode") String errorCode,
      @JsonProperty("message") String message, 
      @JsonProperty("help") String help,
      @JsonProperty("location") String location,
      @JsonProperty("moreInfo") List<MoreInfo> moreInfo) {
    this.errorCode = errorCode;
    this.message = message;
    this.help = help;
    this.location = location;
    this.moreInfo = Collections.unmodifiableList(moreInfo);
  }

  public ErrorResponse(String errorCode, String message, String help, List<MoreInfo> moreInfo) {
    this.errorCode = errorCode;
    this.message = message;
    this.help = help;
    this.location = StringUtils.EMPTY;
    this.moreInfo = Collections.unmodifiableList(moreInfo);
  }


  public ErrorResponse(String errorCode, String message, String help, String location,
      Optional<String> moreInfo) {
    this.errorCode = errorCode;
    this.message = message;
    this.help = help;
    this.location = location;
    if (moreInfo.isPresent()) {
      this.moreInfo =
          Stream.of(new MoreInfo("Details", moreInfo.get())).collect(Collectors.toList());
    } else {
      this.moreInfo = Collections.emptyList();
    }
  }

  public ErrorResponse(String errorCode, String message, String help, String location,
      Throwable throwable) {
    this.errorCode = errorCode;
    this.message = message;
    this.help = help;
    this.location = location;
    if (throwable != null) {
      String errorMessage;
      if (throwable.getMessage() != null) {
        errorMessage = throwable.getMessage();
      } else {
        errorMessage = ExceptionUtils.getStackTrace(throwable).substring(0, 200).concat("...");
      }
      this.moreInfo = Stream.of(new MoreInfo("Details", errorMessage)).collect(Collectors.toList());
    } else {
      this.moreInfo = Collections.emptyList();
    }
  }

  public String getErrorCode() {
    return errorCode;
  }

  public String getMessage() {
    return message;
  }

  public String getHelp() {
    return help;
  }

  public String getLocation() {
    return location;
  }

  public List<MoreInfo> getMoreInfo() {
    return moreInfo;
  }

}
