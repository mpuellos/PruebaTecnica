package co.cobre.billetera.dto.errors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import co.cobre.billetera.dto.errors.builder.ServiceExceptionBuilder;

public class ErrorHandlerUtilService {

  private ErrorHandlerUtilService() {

  }

  public static BaseException handleError(Exception exc, ErrorCode errorCode, String errorMessage,
      String location) {

    int indexOfType = ExceptionUtils.indexOfType(exc, BaseException.class);

    if (indexOfType >= 0) {

      Throwable baseException = ExceptionUtils.getThrowableList(exc).get(indexOfType);

      if (baseException instanceof ServiceException) {
        throw ExceptionUtils.throwableOfThrowable(baseException, ServiceException.class);
      }

      if (baseException instanceof ValidationException) {
        throw ExceptionUtils.throwableOfThrowable(baseException, ValidationException.class);
      }

      if (baseException instanceof NotFoundException) {
        throw ExceptionUtils.throwableOfThrowable(baseException, NotFoundException.class);
      }

      if (baseException instanceof UnauthorizedException) {
        throw ExceptionUtils.throwableOfThrowable(baseException, UnauthorizedException.class);
      }

    }
    throw ServiceExceptionBuilder.builder().cause(exc).exceptionCode(errorCode.getId())
        .message(errorMessage).location(location).build();

  }
}
