package co.cobre.billetera.dto.errors;


public class TransactionException extends BaseException {

  private static final long serialVersionUID = -1388669437657940758L;
  
  private final Object transaction;
  
  public TransactionException(Throwable cause, String message, String exceptionCode, String location,
      String moreInfo, Object transaction) {
    super(cause, message, exceptionCode, location, moreInfo);
    this.transaction = transaction;
  }

  public Object getTransaction() {
    return transaction;
  }

}
