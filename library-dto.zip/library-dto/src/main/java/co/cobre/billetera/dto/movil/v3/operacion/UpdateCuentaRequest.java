package co.cobre.billetera.dto.movil.v3.operacion;

import javax.validation.constraints.Email;
import javax.validation.constraints.Size;

public class UpdateCuentaRequest {

	private String numeroCuenta;

	private String uuid;

	@Size(min = 10, max = 10, message = "El  tamaño del número celular es incorrecto")
	private String numeroCelular;

	private String direccion;

	@Email(message = "Correo inválido")
	private String correo;

	private String lugar_trabajo;

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getLugar_trabajo() {
		return lugar_trabajo;
	}

	public void setLugar_trabajo(String lugar_trabajo) {
		this.lugar_trabajo = lugar_trabajo;
	}

}
