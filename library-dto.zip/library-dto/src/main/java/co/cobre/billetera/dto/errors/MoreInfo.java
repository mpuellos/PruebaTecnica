package co.cobre.billetera.dto.errors;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class MoreInfo {

  private final String location;

  private final String message;

  @JsonCreator(mode = JsonCreator.Mode.PROPERTIES)
  public MoreInfo(@JsonProperty("location") String location,
      @JsonProperty("message") String message) {
    this.location = location;
    this.message = message;
  }

  public String getLocation() {
    return location;
  }

  public String getMessage() {
    return message;
  }
}
