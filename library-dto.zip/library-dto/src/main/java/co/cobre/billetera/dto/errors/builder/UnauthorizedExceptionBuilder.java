package co.cobre.billetera.dto.errors.builder;

import co.cobre.billetera.dto.errors.UnauthorizedException;

public class UnauthorizedExceptionBuilder extends ExceptionBuilder<UnauthorizedException> {

  @Override
  public UnauthorizedException internalBuild() {
    return new UnauthorizedException(getCause(), getMessage(), getErrorCode(), getLocation(),
        getMoreInfo());
  }

  public static ExceptionBuilder<UnauthorizedException> builder() {
    return new UnauthorizedExceptionBuilder();
  }
}
