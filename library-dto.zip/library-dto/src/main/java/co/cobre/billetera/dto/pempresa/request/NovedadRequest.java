package co.cobre.billetera.dto.pempresa.request;

import java.io.Serializable;

public class NovedadRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String nombreArchivoNovedad;
	private String cantidadRegistro;
	private String ipLocal;
	private String idEmisor;
	private String idUsuarioEmisor;
	private String ipOrigen;
	private String userAgent;
	private String idBolsillo;
	private String tipoNovedad;
	private String valorTotal;
	private String fechaArchivo;
	private String descripcion;
	private long documentoAdjunto;

	public String getNombreArchivoNovedad() {
		return nombreArchivoNovedad;
	}

	public void setNombreArchivoNovedad(String nombreArchivoNovedad) {
		this.nombreArchivoNovedad = nombreArchivoNovedad;
	}

	public String getIpLocal() {
		return ipLocal;
	}

	public void setIpLocal(String ipLocal) {
		this.ipLocal = ipLocal;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public String getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public void setIdUsuarioEmisor(String idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	public String getCantidadRegistro() {
		return cantidadRegistro;
	}

	public void setCantidadRegistro(String cantidadRegistro) {
		this.cantidadRegistro = cantidadRegistro;
	}

	public String getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(String idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public String getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getFechaArchivo() {
		return fechaArchivo;
	}

	public void setFechaArchivo(String fechaArchivo) {
		this.fechaArchivo = fechaArchivo;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public long getDocumentoAdjunto() {
		return documentoAdjunto;
	}

	public void setDocumentoAdjunto(long documentoAdjunto) {
		this.documentoAdjunto = documentoAdjunto;
	}

}
