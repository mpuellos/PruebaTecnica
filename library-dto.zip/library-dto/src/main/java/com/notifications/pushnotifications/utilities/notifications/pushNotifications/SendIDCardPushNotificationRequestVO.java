package com.notifications.pushnotifications.utilities.notifications.pushNotifications;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SendIDCardPushNotificationRequestVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String title;
	private String message;
	private List<String> idCards;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getIdCards() {
		return idCards;
	}

	public void setIdCards(List<String> idCards) {
		this.idCards = idCards;
	}

	public String toString() {
		ObjectMapper mapperObject = new ObjectMapper();
		Map<String, Object> response = new HashMap<String, Object>();

		try {
			response.put("title", this.getTitle());
			response.put("message", this.getMessage());
			response.put("idCards", this.getIdCards().toString());

			return mapperObject.writeValueAsString(response);
		} catch (JsonProcessingException e) {
			return "error: " + e.toString();
		}
	}
}