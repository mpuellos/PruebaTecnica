package com.notifications.pushnotifications.utilities.notifications.pushNotifications;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SendPushNotificationResponseVO {

	private String id;
	private String recipients;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRecipients() {
		return recipients;
	}

	public void setRecipients(String recipients) {
		this.recipients = recipients;
	}

	public String toString() {
		ObjectMapper mapperObject = new ObjectMapper();
		Map<String, Object> response = new HashMap<String, Object>();

		try {
			response.put("id", this.getId());
			response.put("recipients", this.getRecipients());

			return mapperObject.writeValueAsString(response);
		} catch (JsonProcessingException e) {
			return "error: " + e.toString();
		}
	}
}