package com.notifications.pushnotifications.utilities.notifications.pushNotifications;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SendByTagsPushNotificationRequestVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String title;
	private String message;
	private List<SendByTagsPushNotificationFilters> filters;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<SendByTagsPushNotificationFilters> getFilters() {
		return filters;
	}

	public void setFilters(List<SendByTagsPushNotificationFilters> filters) {
		this.filters = filters;
	}

	public String toString() {
		ObjectMapper mapperObject = new ObjectMapper();
		Map<String, Object> response = new HashMap<String, Object>();

		try {
			response.put("title", this.getTitle());
			response.put("message", this.getMessage());
			response.put("filters", this.getFilters().toString());

			return mapperObject.writeValueAsString(response);
		} catch (JsonProcessingException e) {
			return "error: " + e.toString();
		}
	}
}