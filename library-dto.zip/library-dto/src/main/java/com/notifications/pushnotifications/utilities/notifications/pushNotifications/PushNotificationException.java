package com.notifications.pushnotifications.utilities.notifications.pushNotifications;

public class PushNotificationException {

	public PushNotificationException(String message) {
		this.message = message;
	}

	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}