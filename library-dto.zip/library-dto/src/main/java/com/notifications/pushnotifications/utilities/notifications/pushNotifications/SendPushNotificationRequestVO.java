package com.notifications.pushnotifications.utilities.notifications.pushNotifications;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class SendPushNotificationRequestVO implements Serializable {

	private static final long serialVersionUID = 1L;

	private String title;
	private List<String> userId;
	private String message;
	private List<String> segments;

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public List<String> getUserId() {
		return userId;
	}

	public void setUserId(final List<String> userId) {
		this.userId = userId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getSegments() {
		return segments;
	}

	public void setSegments(List<String> segments) {
		this.segments = segments;
	}

	public String toString() {
		ObjectMapper mapperObject = new ObjectMapper();
		Map<String, Object> response = new HashMap<String, Object>();

		try {
			response.put("userId", this.getUserId());
			response.put("message", this.getMessage());
			response.put("segments", this.getSegments());

			return mapperObject.writeValueAsString(response);
		} catch (JsonProcessingException e) {
			return "error: " + e.toString();
		}
	}
}