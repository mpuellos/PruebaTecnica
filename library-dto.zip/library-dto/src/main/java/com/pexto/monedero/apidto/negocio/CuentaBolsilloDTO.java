package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class CuentaBolsilloDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String uuid;
	private Date fecha;
	private String estado;
	private String numeroCuenta;
	private String nombreCortoBolsillo;
	private String descripcionBolsillo;
	private Long idCuenta;
	private Long idBolsillo;
	private Long idEmisor;
	private Long idUsuarioEmisor;
	
	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Long getIdCuenta() {
		return idCuenta;
	}
	
	public void setIdCuenta(Long idCuenta) {
		this.idCuenta = idCuenta;
	}
	
	public Long getIdBolsillo() {
		return idBolsillo;
	}
	
	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public Long getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}
	
	public void setIdUsuarioEmisor(Long idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getNombreCortoBolsillo() {
		return nombreCortoBolsillo;
	}

	public void setNombreCortoBolsillo(String nombreCortoBolsillo) {
		this.nombreCortoBolsillo = nombreCortoBolsillo;
	}

	public String getDescripcionBolsillo() {
		return descripcionBolsillo;
	}

	public void setDescripcionBolsillo(String descripcionBolsillo) {
		this.descripcionBolsillo = descripcionBolsillo;
	}
	
}
