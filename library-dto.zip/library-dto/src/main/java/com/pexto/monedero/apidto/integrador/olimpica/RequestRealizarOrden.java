package com.pexto.monedero.apidto.integrador.olimpica;

import java.io.Serializable;

public class RequestRealizarOrden implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String numeroDocumentoCliente;
	private String nombre;
	private Long valor;
	
	public String getNumeroDocumentoCliente() {
		return numeroDocumentoCliente;
	}
	
	public void setNumeroDocumentoCliente(String numeroDocumentoCliente) {
		this.numeroDocumentoCliente = numeroDocumentoCliente;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public Long getValor() {
		return valor;
	}
	
	public void setValor(Long valor) {
		this.valor = valor;
	}	
}
