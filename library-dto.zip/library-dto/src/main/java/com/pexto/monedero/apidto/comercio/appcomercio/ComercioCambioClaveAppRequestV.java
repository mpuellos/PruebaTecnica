package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class ComercioCambioClaveAppRequestV  implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("logon")
	private String logon;
	
	@JsonProperty("passwordActual")
	private String passwordActual;
	
	@JsonProperty("passwordNuevo")
	private String passwordNuevo;
	
	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}

	public String getPasswordActual() {
		return passwordActual;
	}

	public void setPasswordActual(String passwordActual) {
		this.passwordActual = passwordActual;
	}

	public String getPasswordNuevo() {
		return passwordNuevo;
	}

	public void setPasswordNuevo(String passwordNuevo) {
		this.passwordNuevo = passwordNuevo;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		
		if ((this.logon == null) || (this.logon.trim().equals(""))) {
			throw new Exception ("Campo Logon is null or empty!");
		}
		
		if ((this.passwordActual == null) || (this.passwordActual.trim().equals(""))) {
			throw new Exception ("Campo Password Actual is null or empty!");
		}
		
		if ((this.passwordNuevo == null) || (this.passwordNuevo.trim().equals(""))) {
			throw new Exception ("Campo Password Nuevo is null or empty!");
		}
		
		if (this.passwordActual.equals(passwordNuevo)) {
			throw new Exception ("Por favor ingrese un password nuevo diferente al actual!");
		}
		
		return true;
	}
	
}
