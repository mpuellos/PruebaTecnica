package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ComercioTramaPGPAppResponseV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("trama")
	private String trama;
	
	public String getTrama() {
		return trama;
	}
	
	public void setTrama(String trama) {
		this.trama = trama;
	}
	
}
