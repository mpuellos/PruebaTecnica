package com.pexto.monedero.apidto.enterprises;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class EnterpriseEmployeePut {

	EnterpriseEmployeePut.Employee employee;
	EnterpriseEmployeePut.FavoriteTransferV bank;
    String typeMethodOfPay;

    @Getter
    @Builder(toBuilder = true)
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Employee {

        String typeDocument;
        String numberDocument;
        String names;
        String lastNames;
        String email;
        String phoneNumber;
        Date birthdateDate;
        Date expeditionDate;

    }

    @Getter
    @Builder(toBuilder = true)
    @AllArgsConstructor
    @NoArgsConstructor
    public static class FavoriteTransferV {

        Long bankId;
        Long accountTypeId;
        String accountNumber;

    }

}

