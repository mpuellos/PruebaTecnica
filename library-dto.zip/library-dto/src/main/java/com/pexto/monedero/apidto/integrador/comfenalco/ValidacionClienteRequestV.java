package com.pexto.monedero.apidto.integrador.comfenalco;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ValidacionClienteRequestV {

	@JsonProperty("tipoDocumento")
	private String tipoDocumento;

	@JsonProperty("documento")
	private String numeroDocumento;

	public ValidacionClienteRequestV() {
	}

	public ValidacionClienteRequestV(String tipoDocumento, String numeroDocumento) {
		super();
		this.tipoDocumento = tipoDocumento;
		this.numeroDocumento = numeroDocumento;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

}