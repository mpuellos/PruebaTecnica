package com.pexto.monedero.apidto.emisor.pemisor.afiliado;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class NovedadAfiliadoConsultaRequestV implements Serializable, IRequestValidator { 	
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("idEmisor")
	private String idEmisor;
	
	@JsonProperty("tipoDocumento")
	private String tipoDocumento;
	
	@JsonProperty("numeroDocumento")
	private String numeroDocumento;
	
	public String getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((tipoDocumento == null) || (tipoDocumento.trim().length() == 0)) {
			throw new Exception ("El campo Tipo Documento esta vacio o errado!");
		}
		
		if ((numeroDocumento == null) || (numeroDocumento.trim().length() == 0)) {
			throw new Exception ("El campo Numero Documento esta vacio o errado!");
		}
		
		return valid;
	}	
}