package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class MovimientoClienteV implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private double valor;
	private String autorizacion;
	private String fecha;
	private String hora;
	private String establecimiento;
	private String emisor;
	private String movimiento_tipo;
	private String movimiento_desc;
	private String naturaleza;
	private String estado;
	private String estado_desc;
	private String bolsillo;
	private String descripcionMovimiento;

	public MovimientoClienteV() {

	}

	public MovimientoClienteV(Long id, double valor, String autorizacion, Date fecha,
			String establecimiento, String movimiento_tipo, String movimiento_desc,
			String naturaleza, String estado, String estado_desc, String bolsillo) {
		super();
		init(id, valor, autorizacion, fecha, establecimiento, movimiento_tipo, movimiento_desc,
				naturaleza, estado, estado_desc, bolsillo);
	}

	public MovimientoClienteV(Long id, double valor, String autorizacion, Date fecha,
			String establecimiento, String movimiento_tipo, String movimiento_desc,
			String naturaleza, String estado, String estado_desc, String bolsillo,
			String descripcionMovimiento) {
		super();
		init(id, valor, autorizacion, fecha, establecimiento, movimiento_tipo, movimiento_desc,
				naturaleza, estado, estado_desc, bolsillo);
		this.descripcionMovimiento =
				descripcionMovimiento == null ? establecimiento : descripcionMovimiento;
	}

	private void init(Long id, double valor, String autorizacion, Date fecha,
			String establecimiento, String movimiento_tipo, String movimiento_desc,
			String naturaleza, String estado, String estado_desc, String bolsillo) {

		this.id = id;
		this.valor = valor;
		this.autorizacion = autorizacion;

		Calendar calendario = Calendar.getInstance();
		calendario.setTime(fecha);

		String dia = String.valueOf(calendario.get(Calendar.DATE));
		String mes = String.valueOf(calendario.get(Calendar.MONTH) + 1);
		mes = (mes.length() == 1) ? "0" + mes : mes;
		dia = (dia.length() == 1) ? "0" + dia : dia;

		String AM_PM = (calendario.get(Calendar.AM_PM) == 0) ? "AM" : "PM";

		this.fecha = calendario.get(Calendar.YEAR) + "-" + mes + "-" + dia;
		this.hora = calendario.get(Calendar.HOUR) + ":" + calendario.get(Calendar.MINUTE) + ":"
				+ calendario.get(Calendar.SECOND) + AM_PM;
		this.establecimiento = establecimiento;
		this.movimiento_tipo = movimiento_tipo;
		this.movimiento_desc = movimiento_desc;
		this.naturaleza = naturaleza;
		this.estado = estado;
		this.estado_desc = estado_desc;
		this.bolsillo = bolsillo;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getAutorizacion() {
		return autorizacion;
	}

	public void setAutorizacion(String autorizacion) {
		this.autorizacion = autorizacion;
	}

	public String getFecha() {
		return fecha;
	}

	public String getEstablecimiento() {
		return establecimiento;
	}

	public void setEstablecimiento(String establecimiento) {
		this.establecimiento = establecimiento;
	}

	public String getMovimiento_tipo() {
		return movimiento_tipo;
	}

	public void setMovimiento_tipo(String movimiento_tipo) {
		this.movimiento_tipo = movimiento_tipo;
	}

	public String getMovimiento_desc() {
		return movimiento_desc;
	}

	public void setMovimiento_desc(String movimiento_desc) {
		this.movimiento_desc = movimiento_desc;
	}

	public String getNaturaleza() {
		return naturaleza;
	}

	public void setNaturaleza(String naturaleza) {
		this.naturaleza = naturaleza;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getEstado_desc() {
		return estado_desc;
	}

	public void setEstado_desc(String estado_desc) {
		this.estado_desc = estado_desc;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getEmisor() {
		return emisor;
	}

	public void setEmisor(String emisor) {
		this.emisor = emisor;
	}

	public String getBolsillo() {
		return bolsillo;
	}

	public void setBolsillo(String bolsillo) {
		this.bolsillo = bolsillo;
	}

	public String getDescripcionMovimiento() {
		return descripcionMovimiento;
	}

	public void setDescripcionMovimiento(String descripcionMovimiento) {
		this.descripcionMovimiento = descripcionMovimiento;
	}

}
