package com.pexto.monedero.apidto.admin.vo;

import java.io.Serializable;
import java.util.Date;

public class TerminalVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String token;
	private String nombre;
	private String codigo;
	private String codigoTerminalRed;
	private String isDefault;
	private Date fecha;
	private String estado;
	private Long sucursalId;
	private String sucursalNombre;
	private Long usuarioAdminId;
	private String hash;
	
	public TerminalVO() {
		
	}
	
	public TerminalVO(Long id) {
		this.id = id;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}


	public Long getSucursalId() {
		return sucursalId;
	}

	public void setSucursalId(Long sucursalId) {
		this.sucursalId = sucursalId;
	}

	public Long getUsuarioAdminId() {
		return usuarioAdminId;
	}

	public void setUsuarioAdminId(Long usuarioAdminId) {
		this.usuarioAdminId = usuarioAdminId;
	}

	public String getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}

	public String getCodigoTerminalRed() {
		return codigoTerminalRed;
	}

	public void setCodigoTerminalRed(String codigoTerminalRed) {
		this.codigoTerminalRed = codigoTerminalRed;
	}

	public String getSucursalNombre() {
		return sucursalNombre;
	}

	public void setSucursalNombre(String sucursalNombre) {
		this.sucursalNombre = sucursalNombre;
	}
	
}
