package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class DatosAppV implements Serializable {

    private static final long serialVersionUID = 1L;
    private String id;
    private String estado;
    private String mensaje;
    private String data;
    private String numeroCuenta;
    private String fechaExpedicion;
    private Long idCuenta;
    private Long idCliente;
    private Long idBolsillo1;
    private Long idBolsillo2;
    private Long idBolsillo3;
    private Long idBolsillo4;
    private Long idBolsillo5;
    // Campos nuevos: 2020-12-07
    private String nombre1;
    private String nombre2;
    private String apellido1;
    private String apellido2;
    private String nombres;
    private String apellidos;
    private String tokenSession;
    private String documento;
    private String tipoDocumento;
    private String hashSesion;
    private String fechaBloqueo;
    private Integer intentosLogin;
    private String nombreComercio;
    private String nombreSucursal;
    private String nombreTerminal;
    private String tipoTransaccionCompraQR;
    private String tipoTransaccionRetiroQR;
    private String valor;
    private String email;
    private String celular;
    private String tokenTerminal;
    private String tokenComercio;
    private String tokenAutorizacion;
    // Campo nuevo: 2020-12-05
    private String nroReferido;
    private String idComercio;

    private ComercioAutorizacionAppV comercios[];
    private ComercioAutorizacionCompraAppV comercios_compra[];

    public String getNombreSucursal() {
        return nombreSucursal;
    }

    public String getFechaExpedicion() {
        return fechaExpedicion;
    }

    public void setFechaExpedicion(String fechaExpedicion) {
        this.fechaExpedicion = fechaExpedicion;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void setNombreSucursal(String nombreSucursal) {
        this.nombreSucursal = nombreSucursal;
    }

    public DatosAppV() {
        this.estado = "0";
        this.mensaje = "";
    }

    public ComercioAutorizacionAppV[] getComercios() {
        return comercios;
    }

    public void setComercios(ComercioAutorizacionAppV[] comercios) {
        this.comercios = comercios;
    }

    public String getFechaBloqueo() {
        return fechaBloqueo;
    }

    public void setFechaBloqueo(String fechaBloqueo) {
        this.fechaBloqueo = fechaBloqueo;
    }

    public Integer getIntentosLogin() {
        return intentosLogin;
    }

    public void setIntentosLogin(Integer intentosLogin) {
        this.intentosLogin = intentosLogin;
    }

    public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public Long getIdCuenta() {
        return idCuenta;
    }

    public void setIdCuenta(Long idCuenta) {
        this.idCuenta = idCuenta;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getTokenSession() {
        return tokenSession;
    }

    public void setTokenSession(String tokenSession) {
        this.tokenSession = tokenSession;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Long getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Long idCliente) {
        this.idCliente = idCliente;
    }

    public void setBolsillo(int i, Long idBolsillo) {
        if (i == 1) {
            this.setIdBolsillo1(idBolsillo);
        }
        if (i == 2) {
            this.setIdBolsillo2(idBolsillo);
        }
        if (i == 3) {
            this.setIdBolsillo3(idBolsillo);
        }
        if (i == 4) {
            this.setIdBolsillo4(idBolsillo);
        }
        if (i == 5) {
            this.setIdBolsillo5(idBolsillo);
        }
    }

    public Long getIdBolsillo1() {
        return idBolsillo1;
    }

    public void setIdBolsillo1(Long idBolsillo1) {
        this.idBolsillo1 = idBolsillo1;
    }

    public Long getIdBolsillo2() {
        return idBolsillo2;
    }

    public void setIdBolsillo2(Long idBolsillo2) {
        this.idBolsillo2 = idBolsillo2;
    }

    public Long getIdBolsillo3() {
        return idBolsillo3;
    }

    public void setIdBolsillo3(Long idBolsillo3) {
        this.idBolsillo3 = idBolsillo3;
    }

    public Long getIdBolsillo4() {
        return idBolsillo4;
    }

    public void setIdBolsillo4(Long idBolsillo4) {
        this.idBolsillo4 = idBolsillo4;
    }

    public Long getIdBolsillo5() {
        return idBolsillo5;
    }

    public void setIdBolsillo5(Long idBolsillo5) {
        this.idBolsillo5 = idBolsillo5;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getHashSesion() {
        return hashSesion;
    }

    public void setHashSesion(String hashSesion) {
        this.hashSesion = hashSesion;
    }

    public String getNombreComercio() {
        return nombreComercio;
    }

    public void setNombreComercio(String nombreComercio) {
        this.nombreComercio = nombreComercio;
    }

    public String getNombreTerminal() {
        return nombreTerminal;
    }

    public void setNombreTerminal(String nombreTerminal) {
        this.nombreTerminal = nombreTerminal;
    }

    public String getTipoTransaccionCompraQR() {
        return tipoTransaccionCompraQR;
    }

    public void setTipoTransaccionCompraQR(String tipoTransaccionCompraQR) {
        this.tipoTransaccionCompraQR = tipoTransaccionCompraQR;
    }

    public String getTipoTransaccionRetiroQR() {
        return tipoTransaccionRetiroQR;
    }

    public void setTipoTransaccionRetiroQR(String tipoTransaccionRetiroQR) {
        this.tipoTransaccionRetiroQR = tipoTransaccionRetiroQR;
    }

    public String getValor() {
        return valor;
    }

    public void setValor(String valor) {
        this.valor = valor;
    }

    public String getTokenTerminal() {
        return tokenTerminal;
    }

    public void setTokenTerminal(String tokenTerminal) {
        this.tokenTerminal = tokenTerminal;
    }

    public String getTokenComercio() {
        return tokenComercio;
    }

    public void setTokenComercio(String tokenComercio) {
        this.tokenComercio = tokenComercio;
    }

    public String getTokenAutorizacion() {
        return tokenAutorizacion;
    }

    public void setTokenAutorizacion(String tokenAutorizacion) {
        this.tokenAutorizacion = tokenAutorizacion;
    }

    public String getNroReferido() {
        return nroReferido;
    }

    public void setNroReferido(String nroReferido) {
        this.nroReferido = nroReferido;
    }

    public String getIdComercio() {
        return idComercio;
    }

    public void setIdComercio(String idComercio) {
        this.idComercio = idComercio;
    }

    public String getNombre1() {
        return nombre1;
    }

    public void setNombre1(String nombre1) {
        this.nombre1 = nombre1;
    }

    public String getNombre2() {
        return nombre2;
    }

    public void setNombre2(String nombre2) {
        this.nombre2 = nombre2;
    }

    public String getApellido1() {
        return apellido1;
    }

    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    public String getApellido2() {
        return apellido2;
    }

    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

	public ComercioAutorizacionCompraAppV[] getComercios_compra() {
		return comercios_compra;
	}

	public void setComercios_compra(ComercioAutorizacionCompraAppV[] comercios_compra) {
		this.comercios_compra = comercios_compra;
	}

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCelular() {
        return celular;
    }

    public void setCelular(String celular) {
        this.celular = celular;
    }

}
