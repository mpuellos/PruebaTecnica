package com.pexto.monedero.apidto.integrador.comfenalco;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class RespuestaClienteRequestV implements IRequestValidator, Serializable {
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("tipoDocumento")
	private String tipoDocumento;
	
	@JsonProperty("documento")
	private String numeroDocumento;
	
	@JsonProperty("idRegistro")
	private Long idRegistro;
	
	@JsonProperty("respuesta1")
	private String respuesta1;
	
	@JsonProperty("respuesta2")
	private String respuesta2;
	
	@JsonProperty("respuesta3")
	private String respuesta3;
	
	@JsonProperty("respuesta4")
	private String respuesta4;
	
	@JsonProperty("respuesta5")
	private String respuesta5;
	
	@JsonProperty("respuesta6")
	private String respuesta6;
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	public Long getIdRegistro() {
		return idRegistro;
	}

	public void setIdRegistro(Long idRegistro) {
		this.idRegistro = idRegistro;
	}

	public String getRespuesta1() {
		return respuesta1;
	}

	public void setRespuesta1(String respuesta1) {
		this.respuesta1 = respuesta1;
	}

	public String getRespuesta2() {
		return respuesta2;
	}

	public void setRespuesta2(String respuesta2) {
		this.respuesta2 = respuesta2;
	}

	public String getRespuesta3() {
		return respuesta3;
	}

	public void setRespuesta3(String respuesta3) {
		this.respuesta3 = respuesta3;
	}

	public String getRespuesta4() {
		return respuesta4;
	}

	public void setRespuesta4(String respuesta4) {
		this.respuesta4 = respuesta4;
	}

	public String getRespuesta5() {
		return respuesta5;
	}

	public void setRespuesta5(String respuesta5) {
		this.respuesta5 = respuesta5;
	}

	public String getRespuesta6() {
		return respuesta6;
	}

	public void setRespuesta6(String respuesta6) {
		this.respuesta6 = respuesta6;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((tipoDocumento == null) || (tipoDocumento.trim().length() == 0)
				|| (tipoDocumento.trim().length() != 1)) {
			throw new Exception ("El campo tipo de documento esta vacio o errado!");
		}
		
		if ((numeroDocumento == null) || (numeroDocumento.trim().length() == 0)
				|| (numeroDocumento.trim().length() > 15) || (!Parametros.validateOnlyDigits(numeroDocumento))) {
			throw new Exception ("El campo número de documento esta vacio o errado!");
		}
		
		if ((idRegistro == null) || (String.valueOf(idRegistro).trim().equals(""))) {
			throw new Exception ("El campo Id de Registro esta vacio o errado!");
		}
		
		return valid;
	}
}