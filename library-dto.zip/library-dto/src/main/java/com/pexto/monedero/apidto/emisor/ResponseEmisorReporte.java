package com.pexto.monedero.apidto.emisor;

import java.io.Serializable;

public class ResponseEmisorReporte implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long documentoEntidad;
	private String nombreEntidad;
	private Long idTipoTransaccion;
	private String nombreTipoTransaccion;
	private String descripcionTipoTransaccion;
	private Long idEstadoTransaccion;
	private String descripcionEstadoTransaccion;
	private Long idBolsillo;
	private String nombreBolsillo;
	private String descripcionBolsillo;
	private Long cantidad;
	private Double total;
	
	
	public ResponseEmisorReporte() {
		
	}
	public ResponseEmisorReporte(Long documentoEntidad, String nombreEntidad,Long idTipoTransaccion, String nombreTipoTransaccion,
			String descripcionTipoTransaccion, Long idEstadoTransaccion, String descripcionEstadoTransaccion,
			Long idBolsillo, String nombreBolsillo, String descripcionBolsillo, Long cantidad, Double total) {
		super();
		
		this.documentoEntidad = documentoEntidad;
		this.nombreEntidad = nombreEntidad;
		this.idTipoTransaccion = idTipoTransaccion;
		this.nombreTipoTransaccion = nombreTipoTransaccion;
		this.descripcionTipoTransaccion = descripcionTipoTransaccion;
		this.idEstadoTransaccion = idEstadoTransaccion;
		this.descripcionEstadoTransaccion = descripcionEstadoTransaccion;
		this.idBolsillo = idBolsillo;
		this.nombreBolsillo = nombreBolsillo;
		this.descripcionBolsillo = descripcionBolsillo;
		this.cantidad = cantidad;
		this.total = total;
	}
	public ResponseEmisorReporte(Long idTipoTransaccion, String nombreTipoTransaccion,
			String descripcionTipoTransaccion, Long idEstadoTransaccion, String descripcionEstadoTransaccion,
			Long idBolsillo, String nombreBolsillo, String descripcionBolsillo, Long cantidad, Double total) {
		super();
		this.idTipoTransaccion = idTipoTransaccion;
		this.nombreTipoTransaccion = nombreTipoTransaccion;
		this.descripcionTipoTransaccion = descripcionTipoTransaccion;
		this.idEstadoTransaccion = idEstadoTransaccion;
		this.descripcionEstadoTransaccion = descripcionEstadoTransaccion;
		this.idBolsillo = idBolsillo;
		this.nombreBolsillo = nombreBolsillo;
		this.descripcionBolsillo = descripcionBolsillo;
		this.cantidad = cantidad;
		this.total = total;
	}
	public Long getIdTipoTransaccion() {
		return idTipoTransaccion;
	}
	public void setIdTipoTransaccion(Long idTipoTransaccion) {
		this.idTipoTransaccion = idTipoTransaccion;
	}
	public String getNombreTipoTransaccion() {
		return nombreTipoTransaccion;
	}
	public void setNombreTipoTransaccion(String nombreTipoTransaccion) {
		this.nombreTipoTransaccion = nombreTipoTransaccion;
	}
	public String getDescripcionTipoTransaccion() {
		return descripcionTipoTransaccion;
	}
	public void setDescripcionTipoTransaccion(String descripcionTipoTransaccion) {
		this.descripcionTipoTransaccion = descripcionTipoTransaccion;
	}
	public Long getIdEstadoTransaccion() {
		return idEstadoTransaccion;
	}
	public void setIdEstadoTransaccion(Long idEstadoTransaccion) {
		this.idEstadoTransaccion = idEstadoTransaccion;
	}
	public String getDescripcionEstadoTransaccion() {
		return descripcionEstadoTransaccion;
	}
	public void setDescripcionEstadoTransaccion(String descripcionEstadoTransaccion) {
		this.descripcionEstadoTransaccion = descripcionEstadoTransaccion;
	}
	public Long getIdBolsillo() {
		return idBolsillo;
	}
	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}
	public String getNombreBolsillo() {
		return nombreBolsillo;
	}
	public void setNombreBolsillo(String nombreBolsillo) {
		this.nombreBolsillo = nombreBolsillo;
	}
	public String getDescripcionBolsillo() {
		return descripcionBolsillo;
	}
	public void setDescripcionBolsillo(String descripcionBolsillo) {
		this.descripcionBolsillo = descripcionBolsillo;
	}
	public Long getCantidad() {
		return cantidad;
	}
	public void setCantidad(Long cantidad) {
		this.cantidad = cantidad;
	}
	public Double getTotal() {
		return total;
	}
	public void setTotal(Double total) {
		this.total = total;
	}
	public Long getDocumentoEntidad() {
		return documentoEntidad;
	}
	public void setDocumentoEntidad(Long documentoEntidad) {
		this.documentoEntidad = documentoEntidad;
	}
	public String getNombreEntidad() {
		return nombreEntidad;
	}
	public void setNombreEntidad(String nombreEntidad) {
		this.nombreEntidad = nombreEntidad;
	}
	
	
}
