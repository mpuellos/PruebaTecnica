package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class ComercioAutorizadorIntegradorV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Date fecha;
	private String data;
	private String filler1;
	private String filler2;
	private String filler3;
	private String filler4;
	private String filler5;
	private String filler6;
	private String filler7;
	private String filler8;
	private String filler9;
	private String filler10;
	private String filler11;
	private String filler12;
	private String filler13;
	private String filler14;
	private String filler15;
	private String filler16;
	private String filler17;
	private String filler18;
	private String filler19;
	private String filler20;
	private Long idComercioAutorizador;

	public Long getId() {
		return id;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getData() {
		return data;
	}

	public String getFiller1() {
		return filler1;
	}

	public String getFiller2() {
		return filler2;
	}

	public String getFiller3() {
		return filler3;
	}

	public String getFiller4() {
		return filler4;
	}

	public String getFiller5() {
		return filler5;
	}

	public String getFiller6() {
		return filler6;
	}

	public String getFiller7() {
		return filler7;
	}

	public String getFiller8() {
		return filler8;
	}

	public String getFiller9() {
		return filler9;
	}

	public String getFiller10() {
		return filler10;
	}

	public String getFiller11() {
		return filler11;
	}

	public String getFiller12() {
		return filler12;
	}

	public String getFiller13() {
		return filler13;
	}

	public String getFiller14() {
		return filler14;
	}

	public String getFiller15() {
		return filler15;
	}

	public String getFiller16() {
		return filler16;
	}

	public String getFiller17() {
		return filler17;
	}

	public String getFiller18() {
		return filler18;
	}

	public String getFiller19() {
		return filler19;
	}

	public String getFiller20() {
		return filler20;
	}

	public Long getIdComercioAutorizador() {
		return idComercioAutorizador;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setData(String data) {
		this.data = data;
	}

	public void setFiller1(String filler1) {
		this.filler1 = filler1;
	}

	public void setFiller2(String filler2) {
		this.filler2 = filler2;
	}

	public void setFiller3(String filler3) {
		this.filler3 = filler3;
	}

	public void setFiller4(String filler4) {
		this.filler4 = filler4;
	}

	public void setFiller5(String filler5) {
		this.filler5 = filler5;
	}

	public void setFiller6(String filler6) {
		this.filler6 = filler6;
	}

	public void setFiller7(String filler7) {
		this.filler7 = filler7;
	}

	public void setFiller8(String filler8) {
		this.filler8 = filler8;
	}

	public void setFiller9(String filler9) {
		this.filler9 = filler9;
	}

	public void setFiller10(String filler10) {
		this.filler10 = filler10;
	}

	public void setFiller11(String filler11) {
		this.filler11 = filler11;
	}

	public void setFiller12(String filler12) {
		this.filler12 = filler12;
	}

	public void setFiller13(String filler13) {
		this.filler13 = filler13;
	}

	public void setFiller14(String filler14) {
		this.filler14 = filler14;
	}

	public void setFiller15(String filler15) {
		this.filler15 = filler15;
	}

	public void setFiller16(String filler16) {
		this.filler16 = filler16;
	}

	public void setFiller17(String filler17) {
		this.filler17 = filler17;
	}

	public void setFiller18(String filler18) {
		this.filler18 = filler18;
	}

	public void setFiller19(String filler19) {
		this.filler19 = filler19;
	}

	public void setFiller20(String filler20) {
		this.filler20 = filler20;
	}

	public void setIdComercioAutorizador(Long idComercioAutorizador) {
		this.idComercioAutorizador = idComercioAutorizador;
	}

}