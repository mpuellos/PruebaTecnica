package com.pexto.monedero.apidto.comercio.pcomercio;

import java.io.Serializable;
import java.sql.Date;

public class UsuarioComercioV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String token;
	private String logon;
	private String password;
	private Date vigencia;
	private String reporte;
	private Long idPersona;
	private Date fecha;
	private String estado;
	
	public Long getId() {
		return id;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public String getToken() {
		return token;
	}
	
	public String getLogon() {
		return logon;
	}
	
	public String getPassword() {
		return password;
	}
	
	public Date getVigencia() {
		return vigencia;
	}
	
	public String getReporte() {
		return reporte;
	}
	
	public Long getPersona() {
		return idPersona;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public void setToken(String token) {
		this.token = token;
	}
	
	public void setLogon(String logon) {
		this.logon = logon;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}
	
	public void setReporte(String reporte) {
		this.reporte = reporte;
	}
	
	public void setPersona(Long idPersona) {
		this.idPersona = idPersona;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
}
