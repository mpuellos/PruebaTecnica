package com.pexto.monedero.apidto.negocio;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

public class TransactionCompaniesDownloadBusinessVoucherRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "novedadId cannot be null")
    private int novedadId;

    public int getNovedadId() {
        return novedadId;
    }

    public void setNovedadId(int novedadId) {
        this.novedadId = novedadId;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }
}
