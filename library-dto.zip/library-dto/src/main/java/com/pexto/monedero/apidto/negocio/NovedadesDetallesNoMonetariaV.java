package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class NovedadesDetallesNoMonetariaV implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long Id;
	private String numeroCuenta;
	private double valor;
	private String consecutivo;
	private String numeroDocumento;
	private String nombres;
	private String apellidos;
	private String correo;
	private String estado;
	private String nit;
	private String fechaEnvio;
	private String codigoProducto;
	private String fechaNacimiento;
	private String fechaExpedicion;	
	private String codigoCausal;
	private String tipoDocumento;
	private String nombreArchivo;
	
	
	public NovedadesDetallesNoMonetariaV() {
		
	}
	
	public NovedadesDetallesNoMonetariaV(Long id, String numeroCuenta, double valor, String consecutivo,
			String numeroDocumento, String nombres, String apellidos, String correo, String estado,
			String nit, String fechaEnvio, String codigoProducto, String fechaNacimiento, String fechaExpedicion, String tipoDocumento, String codigoCausal) {
		super();
		Id = id;
		this.numeroCuenta = numeroCuenta;
		this.valor = valor;
		this.consecutivo = consecutivo;
		this.numeroDocumento = numeroDocumento;
		this.nombres = nombres;
		this.apellidos = apellidos;
		this.correo = correo;
		this.estado = estado;
		this.nit = nit;
		this.fechaEnvio = fechaEnvio;
		this.codigoProducto = codigoProducto;
		this.fechaNacimiento = fechaNacimiento;
		this.fechaExpedicion = fechaExpedicion;
		this.tipoDocumento = tipoDocumento;
		this.codigoCausal = codigoCausal;
	}
	
	public Long getId() {
		return Id;
	}
	
	public void setId(Long id) {
		Id = id;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public double getValor() {
		return valor;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public String getConsecutivo() {
		return consecutivo;
	}
	
	public void setConsecutivo(String consecutivo) {
		this.consecutivo = consecutivo;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	public String getNombres() {
		return nombres;
	}
	
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	
	public String getApellidos() {
		return apellidos;
	}
	
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	
	public String getCorreo() {
		return correo;
	}
	
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public String getNit() {
		return nit;
	}
	
	public void setNit(String nit) {
		this.nit = nit;
	}
	
	public String getFechaEnvio() {
		return fechaEnvio;
	}
	
	public void setFechaEnvio(String fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}
	
	public String getCodigoProducto() {
		return codigoProducto;
	}
	
	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}
	
	public String getFechaNacimiento() {
		return fechaNacimiento;
	}
	
	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	
	public String getFechaExpedicion() {
		return fechaExpedicion;
	}
	
	public void setFechaExpedicion(String fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public String getCodigoCausal() {
		return codigoCausal;
	}

	public void setCodigoCausal(String codigoCausal) {
		this.codigoCausal = codigoCausal;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
}
