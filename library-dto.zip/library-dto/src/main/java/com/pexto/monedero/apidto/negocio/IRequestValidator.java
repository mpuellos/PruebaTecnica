package com.pexto.monedero.apidto.negocio;

public interface IRequestValidator {
	
	public abstract boolean validateProperties() throws Exception;

}
