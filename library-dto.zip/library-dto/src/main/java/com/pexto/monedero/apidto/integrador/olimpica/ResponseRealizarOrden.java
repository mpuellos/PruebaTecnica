package com.pexto.monedero.apidto.integrador.olimpica;

import java.io.Serializable;

public class ResponseRealizarOrden implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String aufecharea;
	private String aufechav;
	private String nombreCliente;
	private String direccion;
	private String numeroDocumentoCliente;
	private String telefono;
	private String ciudad;
	private Long valor;
	private String nombre;
	private String numeroDocumento;
	private String observacion;
	private Long aunumtar;
	private String aucodiauto;
	private String email;
	private String tipoCreditoOrden;
	
	public String getAufecharea() {
		return aufecharea;
	}
	
	public void setAufecharea(String aufecharea) {
		this.aufecharea = aufecharea;
	}
	
	public String getAufechav() {
		return aufechav;
	}
	
	public void setAufechav(String aufechav) {
		this.aufechav = aufechav;
	}
	
	public String getNombreCliente() {
		return nombreCliente;
	}
	
	public void setNombreCliente(String nombreCliente) {
		this.nombreCliente = nombreCliente;
	}
	
	public String getDireccion() {
		return direccion;
	}
	
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	public String getNumeroDocumentoCliente() {
		return numeroDocumentoCliente;
	}
	
	public void setNumeroDocumentoCliente(String numeroDocumentoCliente) {
		this.numeroDocumentoCliente = numeroDocumentoCliente;
	}
	
	public String getTelefono() {
		return telefono;
	}
	
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	
	public String getCiudad() {
		return ciudad;
	}
	
	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}
	
	public Long getValor() {
		return valor;
	}
	
	public void setValor(Long valor) {
		this.valor = valor;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	public String getObservacion() {
		return observacion;
	}
	
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
	public Long getAunumtar() {
		return aunumtar;
	}
	
	public void setAunumtar(Long aunumtar) {
		this.aunumtar = aunumtar;
	}
	
	public String getAucodiauto() {
		return aucodiauto;
	}
	
	public void setAucodiauto(String aucodiauto) {
		this.aucodiauto = aucodiauto;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getTipoCreditoOrden() {
		return tipoCreditoOrden;
	}
	
	public void setTipoCreditoOrden(String tipoCreditoOrden) {
		this.tipoCreditoOrden = tipoCreditoOrden;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ResponseRealizarOrden [aufecharea=");
		builder.append(aufecharea);
		builder.append(", aufechav=");
		builder.append(aufechav);
		builder.append(", nombreCliente=");
		builder.append(nombreCliente);
		builder.append(", direccion=");
		builder.append(direccion);
		builder.append(", numeroDocumentoCliente=");
		builder.append(numeroDocumentoCliente);
		builder.append(", telefono=");
		builder.append(telefono);
		builder.append(", ciudad=");
		builder.append(ciudad);
		builder.append(", valor=");
		builder.append(valor);
		builder.append(", nombre=");
		builder.append(nombre);
		builder.append(", numeroDocumento=");
		builder.append(numeroDocumento);
		builder.append(", observacion=");
		builder.append(observacion);
		builder.append(", aunumtar=");
		builder.append(aunumtar);
		builder.append(", aucodiauto=");
		builder.append(aucodiauto);
		builder.append(", email=");
		builder.append(email);
		builder.append(", tipoCreditoOrden=");
		builder.append(tipoCreditoOrden);
		builder.append("]");
		return builder.toString();
	}
	
}
