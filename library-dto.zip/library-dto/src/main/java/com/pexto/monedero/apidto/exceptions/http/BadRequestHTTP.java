package com.pexto.monedero.apidto.exceptions.http;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.BAD_REQUEST)
public class BadRequestHTTP extends Exception {

    private static final long serialVersionUID = 1L;
    private static final Logger LOGGER = LoggerFactory.getLogger(BadRequestHTTP.class);

    public BadRequestHTTP() {
        super();
        LOGGER.info("Response Exception: " + this.toString());
    }

    public BadRequestHTTP(String message, Throwable cause, boolean enableSuppression,
                          boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
        LOGGER.info("Response Exception: " + this.toString());
    }

    public BadRequestHTTP(String message, Throwable cause) {
        super(message, cause, false, false);
        LOGGER.info("Response Exception: " + this.toString());
    }

    public BadRequestHTTP(String message) {
        super(message, null, false, false);
        LOGGER.info("Response Exception: " + this.toString());
    }

    public BadRequestHTTP(Throwable cause) {
        super(cause);
        LOGGER.info("Response Exception: " + this.toString());
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(BadRequestHTTP.class + "[message=");
        builder.append(this.getMessage() + ", cause=");
        builder.append(this.getCause() + ", suppressed=");
        builder.append(this.getSuppressed().toString() + ", stackTrace=");
        builder.append(this.getStackTrace().toString());
        builder.append("]");
        return builder.toString();
    }
}