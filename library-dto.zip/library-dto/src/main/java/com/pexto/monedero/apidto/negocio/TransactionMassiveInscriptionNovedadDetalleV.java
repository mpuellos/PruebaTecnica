package com.pexto.monedero.apidto.negocio;

import com.pexto.monedero.apidto.enterprises.options.TypeMethodOfPay;
import lombok.*;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class TransactionMassiveInscriptionNovedadDetalleV implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "name cannot be null")
    private String name;

    @NotNull(message = "lastName cannot be null")
    private String lastName;

    @NotNull(message = "documentType cannot be null")
    private String documentType;

    @NotNull(message = "documentNumber cannot be null")
    private String documentNumber;

    @NotNull(message = "contactPhone cannot be null")
    private String contactPhone;

    @NotNull(message = "email cannot be null")
    private String email;

    @NotNull(message = "account type ID cannot be null")
    private String accountTypeId;

    @NotNull(message = "bank code cannot be null")
    private String bankCode;

    @NotNull(message = "account number cannot be null")
    private String accountNumber;

    @NotNull(message = "account number cannot be null")
    private TypeMethodOfPay typeMethodOfPay;

    @NotNull(message = "expeditionDate cannot be null")
    private Date expeditionDate;

    @NotNull(message = "birthdayDate cannot be null")
    private Date birthdayDate;
}
