package com.pexto.monedero.apidto.enterprises;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnterpriseUserPost {

    String logon;
    Long idPerfil;
    String numeroDocumento;
    String nombres;
    String apellidos;
    String correo;
    String nroCelular;
    String cargo;
    String estado;

}
