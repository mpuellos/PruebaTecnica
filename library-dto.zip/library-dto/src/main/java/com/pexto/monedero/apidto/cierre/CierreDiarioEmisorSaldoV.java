package com.pexto.monedero.apidto.cierre;

public class CierreDiarioEmisorSaldoV {
	
	private String nitEmisor;
	private String tipoIdentificacionAfiliado;
	private String numeroIdentificacionAfiliado;
	private String numeroCuenta;
	private double saldoCuenta;
	private String codigoProducto;
	private String estadoCuenta;
	
	public CierreDiarioEmisorSaldoV(String nitEmisor, String tipoIdentificacionAfiliado,
			String numeroIdentificacionAfiliado, String numeroCuenta, String codigoProducto,
			String estadoCuenta, double saldoCuenta) {
		
		super();
		this.nitEmisor 						= nitEmisor;
		this.tipoIdentificacionAfiliado 	= tipoIdentificacionAfiliado;
		this.numeroIdentificacionAfiliado 	= numeroIdentificacionAfiliado;
		this.numeroCuenta 					= numeroCuenta;
		this.codigoProducto 				= codigoProducto;
		this.estadoCuenta 					= estadoCuenta;
		this.saldoCuenta 					= saldoCuenta;
	}

	public String getNitEmisor() {
		return nitEmisor;
	}
	
	public String getTipoIdentificacionAfiliado() {
		return tipoIdentificacionAfiliado;
	}
	
	public String getNumeroIdentificacionAfiliado() {
		return numeroIdentificacionAfiliado;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public double getSaldoCuenta() {
		return saldoCuenta;
	}
	
	public String getCodigoProducto() {
		return codigoProducto;
	}
	
	public String getEstadoCuenta() {
		return estadoCuenta;
	}
	
	public void setNitEmisor(String nitEmisor) {
		this.nitEmisor = nitEmisor;
	}
	
	public void setTipoIdentificacionAfiliado(String tipoIdentificacionAfiliado) {
		this.tipoIdentificacionAfiliado = tipoIdentificacionAfiliado;
	}
	
	public void setNumeroIdentificacionAfiliado(String numeroIdentificacionAfiliado) {
		this.numeroIdentificacionAfiliado = numeroIdentificacionAfiliado;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public void setSaldoCuenta(double saldoCuenta) {
		this.saldoCuenta = saldoCuenta;
	}
	
	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}
	
	public void setEstadoCuenta(String estadoCuenta) {
		this.estadoCuenta = estadoCuenta;
	}
	
}
