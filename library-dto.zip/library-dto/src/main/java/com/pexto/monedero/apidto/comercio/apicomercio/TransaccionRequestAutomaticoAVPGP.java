package com.pexto.monedero.apidto.comercio.apicomercio;

import java.io.Serializable;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.PGP;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionRequestAutomaticoAVPGP implements Serializable, IRequestValidator {
	
private static final long serialVersionUID = 1L;
	
	@JsonProperty("tokenComercio")
	private String tokenComercio;
	
	@JsonProperty("tokenTerminal")
	private String tokenTerminal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("valor")
	private String valor;
	
	@JsonProperty("otp")
	private String otp;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("fechaTransaccion")
	private String fechaTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	public String getTokenComercio() {
		return tokenComercio;
	}

	public String getTokenTerminal() {
		return tokenTerminal;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public String getValor() {
		return valor;
	}

	public String getOtp() {
		return otp;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public String getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}
	
	public void setTokenComercio(String tokenComercio) {
		this.tokenComercio = tokenComercio;
	}

	public void setTokenTerminal(String tokenTerminal) {
		this.tokenTerminal = tokenTerminal;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}
	
	public static TransaccionRequestAutomaticoAVPGP Encrypt(TransaccionRequestAutomaticoAEstandarV transaccionRequestAutomaticoAEstandarV, String idPublicKey) throws Exception {
		TransaccionRequestAutomaticoAVPGP transaccionRequestAutomaticoAVPGP = null;
		PGP pgp = new PGP();
		
		if (transaccionRequestAutomaticoAEstandarV == null) {
			throw new Exception("Error Encrypt [transaccionRequestAutomaticoAEstandarV - null]");
		}
		
		if (idPublicKey == null) {
			throw new Exception("Error Encrypt [idPublicKey - null]");
		}
		
		try {
			
			String tokenComercio 		= pgp.encrypt(transaccionRequestAutomaticoAEstandarV.getTokenComercio(),idPublicKey);
		    String tokenTerminal 		= pgp.encrypt(transaccionRequestAutomaticoAEstandarV.getTokenTerminal(), idPublicKey);
		    String otp 					= pgp.encrypt(transaccionRequestAutomaticoAEstandarV.getOtp(), idPublicKey); 
		    String numeroCuenta			= pgp.encrypt(transaccionRequestAutomaticoAEstandarV.getNumeroCuenta(), idPublicKey);
		    String valor				= pgp.encrypt(String.valueOf(transaccionRequestAutomaticoAEstandarV.getValor()), idPublicKey);
		    String tipoTransaccion		= pgp.encrypt(transaccionRequestAutomaticoAEstandarV.getTipoTransaccion(), idPublicKey);
		    String fechaTransaccion		= pgp.encrypt(Parametros.getFechaString(transaccionRequestAutomaticoAEstandarV.getFechaTransaccion()), idPublicKey);
		    String numeroAutorizacion	= null;
		    
		    if (transaccionRequestAutomaticoAEstandarV.getNumeroAutorizacion() == null) {
		    	numeroAutorizacion = pgp.encrypt("0", idPublicKey);//encriptamos con valor de 0
		    } else {
		    	numeroAutorizacion = pgp.encrypt(transaccionRequestAutomaticoAEstandarV.getNumeroAutorizacion(), idPublicKey);
		    }
		    
		    transaccionRequestAutomaticoAVPGP = new TransaccionRequestAutomaticoAVPGP();
		    
		    transaccionRequestAutomaticoAVPGP.setTokenComercio(tokenComercio);
		    transaccionRequestAutomaticoAVPGP.setTokenTerminal(tokenTerminal);
		    transaccionRequestAutomaticoAVPGP.setOtp(otp);
		    transaccionRequestAutomaticoAVPGP.setNumeroCuenta(numeroCuenta);
		    transaccionRequestAutomaticoAVPGP.setValor(valor);
		    transaccionRequestAutomaticoAVPGP.setTipoTransaccion(tipoTransaccion);
		    transaccionRequestAutomaticoAVPGP.setFechaTransaccion(fechaTransaccion);
		    transaccionRequestAutomaticoAVPGP.setNumeroAutorizacion(numeroAutorizacion);
			
		} catch (Exception exc) {
			throw new Exception("Error encriptando la trama enviada: " + exc.getMessage());
		}
		
		return transaccionRequestAutomaticoAVPGP;
	}
	
	public static TransaccionRequestAutomaticoAEstandarV Decrypt(TransaccionRequestAutomaticoAVPGP transaccionRequestAutomaticoAVPGP, String passphrase) throws Exception {
		TransaccionRequestAutomaticoAEstandarV transaccionRequestAutomaticoAEstandarV = null;
		PGP pgp = new PGP();
		
		if (transaccionRequestAutomaticoAVPGP == null) {
			throw new Exception("Error Decrypt [transaccionRequestAutomaticoAVPGP - null]");
		}
		
		if (passphrase == null) {
			throw new Exception("Error Decrypt [Passphrase - null]");
		}
		
		try {
			
			String tokenComercio 		= pgp.decrypt(transaccionRequestAutomaticoAVPGP.getTokenComercio(), passphrase);
		    String tokenTerminal 		= pgp.decrypt(transaccionRequestAutomaticoAVPGP.getTokenTerminal(), passphrase);
		    String otp 					= pgp.decrypt(transaccionRequestAutomaticoAVPGP.getOtp(), passphrase); 
		    String numeroCuenta			= pgp.decrypt(transaccionRequestAutomaticoAVPGP.getNumeroCuenta(), passphrase);
		    String valor				= pgp.decrypt(transaccionRequestAutomaticoAVPGP.getValor(), passphrase);
		    String tipoTransaccion		= pgp.decrypt(transaccionRequestAutomaticoAVPGP.getTipoTransaccion(), passphrase);
		    String fechaTransaccionStr	= pgp.decrypt(transaccionRequestAutomaticoAVPGP.getFechaTransaccion(), passphrase);
		    String numeroAutorizacion	= null;
		    
		    if (transaccionRequestAutomaticoAVPGP.getNumeroAutorizacion() == null) {
		    	numeroAutorizacion	= "0";
		    } else {
		    	numeroAutorizacion	= pgp.decrypt(transaccionRequestAutomaticoAVPGP.getNumeroAutorizacion(), passphrase);
		    }
		    
		    SimpleDateFormat dateFormat 			= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    transaccionRequestAutomaticoAEstandarV	= new TransaccionRequestAutomaticoAEstandarV();
		    
		    transaccionRequestAutomaticoAEstandarV.setTokenComercio(tokenComercio);
		    transaccionRequestAutomaticoAEstandarV.setTokenTerminal(tokenTerminal);
		    transaccionRequestAutomaticoAEstandarV.setOtp(otp);
		    transaccionRequestAutomaticoAEstandarV.setNumeroCuenta(numeroCuenta);
		    transaccionRequestAutomaticoAEstandarV.setValor(Double.parseDouble(valor));
		    transaccionRequestAutomaticoAEstandarV.setTipoTransaccion(tipoTransaccion);
		    transaccionRequestAutomaticoAEstandarV.setFechaTransaccion(dateFormat.parse(fechaTransaccionStr));
		    transaccionRequestAutomaticoAEstandarV.setNumeroAutorizacion(numeroAutorizacion);
			
		} catch (Exception exc) {
			throw new Exception("Error desencriptando la trama enviada: " + exc.getMessage());
		}
		
		return transaccionRequestAutomaticoAEstandarV;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		//VALIDATION NULL
		
		if (this.tokenComercio == null) {
			throw new Exception("TokenComercio - null!");
		}
		
		if (this.tokenTerminal == null) {
			throw new Exception("TokenTerminal - null!");
		}
		
		if (this.otp == null) {
			throw new Exception("OTP - null!");
		}
		
		if (this.numeroCuenta == null) {
			throw new Exception("Numero de cuenta - null!");
		}
		
		if (this.valor == null) {
			throw new Exception("Valor - null!");
		}
		
		if (this.tipoTransaccion == null) {
			throw new Exception("TipoTransaccion - null!");
		}
		
		if (this.fechaTransaccion == null) {
			throw new Exception("FechaTransaccion - null!");
		}
		
		//VALIDATION EMPTY
    	if (String.valueOf(this.tokenComercio).equals("")) {
    		throw new Exception("TokenComercio vacio!");
		}
    	
    	if (String.valueOf(this.tokenTerminal).equals("")) {
    		throw new Exception("TokenTerminal vacio!");
		}
    	
    	if (this.otp.equals("")) {
    		throw new Exception("OTP vacio!");
		}
    	
    	if (this.valor.equals("")) {
    		throw new Exception("Valor vacio!");
    	}
    	
    	if (this.numeroCuenta.equals("")) {
    		throw new Exception("Numero de cuenta vacio!");
    	}
    	
    	if (this.tipoTransaccion.equals("")) {
    		throw new Exception("Tipo Transaccion vacio!");
    	}
    	
    	return valid;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TransaccionRequestAutomaticoAVPGP [tokenComercio=");
		builder.append(tokenComercio);
		builder.append(", tokenTerminal=");
		builder.append(tokenTerminal);
		builder.append(", numeroCuenta=");
		builder.append(numeroCuenta);
		builder.append(", valor=");
		builder.append(valor);
		builder.append(", otp=");
		builder.append(otp);
		builder.append(", tipoTransaccion=");
		builder.append(tipoTransaccion);
		builder.append(", fechaTransaccion=");
		builder.append(fechaTransaccion);
		builder.append(", numeroAutorizacion=");
		builder.append(numeroAutorizacion);
		builder.append("]");
		return builder.toString();
	}
}
