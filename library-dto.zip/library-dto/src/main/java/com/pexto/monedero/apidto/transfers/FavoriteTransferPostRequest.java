package com.pexto.monedero.apidto.transfers;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FavoriteTransferPostRequest {

    FavoriteTransferPostRequest.Client client;
    FavoriteTransferPostRequest.Bank bank;
    FavoriteTransferPostRequest.Beneficiary beneficiary;
    FavoriteTransferPostRequest.Account account;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public class Client {
        String typeId;
        String numberId;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public class Bank {
        String bankId;
        String accountTypeId;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public class Beneficiary {
        String typeId;
        String numberId;
        String name;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    public class Account {
        String name;
        String number;
    }

}
