package com.pexto.monedero.apidto.route53.Request;

public class ListRequestRoute53 {
    private String StartRecordType;
    private String StartRecordName;

    public String getStartRecordType() {
        return StartRecordType;
    }

    public void setStartRecordType(String startRecordType) {
        StartRecordType = startRecordType;
    }

    public String getStartRecordName() {
        return StartRecordName;
    }

    public void setStartRecordName(String startRecordName) {
        StartRecordName = startRecordName;
    }

}
