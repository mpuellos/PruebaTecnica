package com.pexto.monedero.apidto.comercio.apicomercio;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.core.ParamRequestV;
import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionRequestAutomaticoAEstandarV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("tokenComercio")
	private String tokenComercio;
	
	@JsonProperty("tokenTerminal")
	private String tokenTerminal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("valor")
	private double valor;
	
	@JsonProperty("otp")
	private String otp;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("fechaTransaccion")
	private Date fechaTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("paramRequest")
	private ParamRequestV paramRequest;
	
	public TransaccionRequestAutomaticoAEstandarV() {
		this.tokenComercio 		= null;
		this.tokenTerminal 		= null;
		this.numeroCuenta 		= null;
		this.valor 				= 0;
		this.otp 				= null;
		this.tipoTransaccion 	= null;
		this.fechaTransaccion	= new Date();
		this.numeroAutorizacion	= "0";
	}
	
	public String getTokenComercio() {
		return tokenComercio;
	}

	public String getTokenTerminal() {
		return tokenTerminal;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public double getValor() {
		return valor;
	}

	public String getOtp() {
		return otp;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public void setTokenComercio(String tokenComercio) {
		this.tokenComercio = tokenComercio;
	}

	public void setTokenTerminal(String tokenTerminal) {
		this.tokenTerminal = tokenTerminal;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}
	
	public ParamRequestV getParamRequest() {
		return paramRequest;
	}

	public void setParamRequest(ParamRequestV paramRequest) {
		this.paramRequest = paramRequest;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		//VALIDATION NULL
		
		if (this.tokenComercio == null || this.tokenComercio.equals("")) {
			throw new Exception("TokenComercio - null o vacio!");
		}
		
		if (this.tokenTerminal == null || this.tokenTerminal.equals("")) {
			throw new Exception("TokenTerminal - null o vacio!!");
		}
		
		if (this.numeroCuenta == null || this.numeroCuenta.equals("")) {
			throw new Exception("Numero de cuenta - null o vacio!!");
		}
		
		if (this.otp == null || this.otp.equals("")) {
			throw new Exception("OTP - null o vacio!!");
		}
		
		if (this.tipoTransaccion == null || this.tipoTransaccion.equals("")) {
			throw new Exception("TipoTransaccion - null!");
		}
		
		if (this.fechaTransaccion == null) {
			throw new Exception("FechaTransaccion - null o vacio!!");
		}
		
    	if (String.valueOf(this.valor).equals("")) {
    		throw new Exception("Valor vacio!");
    	}
    	
    	//VALIDATION DATA_VALUES
    	
    	//validate_ValorPositivo
    	if (this.valor <= 0) {
    		throw new Exception("Ingrese un valor correcto!");
    	}
    	
    	//validate_tipoTransaccionCompraRetiro
    	if (!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_COMPRA) &&
    			!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_RETIRO) &&
    				!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_COMPRA) &&
    					!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_RETIRO)) {
    		
    		throw new Exception("Ingrese un tipo de transaccion correcto!");
    	}
		
		return valid;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TransaccionRequestAutomaticoAEstandarV [tokenComercio=");
		builder.append(tokenComercio);
		builder.append(", tokenTerminal=");
		builder.append(tokenTerminal);
		builder.append(", numeroCuenta=");
		builder.append(numeroCuenta);
		builder.append(", valor=");
		builder.append(valor);
		builder.append(", otp=");
		builder.append(otp);
		builder.append(", tipoTransaccion=");
		builder.append(tipoTransaccion);
		builder.append(", fechaTransaccion=");
		builder.append(fechaTransaccion);
		builder.append(", numeroAutorizacion=");
		builder.append(numeroAutorizacion);
		builder.append(", paramRequest=");
		builder.append(paramRequest);
		builder.append("]");
		return builder.toString();
	}
	
}
