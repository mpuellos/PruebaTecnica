package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class NovedadACuentaUnitarioRequestV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private String tipoDocumento;
	private String numeroDocumento;
	private String numeroCuenta;
	private String codigoProducto;
	private double valor;
	private String tipoOperacion;
	private String tipoNovedad;
	private Long idEmisor;
	private Long idBolsillo;
	private Long idUsuarioEmisor;
	private String ipOrigen;
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public double getValor() {
		return valor;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public Long getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public void setIdUsuarioEmisor(Long idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	@Override
	public boolean validateProperties() throws Exception {
		//VALIDATION_NULL
		
		if (this.numeroDocumento == null || this.numeroDocumento.equals("")) {
			throw new Exception("Error en el campo Numero de Documento is null!");
		}else {
			if (!Parametros.validateOnlyDigits(numeroDocumento)) {
				throw new Exception ("Error en el campo Número de Documento, valor errado: " + numeroDocumento);
			}
			
			Long numeroDocumentoLong = Long.parseLong(numeroDocumento);
			
			if (numeroDocumentoLong <= 0) {
				throw new Exception ("Error en el registro - campo Numero de Documento, valor inferior o igual a 0: " + numeroDocumento);
			}
		}
		
		if (this.tipoDocumento == null || this.tipoDocumento.equals("")) {
			throw new Exception("Tipo de documento - null!");
		}else {
			if (!Parametros.validateOnlyDigits(tipoDocumento)) {
				throw new Exception ("Error en el campo Tipo de Documento, valor errado: " + numeroDocumento);
			}
		}
		
		if (this.numeroCuenta == null || this.numeroCuenta.equals("")) {
			throw new Exception("Número de cuenta - null!");
		}else {
			if (!Parametros.validateOnlyDigits(numeroCuenta)) {
				throw new Exception ("Error en el campo Numero de Cuenta, valor errado: " + numeroCuenta);
			}
			
			Long numeroCuentaLong = Long.parseLong(numeroCuenta);
			
			if (numeroCuentaLong <= 0) {
				throw new Exception ("Error en el campo Numero de Cuenta, valor errado, valor inferior o igual a 0: " + numeroCuenta);
			}
		}
		
		if (this.idEmisor == null || String.valueOf(this.idEmisor).equals("")) {
			throw new Exception("Error en el campo Id Emisor - null!");
		}
		
		if (this.idUsuarioEmisor == null || String.valueOf(this.idUsuarioEmisor).equals("")) {
			throw new Exception("Error en el campo Id Usuario Emisor - null!");
		}
		
		if (this.idBolsillo == null || String.valueOf(this.idBolsillo).equals("")) {
			throw new Exception("Error en el campo Id Bolsillo - null!");
		}
		
		if (this.valor <= 0) {
			throw new Exception ("Error en el campo Valor, valor inferior o igual a 0: " + this.valor);
		}
		
		return true;
	}
	
}
