package com.pexto.monedero.apidto.negocio;

import java.util.Collection;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@AllArgsConstructor
public class TransfersExternalBankRequest {

  @NotNull(message = "object client cannot be null")
  private Client client;

  @NotNull(message = "object beneficiary cannot be null")
  private Beneficiary beneficiary;

  @NotNull(message = "object workplaceBank cannot be null")
  private WorkplaceBank workplaceBank;

  @NotNull(message = "object workplaceBank cannot be null")
  private Notifications notifications;

  @Value
  @Builder
  @AllArgsConstructor
  public static class Client {

    @NotNull(message = "typeId of the client cannot be null")
    private String typeId;

    @NotNull(message = "numberId of the client cannot be null") 
    private String numberId;

    @NotNull(message = "name of the client cannot be null")
    private String name;

    @NotNull(message = "name of the client cannot be null")
    private String surname;

    @NotNull(message = "email of the client cannot be null")
    private String email;

    @NotNull(message = "cellphoneNumber of the client cannot be null")
    private String cellphoneNumber;

    @NotNull(message = "accountNumber of the client cannot be null")
    private String accountNumber;

    @NotNull(message = "birthday of the client cannot be null")
    private String birthday;

    @NotNull(message = "expeditionDate of the client cannot be null")
    private String expeditionDate;

    @NotNull(message = "walletId of the client cannot be null")
    private String walletId;
  }

  @Value
  @Builder
  @AllArgsConstructor
  public static class Beneficiary {

    @NotNull(message = "name of the beneficiary cannot be null")
    private String name;

    @NotNull(message = "typeId of the beneficiary cannot be null")
    private String typeId;

    @NotNull(message = "numberId of the beneficiary cannot be null")
    private String numberId;

    @NotNull(message = "bankAccountTypeId of the beneficiary cannot be null")
    private String bankAccountTypeId;

    @NotNull(message = "bankId of the beneficiary cannot be null")
    private String bankId;

    @NotNull(message = "accountNumber of the beneficiary cannot be null")
    private String accountNumber;

    @NotNull(message = "amount of the beneficiary cannot be null")
    private String amount;
  }

  @Value
  @Builder
  @AllArgsConstructor
  public static class WorkplaceBank {

    @NotNull(message = "code of the workplaceBank cannot be null")
    private String code;

    @NotNull(message = "authorizationNumber of the workplaceBank cannot be null")
    private String authorizationNumber;

    @NotNull(message = "transactionHash of the workplaceBank cannot be null")
    private String transactionHash;

    @NotNull(message = "transactionUuid of the workplaceBank cannot be null")
    private String transactionUuid;
  }

  @Value
  @Builder
  @AllArgsConstructor
  public static class Notifications {

    @NotNull(message = "object email cannot be null")
    private NotificationEmail email;

    @Value
    @Builder
    @AllArgsConstructor
    public static class NotificationEmail {
      @NotNull(message = "from email cannot be null")
      private String from;

      @NotNull(message = "to email or emails of the client cannot be null")
      private Collection<String> collectionTo;

      @NotNull(message = "subject cannot be null")
      private String subject;

      @NotNull(message = "content cannot be null")
      private String content;

      @NotNull(message = "template cannot be null")
      private String template;

      @NotNull(message = "object model cannot be null")
      private NotificationEmailModel model;


      @Value
      @Builder
      @AllArgsConstructor
      public static class NotificationEmailModel {
        @NotNull(message = "clientName cannot be null")
        private String clientName;

        @NotNull(message = "clientNumberId cannot be null")
        private String clientNumberId;

        @NotNull(message = "clientType cannot be null")
        private String clientType;

        @NotNull(message = "clientCellphoneNumber cannot be null")
        private String clientCellphoneNumber;

        @NotNull(message = "beneficiaryName cannot be null")
        private String beneficiaryName;

        @NotNull(message = "beneficiaryTypeId cannot be null")
        private String beneficiaryTypeId;

        @NotNull(message = "beneficiaryNumberId cannot be null")
        private String beneficiaryNumberId;

        @NotNull(message = "beneficiaryNameBank cannot be null")
        private String beneficiaryNameBank;

        @NotNull(message = "beneficiaryNameBankAccountType cannot be null")
        private String beneficiaryNameBankAccountType;

        @NotNull(message = "beneficiaryAccountNumber cannot be null")
        private String beneficiaryAccountNumber;

        @NotNull(message = "amount cannot be null")
        private String amount;

        @NotNull(message = "workplaceBankCode cannot be null")
        private String workplaceBankCode;
      }
    }
  }
}
