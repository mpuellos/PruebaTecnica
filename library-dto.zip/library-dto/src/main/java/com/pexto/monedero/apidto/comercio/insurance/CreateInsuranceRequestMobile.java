package com.pexto.monedero.apidto.comercio.insurance;

import java.net.InetAddress;
import java.net.UnknownHostException;
import javax.servlet.http.HttpServletRequest;
import com.pexto.monedero.apidto.core.ParamRequestV;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder=true)
public class CreateInsuranceRequestMobile {

    private static final String LOCAL_IP = "127.0.0.1";

    String providerId;
    String productId;
    String workplaceBankCode;
    String insuranceTypeId;
    String insurancePlan;
    String insurancePaymentMode;
    String startInsuranceDate;
    Integer insuranceValue;
    String insuredGender;
    String clientDocumentType;
    String clientDocumentNumber;
    String clientAccountNumber;
    String clientEmail;
    Boolean isPayWithPoints;
    Double purchaseAmount;
    Long workplaceBankWalletId;
    Double walletPurchaseAmount;
    Long cobreWalletId;
    Double cobrePurchaseAmount;
    String insuredCity;
    String insuredAddress;
    Boolean isPersonalDataAuthorization;
    Boolean isEmailAuthorization;
    Boolean isSmsAuthorization;

    ParamRequestV paramRequestV;

    public ParamRequestV setIpSRequest(HttpServletRequest request) {
        String remoteAddr = "", ipLocal = "";
        ParamRequestV pRequestV = new ParamRequestV();
        pRequestV.setUserAgent(request.getHeader("User-Agent"));
        if (request != null) {
            ipLocal = request.getRemoteAddr();
            remoteAddr = request.getHeader("X-FORWARDED-FOR");

            if (remoteAddr == null || "".equals(remoteAddr)) {
                remoteAddr = ipLocal;
            }
        }
        InetAddress IP;
        try {
            IP = InetAddress.getLocalHost();
            pRequestV.setIpLocal(IP.getHostAddress());
            pRequestV.setIpOrigen(remoteAddr);
        } catch (UnknownHostException e1) {
        	pRequestV.setIpLocal(LOCAL_IP);
        	pRequestV.setIpOrigen(LOCAL_IP);
            e1.printStackTrace();
        }
        return pRequestV;
    }
}
