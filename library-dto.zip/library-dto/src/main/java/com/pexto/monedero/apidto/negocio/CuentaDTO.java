package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CuentaDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String uuid;
	private String numeroCuentaHash;
	private String numeroCuenta;
	private Date fecha;
	private String estado;
	private Long idCliente;
	private Date fechaBloqueo;
	private Long intentosLogin;
	
	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public String getNumeroCuentaHash() {
		return numeroCuentaHash;
	}
	
	public void setNumeroCuentaHash(String numeroCuentaHash) {
		this.numeroCuentaHash = numeroCuentaHash;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Long getIdCliente() {
		return idCliente;
	}
	
	public void setIdCliente(Long idCliente) {
		this.idCliente = idCliente;
	}
	
	public Date getFechaBloqueo() {
		return fechaBloqueo;
	}
	
	public void setFechaBloqueo(Date fechaBloqueo) {
		this.fechaBloqueo = fechaBloqueo;
	}
	
	public Long getIntentosLogin() {
		return intentosLogin;
	}
	
	public void setIntentosLogin(Long intentosLogin) {
		this.intentosLogin = intentosLogin;
	}

    public CuentaDTO() {
    }

    public CuentaDTO(String uuid, String numeroCuenta) {
        this.uuid = uuid;
        this.numeroCuenta = numeroCuenta;
    }

    
}
