package com.pexto.monedero.apidto.admin.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class RequestPostAdminLogin implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("logon")
	private String logon;
	
	@JsonProperty("password")
	private String password;
	
	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((this.logon == null) || (this.logon.trim().equals(""))) {
			throw new Exception ("Logon esta vacio o errado!");
		}
		
		if ((this.password == null) || (this.password.trim().equals(""))) {
			throw new Exception ("Password esta vacio o errado!");
		}
		
		return valid;
	}	
}