package com.pexto.monedero.apidto.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@AllArgsConstructor
public class DebitAccountRequest {
    String commerceToken;
    String terminalToken;
    String authorization;
    Long userCommerceId;
    String accountNumber;
    Double value;
    String transactionType;
    String transactionDate;
    Long walletId;
    String authorizationNumber;
    String description;
    String otp;
    String localIp;
    String originIp;
    String origin;
    String transactionOrigin;
    String transactionInfo;
    String userAgent;
    String checksum;
}
