package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class NovedadRegistroRequestV implements Serializable, IRequestValidator {

	private static final long serialVersionUID = 1L;

	/*
	 * Nuevos atributos para la super APP, con esto podemos identificar el registro
	 * de que emisor corresponde
	 */
	private Long idEmisor;
	private String tokenEmisor;

	private String ipOrigen;
	private String tipoDocumento;
	private String numeroDocumento;
	private String nombre1;
	private String nombre2;
	private String apellido1;
	private String apellido2;
	private String numeroCelular;
	private String correoElectronico;
	private String fechaNacimiento;
	private String fechaExpedicion;
	private String numeroOtp;

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getTokenEmisor() {
		return tokenEmisor;
	}

	public void setTokenEmisor(String tokenEmisor) {
		this.tokenEmisor = tokenEmisor;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombre1() {
		return nombre1;
	}

	public void setNombre1(String nombre1) {
		this.nombre1 = nombre1;
	}

	public String getNombre2() {
		return nombre2;
	}

	public void setNombre2(String nombre2) {
		this.nombre2 = nombre2;
	}

	public String getApellido1() {
		return apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(String fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getNumeroOtp() {
		return numeroOtp;
	}

	public void setNumeroOtp(String numeroOtp) {
		this.numeroOtp = numeroOtp;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((ipOrigen == null) || (ipOrigen.trim().length() == 0)) {
			throw new Exception("El campo Ip Origen esta vacio!");
		}

		if ((tipoDocumento == null) || (tipoDocumento.trim().length() == 0) || (tipoDocumento.trim().length() != 1)) {
			throw new Exception("El campo tipo de documento esta vacio o errado!");
		}

		if ((numeroDocumento == null) || (numeroDocumento.trim().length() == 0)
				|| (numeroDocumento.trim().length() > 15) || (!Parametros.validateOnlyDigits(numeroDocumento))) {
			throw new Exception("El campo número de documento esta vacio o errado!");
		}

		if ((nombre1 == null) || (nombre1.trim().length() == 0) || (nombre1.trim().length() > 20)) {
			throw new Exception("El campo primer nombre esta vacio o errado!");
		}

		if ((apellido1 == null) || (apellido1.trim().length() == 0) || (apellido1.trim().length() > 20)) {
			throw new Exception("El campo primer apellido esta vacio o errado!");
		}

		if ((fechaNacimiento == null) || (fechaNacimiento.trim().length() == 0) || (fechaNacimiento.length() != 8)
				|| (!Parametros.validateOnlyDigits(fechaNacimiento))) {
			throw new Exception("El campo fecha de nacimiento esta vacio o errado!");
		}

		if ((fechaExpedicion == null) || (fechaExpedicion.trim().length() == 0) || (fechaExpedicion.length() != 8)
				|| (!Parametros.validateOnlyDigits(fechaExpedicion))) {
			throw new Exception("El campo fecha de expedición esta vacio o errado!");
		}

		if ((numeroOtp != null) && (numeroOtp.length() != 6) && (!Parametros.validateOnlyDigits(numeroOtp))) {
			throw new Exception("El campo número OTP esta errado!");
		}

		return valid;
	}

}