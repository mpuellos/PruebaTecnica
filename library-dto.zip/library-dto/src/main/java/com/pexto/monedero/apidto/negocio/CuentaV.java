package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class CuentaV implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String numeroCuenta;
	private String numeroCuentaDestino;//Solo para transferencias
	private String pin;
	private Long idbolsillo;
	private String codigoBolsillo;
	private double valor;
	private String tipoTransaccion;//C=Compra R=Retiro
	private String idEmisor;
	private String idUsuarioEmisor;
	private String bloqueo;
	private String token;
	private String uuid;
	private String idComercio;	
	private String idTerminal;
	
	public double getValor() {
		return valor;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public String getNumeroCuenta() {
		return this.numeroCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public String getPin() {
		return pin;
	}
	
	public void setPin(String pin) {
		this.pin = pin;
	}
	
	public Long getIdbolsillo() {
		return idbolsillo;
	}
	
	public void setIdbolsillo(Long idbolsillo) {
		this.idbolsillo = idbolsillo;
	}
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	public String getNumeroCuentaDestino() {
		return numeroCuentaDestino;
	}
	
	public void setNumeroCuentaDestino(String numeroCuentaDestino) {
		this.numeroCuentaDestino = numeroCuentaDestino;
	}
	
	public String getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public String getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}
	
	public void setIdUsuarioEmisor(String idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}
	
	public String getCodigoBolsillo() {
		return codigoBolsillo;
	}
	
	public void setCodigoBolsillo(String codigoBolsillo) {
		this.codigoBolsillo = codigoBolsillo;
	}

	public String getBloqueo() {
		return bloqueo;
	}

	public void setBloqueo(String bloqueo) {
		this.bloqueo = bloqueo;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(String idComercio) {
		this.idComercio = idComercio;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getIdTerminal() {
		return idTerminal;
	}

	public void setIdTerminal(String idTerminal) {
		this.idTerminal = idTerminal;
	}
	
	
}
