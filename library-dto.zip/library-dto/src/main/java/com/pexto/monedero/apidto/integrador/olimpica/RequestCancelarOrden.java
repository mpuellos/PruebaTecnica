package com.pexto.monedero.apidto.integrador.olimpica;

import java.io.Serializable;

public class RequestCancelarOrden implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String aunumtar;
	private String aucodiauto;
	private String observacion;
	
	public String getAunumtar() {
		return aunumtar;
	}
	
	public void setAunumtar(String aunumtar) {
		this.aunumtar = aunumtar;
	}
	
	public String getAucodiauto() {
		return aucodiauto;
	}
	
	public void setAucodiauto(String aucodiauto) {
		this.aucodiauto = aucodiauto;
	}
	
	public String getObservacion() {
		return observacion;
	}
	
	public void setObservacion(String observacion) {
		this.observacion = observacion;
	}
	
}
