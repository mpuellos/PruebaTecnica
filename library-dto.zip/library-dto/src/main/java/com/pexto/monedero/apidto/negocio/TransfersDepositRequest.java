package com.pexto.monedero.apidto.negocio;

import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@AllArgsConstructor
public class TransfersDepositRequest {

  @NotNull(message = "object beneficiary cannot be null")
  private Beneficiary beneficiary;

  @NotNull(message = "object client cannot be null")
  private Client client;

  @NotNull(message = "amount cannot be null")
  private Double amount;

  @NotNull(message = "walletId cannot be null")
  private String walletId;

  @Value
  @Builder
  @AllArgsConstructor
  public static class Beneficiary {

    @NotNull(message = "bankId cannot be null")
    private String bankId;

    @NotNull(message = "nameBank cannot be null")
    private String nameBank;

    @NotNull(message = "bankAccountTypeId cannot be null")
    private String bankAccountTypeId;

    @NotNull(message = "nameBankAccountType cannot be null")
    private String nameBankAccountType;

    @NotNull(message = "accountNumber cannot be null")
    private String accountNumber;

    @NotNull(message = "name cannot be null")
    private String name;

    @NotNull(message = "typeId cannot be null")
    private String typeId;

    @NotNull(message = "numberId cannot be null")
    private String numberId;
  }

  @Value
  @Builder
  @AllArgsConstructor
  public static class Client {

    @NotNull(message = "numberId cannot be null")
    private String numberId;

    @NotNull(message = "client type cannot be null")
    private String typeId;
  }
}
