package com.pexto.monedero.apidto.admin.request;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class RequestPutUsuarioComercio implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("id")
	private Long id;
	
	@JsonProperty("uuid")
	private String uuid;
	
	@JsonProperty("token")
	private String token;
	
	@JsonProperty("tokenFirebase")
	private String tokenFirebase;
	
	@JsonProperty("logon")
	private String logon;
	
	@JsonProperty("password")
	private String password;
	
	@JsonProperty("vigencia")
	private String vigencia;
	
	@JsonProperty("reporte")
	private String reporte;
	
	@JsonProperty("isCambioClave")
	private String isCambioClave;
	
	@JsonProperty("fechaCambioClave")
	private Date fechaCambioClave;
	
	@JsonProperty("fecha")
	private Date fecha;
	
	@JsonProperty("estado")
	private String estado;
	
	@JsonProperty("idPersona")
	private Long idPersona;
	
	@JsonProperty("idPerfil")
	private Long idPerfil;
	
	@JsonProperty("idComercio")
	private Long idComercio;
	
	@JsonProperty("idUsuarioAdmin")
	private Long idUsuarioAdmin;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getTokenFirebase() {
		return tokenFirebase;
	}

	public void setTokenFirebase(String tokenFirebase) {
		this.tokenFirebase = tokenFirebase;
	}

	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getVigencia() {
		return vigencia;
	}

	public void setVigencia(String vigencia) {
		this.vigencia = vigencia;
	}

	public String getReporte() {
		return reporte;
	}

	public void setReporte(String reporte) {
		this.reporte = reporte;
	}

	public String getIsCambioClave() {
		return isCambioClave;
	}

	public void setIsCambioClave(String isCambioClave) {
		this.isCambioClave = isCambioClave;
	}

	public Date getFechaCambioClave() {
		return fechaCambioClave;
	}

	public void setFechaCambioClave(Date fechaCambioClave) {
		this.fechaCambioClave = fechaCambioClave;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public Long getIdPersona() {
		return idPersona;
	}

	public void setIdPersona(Long idPersona) {
		this.idPersona = idPersona;
	}

	public Long getIdPerfil() {
		return idPerfil;
	}

	public void setIdPerfil(Long idPerfil) {
		this.idPerfil = idPerfil;
	}

	public Long getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public Long getIdUsuarioAdmin() {
		return idUsuarioAdmin;
	}

	public void setIdUsuarioAdmin(Long idUsuarioAdmin) {
		this.idUsuarioAdmin = idUsuarioAdmin;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((this.id == null) || (String.valueOf(this.id).trim().equals(""))) {
			throw new Exception ("Id esta vacio o errado!");
		}
		
		if ((this.token == null) || (this.token.trim().equals(""))) {
			throw new Exception ("Token esta vacio o errado!");
		}
		
		if ((this.logon == null) || (this.logon.trim().equals(""))) {
			throw new Exception ("Logon esta vacio o errado!");
		}
		
		if ((this.password == null) || (this.password.trim().equals(""))) {
			throw new Exception ("Password esta vacio o errado!");
		}
		
		if ((this.vigencia == null) || (this.vigencia.trim().equals(""))) {
			throw new Exception ("Fecha de Vigencia esta vacio o errado!");
		}
		
		if ((this.idPersona == null) || (String.valueOf(this.idPersona).trim().equals(""))) {
			throw new Exception ("Id Persona esta vacio o errado!");
		}
		
		if ((this.idComercio == null) || (String.valueOf(this.idComercio).trim().equals(""))) {
			throw new Exception ("Id Comercio esta vacio o errado!");
		}
		
		if ((this.idUsuarioAdmin == null) || (String.valueOf(this.idUsuarioAdmin).trim().equals(""))) {
			throw new Exception ("Id Usuario Admin esta vacio o errado!");
		}
		
		return valid;
	}	
}