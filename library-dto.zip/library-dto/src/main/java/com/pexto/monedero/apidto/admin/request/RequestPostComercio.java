package com.pexto.monedero.apidto.admin.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class RequestPostComercio implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("entidadTipoDocumento")
	private String entidadTipoDocumento;
	
	@JsonProperty("entidadNumeroDocumento")
	private String entidadNumeroDocumento;
	
	@JsonProperty("entidadNombre")
	private String entidadNombre;
	
	@JsonProperty("entidadDireccion")
	private String entidadDireccion;
	
	@JsonProperty("entidadTelefono1")
	private String entidadTelefono1;
	
	@JsonProperty("entidadTelefono2")
	private String entidadTelefono2;
	
	@JsonProperty("entidadCorreo")
	private String entidadCorreo;
	
	@JsonProperty("entidadRNumeroDocumento")
	private String entidadRNumeroDocumento;
	
	@JsonProperty("entidadRNombre")
	private String entidadRNombre;
	
	@JsonProperty("entidadRCorreo")
	private String entidadRCorreo;
	
	@JsonProperty("entidadCNombre")
	private String entidadCNombre;
	
	@JsonProperty("entidadCTelefono")
	private String entidadCTelefono;
	
	@JsonProperty("entidadCCorreo")
	private String entidadCCorreo;
	
	@JsonProperty("comercioNombreCorto")
	private String comercioNombreCorto;
	
	@JsonProperty("comercioVigencia")
	private String comercioVigencia;
	
	@JsonProperty("comercioAutorizacionApp")
	private String comercioAutorizacionApp;
	
	@JsonProperty("comercioTokenApp")
	private String comercioTokenApp;
	
	@JsonProperty("comercioNumeroCuenta")
	private String comercioNumeroCuenta;
	
	@JsonProperty("comercioTipoCompensacion")
	private String comercioTipoCompensacion;
	
	@JsonProperty("comercioTipoPeriodicidad")
	private String comercioTipoPeriodicidad;
	
	@JsonProperty("comercioTipoComercio")
	private String comercioTipoComercio;
	
	@JsonProperty("comercioTipoOperacion")
	private String comercioTipoOperacion;
	
	@JsonProperty("comercioSucursal")
	private Boolean comercioSucursal;
	
	@JsonProperty("comercioTerminal")
	private Boolean comercioTerminal;
	
	@JsonProperty("limiteTipoTransaccion")
	private String limiteTipoTransaccion;
	
	@JsonProperty("limiteMultiplo")
	private Integer limiteMultiplo;
	
	@JsonProperty("limiteLimiteInferior")
	private Double limiteLimiteInferior;
	
	@JsonProperty("limiteLimiteSuperior")
	private Double limiteLimiteSuperior;
	
	@JsonProperty("seguridadLlavePublica")
	private String seguridadLlavePublica;
	
	@JsonProperty("seguridadLlavePrivada")
	private String seguridadLlavePrivada;
	
	@JsonProperty("seguridadFraseClave")
	private String seguridadFraseClave;
	
	@JsonProperty("seguridadVigencia")
	private String seguridadVigencia;
	
	@JsonProperty("idUsuarioAdmin")
	private Long idUsuarioAdmin;

	public String getEntidadTipoDocumento() {
		return entidadTipoDocumento;
	}

	public void setEntidadTipoDocumento(String entidadTipoDocumento) {
		this.entidadTipoDocumento = entidadTipoDocumento;
	}

	public String getEntidadNumeroDocumento() {
		return entidadNumeroDocumento;
	}

	public void setEntidadNumeroDocumento(String entidadNumeroDocumento) {
		this.entidadNumeroDocumento = entidadNumeroDocumento;
	}

	public String getEntidadNombre() {
		return entidadNombre;
	}

	public void setEntidadNombre(String entidadNombre) {
		this.entidadNombre = entidadNombre;
	}

	public String getEntidadDireccion() {
		return entidadDireccion;
	}

	public void setEntidadDireccion(String entidadDireccion) {
		this.entidadDireccion = entidadDireccion;
	}

	public String getEntidadTelefono1() {
		return entidadTelefono1;
	}

	public void setEntidadTelefono1(String entidadTelefono1) {
		this.entidadTelefono1 = entidadTelefono1;
	}

	public String getEntidadTelefono2() {
		return entidadTelefono2;
	}

	public void setEntidadTelefono2(String entidadTelefono2) {
		this.entidadTelefono2 = entidadTelefono2;
	}

	public String getEntidadCorreo() {
		return entidadCorreo;
	}

	public void setEntidadCorreo(String entidadCorreo) {
		this.entidadCorreo = entidadCorreo;
	}

	public String getEntidadRNumeroDocumento() {
		return entidadRNumeroDocumento;
	}

	public void setEntidadRNumeroDocumento(String entidadRNumeroDocumento) {
		this.entidadRNumeroDocumento = entidadRNumeroDocumento;
	}

	public String getEntidadRNombre() {
		return entidadRNombre;
	}

	public void setEntidadRNombre(String entidadRNombre) {
		this.entidadRNombre = entidadRNombre;
	}

	public String getEntidadRCorreo() {
		return entidadRCorreo;
	}

	public void setEntidadRCorreo(String entidadRCorreo) {
		this.entidadRCorreo = entidadRCorreo;
	}

	public String getEntidadCNombre() {
		return entidadCNombre;
	}

	public void setEntidadCNombre(String entidadCNombre) {
		this.entidadCNombre = entidadCNombre;
	}

	public String getEntidadCTelefono() {
		return entidadCTelefono;
	}

	public void setEntidadCTelefono(String entidadCTelefono) {
		this.entidadCTelefono = entidadCTelefono;
	}

	public String getEntidadCCorreo() {
		return entidadCCorreo;
	}

	public void setEntidadCCorreo(String entidadCCorreo) {
		this.entidadCCorreo = entidadCCorreo;
	}

	public String getComercioNombreCorto() {
		return comercioNombreCorto;
	}

	public void setComercioNombreCorto(String comercioNombreCorto) {
		this.comercioNombreCorto = comercioNombreCorto;
	}

	public String getComercioVigencia() {
		return comercioVigencia;
	}

	public void setComercioVigencia(String comercioVigencia) {
		this.comercioVigencia = comercioVigencia;
	}

	public String getComercioAutorizacionApp() {
		return comercioAutorizacionApp;
	}

	public void setComercioAutorizacionApp(String comercioAutorizacionApp) {
		this.comercioAutorizacionApp = comercioAutorizacionApp;
	}

	public String getComercioTokenApp() {
		return comercioTokenApp;
	}

	public void setComercioTokenApp(String comercioTokenApp) {
		this.comercioTokenApp = comercioTokenApp;
	}

	public String getComercioNumeroCuenta() {
		return comercioNumeroCuenta;
	}

	public void setComercioNumeroCuenta(String comercioNumeroCuenta) {
		this.comercioNumeroCuenta = comercioNumeroCuenta;
	}

	public String getComercioTipoCompensacion() {
		return comercioTipoCompensacion;
	}

	public void setComercioTipoCompensacion(String comercioTipoCompensacion) {
		this.comercioTipoCompensacion = comercioTipoCompensacion;
	}

	public String getComercioTipoComercio() {
		return comercioTipoComercio;
	}

	public void setComercioTipoComercio(String comercioTipoComercio) {
		this.comercioTipoComercio = comercioTipoComercio;
	}

	public String getComercioTipoOperacion() {
		return comercioTipoOperacion;
	}

	public void setComercioTipoOperacion(String comercioTipoOperacion) {
		this.comercioTipoOperacion = comercioTipoOperacion;
	}

	public Boolean getComercioSucursal() {
		return comercioSucursal;
	}

	public void setComercioSucursal(Boolean comercioSucursal) {
		this.comercioSucursal = comercioSucursal;
	}

	public Boolean getComercioTerminal() {
		return comercioTerminal;
	}

	public void setComercioTerminal(Boolean comercioTerminal) {
		this.comercioTerminal = comercioTerminal;
	}

	public String getLimiteTipoTransaccion() {
		return limiteTipoTransaccion;
	}

	public void setLimiteTipoTransaccion(String limiteTipoTransaccion) {
		this.limiteTipoTransaccion = limiteTipoTransaccion;
	}

	public Integer getLimiteMultiplo() {
		return limiteMultiplo;
	}

	public void setLimiteMultiplo(Integer limiteMultiplo) {
		this.limiteMultiplo = limiteMultiplo;
	}

	public Double getLimiteLimiteInferior() {
		return limiteLimiteInferior;
	}

	public void setLimiteLimiteInferior(Double limiteLimiteInferior) {
		this.limiteLimiteInferior = limiteLimiteInferior;
	}

	public Double getLimiteLimiteSuperior() {
		return limiteLimiteSuperior;
	}

	public void setLimiteLimiteSuperior(Double limiteLimiteSuperior) {
		this.limiteLimiteSuperior = limiteLimiteSuperior;
	}

	public String getSeguridadLlavePublica() {
		return seguridadLlavePublica;
	}

	public void setSeguridadLlavePublica(String seguridadLlavePublica) {
		this.seguridadLlavePublica = seguridadLlavePublica;
	}

	public String getSeguridadLlavePrivada() {
		return seguridadLlavePrivada;
	}

	public void setSeguridadLlavePrivada(String seguridadLlavePrivada) {
		this.seguridadLlavePrivada = seguridadLlavePrivada;
	}

	public String getSeguridadFraseClave() {
		return seguridadFraseClave;
	}

	public void setSeguridadFraseClave(String seguridadFraseClave) {
		this.seguridadFraseClave = seguridadFraseClave;
	}

	public String getSeguridadVigencia() {
		return seguridadVigencia;
	}

	public void setSeguridadVigencia(String seguridadVigencia) {
		this.seguridadVigencia = seguridadVigencia;
	}

	public Long getIdUsuarioAdmin() {
		return idUsuarioAdmin;
	}

	public void setIdUsuarioAdmin(Long idUsuarioAdmin) {
		this.idUsuarioAdmin = idUsuarioAdmin;
	}
	
	public String getComercioTipoPeriodicidad() {
		return comercioTipoPeriodicidad;
	}

	public void setComercioTipoPeriodicidad(String comercioTipoPeriodicidad) {
		this.comercioTipoPeriodicidad = comercioTipoPeriodicidad;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((this.entidadTipoDocumento == null) || (this.entidadTipoDocumento.trim().equals(""))) {
			throw new Exception ("Tipo de documento esta vacio o errado!");
		}
		
		if ((this.entidadNumeroDocumento == null) || (this.entidadNumeroDocumento.trim().equals(""))) {
			throw new Exception ("Número de documento esta vacio o errado!");
		}
		
		if ((this.entidadNombre == null) || (this.entidadNombre.trim().equals(""))) {
			throw new Exception ("Razon Social esta vacio o errado!");
		}
		
		if ((this.entidadDireccion == null) || (this.entidadDireccion.trim().equals(""))) {
			throw new Exception ("Dirección esta vacio o errado!");
		}
		
		if ((this.entidadTelefono1 == null) || (this.entidadTelefono1.trim().equals(""))) {
			throw new Exception ("Número de Telefono esta vacio o errado!");
		}
		
		if ((this.entidadCorreo == null) || (this.entidadCorreo.trim().equals(""))) {
			throw new Exception ("Correo electronico esta vacio o errado!");
		}
		
		if ((this.entidadRNumeroDocumento == null) || (this.entidadRNumeroDocumento.trim().equals(""))) {
			throw new Exception ("Rep Legal Número de documento del esta vacio o errado!");
		}
		
		if ((this.entidadRNombre == null) || (this.entidadRNombre.trim().equals(""))) {
			throw new Exception ("Rep Legal Nombre esta vacio o errado!");
		}
		
		if ((this.entidadRCorreo == null) || (this.entidadNombre.trim().equals(""))) {
			throw new Exception ("Rep Legal Correo esta vacio o errado!");
		}
		
		if ((this.comercioNombreCorto == null) || (this.comercioNombreCorto.trim().equals(""))) {
			throw new Exception ("Nombre de comercio esta vacio o errado!");
		}
		
		if ((this.comercioTipoComercio == null) || (this.comercioTipoComercio.trim().equals(""))) {
			throw new Exception ("Tipo de comercio esta vacio o errado!");
		}
		
		if ((this.comercioTipoCompensacion == null) || (this.comercioTipoCompensacion.trim().equals(""))) {
			throw new Exception ("Tipo de compensación esta vacio o errado!");
		}
		
		if ((this.comercioTipoPeriodicidad == null) || (this.comercioTipoPeriodicidad.trim().equals(""))) {
			throw new Exception ("Tipo de periodicidad esta vacio o errado!");
		}
		
		if ((this.comercioTipoOperacion == null) || (this.comercioTipoOperacion.trim().equals(""))) {
			throw new Exception ("Tipo de operación esta vacio o errado!");
		}
		
		if ((this.limiteTipoTransaccion == null) || (this.limiteTipoTransaccion.trim().equals(""))) {
			throw new Exception ("Tipo de transacción esta vacio o errado!");
		}
		
		if ((this.limiteMultiplo == null) || (String.valueOf(this.limiteMultiplo).trim().equals(""))) {
			throw new Exception ("Multiplo esta vacio o errado!");
		}
		
		if ((this.limiteLimiteInferior == null) || (String.valueOf(this.limiteLimiteInferior).trim().equals(""))) {
			throw new Exception ("Limite Inferior esta vacio o errado!");
		}
		
		if ((this.limiteLimiteSuperior == null) || (String.valueOf(this.limiteLimiteSuperior).trim().equals(""))) {
			throw new Exception ("Limite Superior esta vacio o errado!");
		}
		
		if ((this.seguridadLlavePublica == null) || (this.seguridadLlavePublica.trim().equals(""))) {
			throw new Exception ("Llave Publica esta vacio o errado!");
		}
		
		if ((this.seguridadLlavePrivada == null) || (this.seguridadLlavePrivada.trim().equals(""))) {
			throw new Exception ("Llave Privada esta vacio o errado!");
		}
		
		if ((this.seguridadFraseClave == null) || (this.seguridadFraseClave.trim().equals(""))) {
			throw new Exception ("Frase Clave esta vacio o errado!");
		}
		
		if ((this.seguridadVigencia == null) || (this.seguridadVigencia.trim().equals(""))) {
			throw new Exception ("Fecha de Vigencia esta vacio o errado!");
		}
		
		return valid;
	}	
}