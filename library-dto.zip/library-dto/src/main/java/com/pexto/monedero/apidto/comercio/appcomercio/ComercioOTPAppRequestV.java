package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ComercioOTPAppRequestV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("idBolsillo")
	private Long idBolsillo;
	
	@JsonProperty("codigoBolsillo")
	private String codigoBolsillo;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("valor")
	private double valor;
	
	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public String getCodigoBolsillo() {
		return codigoBolsillo;
	}

	public void setCodigoBolsillo(String codigoBolsillo) {
		this.codigoBolsillo = codigoBolsillo;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	public double getValor() {
		return valor;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}

	public boolean validateProperties() throws Exception {
		if (idBolsillo == null) {
			throw new Exception("Id Bolsillo is null");
		}
		
		if (numeroCuenta == null) {
			throw new Exception("Número de cuenta is null");
		}
		/*
		if (tipoTransaccion == null) {
			throw new Exception("Tipo de transacción is null");
		}
		*/
		if (valor <= 0) {
			throw new Exception("Ingresé un valor correcto!");
		}
		
		return true;
	}
	
	
	
}
