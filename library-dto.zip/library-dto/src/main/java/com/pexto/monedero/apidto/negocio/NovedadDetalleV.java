package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

import com.pexto.monedero.apidto.enterprises.options.TypeMethodOfPay;

public class NovedadDetalleV implements Serializable {

	private static final long serialVersionUID = 1L;

	private String numeroCuenta;
	private String valor;
	private String consecutivo;
	private String documento;// Documento Giro SAP
	private String numeroDocumento;
	private String nombres;
	private String apellidos;
	private String correo;
	private String numeroCelular;
	private String estado;
	private String tipoDocumento;
	private String idNovedad;
	private String nit;
	private String fechaEnvio;
	private String codigoProducto;
	private String tipoNovedad;
	private String fechaNacimiento;
	private String fechaExpedicion;
	private TypeMethodOfPay transferType;
	private String bankCode;
	private String bankAccountTypeCode;
	private String bankAccountNumber;

	public NovedadDetalleV() {

	}

	public NovedadDetalleV(String campoDuplicado, int tipoDuplicado) {

		if (tipoDuplicado == 1) {
			this.numeroDocumento = campoDuplicado;
		} else if (tipoDuplicado == 2) {
			this.numeroCuenta = campoDuplicado;
		}

	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public String getConsecutivo() {
		return consecutivo;
	}

	public void setConsecutivo(String consecutivo) {
		this.consecutivo = consecutivo;
	}

	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getIdNovedad() {
		return idNovedad;
	}

	public void setIdNovedad(String idNovedad) {
		this.idNovedad = idNovedad;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getFechaEnvio() {
		return fechaEnvio;
	}

	public void setFechaEnvio(String fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public String getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(String fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public TypeMethodOfPay getTransferType() {
		return transferType;
	}

	public void setTransferType(TypeMethodOfPay transferType) {
		this.transferType = transferType;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankAccountTypeCode() {
		return bankAccountTypeCode;
	}

	public void setBankAccountTypeCode(String bankAccountTypeCode) {
		this.bankAccountTypeCode = bankAccountTypeCode;
	}

	public String getBankAccountNumber() {
		return bankAccountNumber;
	}

	public void setBankAccountNumber(String bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}

	public boolean validatePropertiesMonetaria() throws Exception {
		if (this.nit == null || this.nit.length() == 0) {
			throw new Exception("nit es nulo");
		}
		if (this.fechaEnvio == null || this.fechaEnvio.length() == 0) {
			throw new Exception("fechaEnvio es nulo");
		}
		if (this.consecutivo == null || this.consecutivo.length() == 0) {
			throw new Exception("consecutivo es nulo");
		}
		if (this.tipoDocumento == null || this.tipoDocumento.length() == 0) {
			throw new Exception("bolsillo es nulo");
		}
		if (this.numeroDocumento == null || this.numeroDocumento.length() == 0) {
			throw new Exception("numeroDocumento es nulo");
		}
		if (this.numeroCuenta == null || this.numeroCuenta.length() == 0) {
			throw new Exception("numeroCuenta es nulo");
		}
		if (this.tipoNovedad == null || this.tipoNovedad.length() == 0) {
			throw new Exception("tipoNovedad es nulo");
		}
		if (this.codigoProducto == null || this.codigoProducto.length() == 0) {
			throw new Exception("codigoProducto es nulo");
		}
		if (this.valor == null || this.valor.length() == 0) {
			throw new Exception("valor es nulo");
		}
		if (this.documento == null || this.documento.length() == 0) {
			throw new Exception("documento es nulo");
		}

		return true;
	}

	public boolean validatePropertiesNoMonetaria() throws Exception {
		if (this.nit == null || this.nit.length() == 0) {
			throw new Exception("nit es nulo");
		}
		if (this.fechaEnvio == null || this.fechaEnvio.length() == 0) {
			throw new Exception("fechaEnvio es nulo");
		}
		if (this.consecutivo == null || this.consecutivo.length() == 0) {
			throw new Exception("consecutivo es nulo");
		}
		if (this.tipoDocumento == null || this.tipoDocumento.length() == 0) {
			throw new Exception("bolsillo es nulo");
		}
		if (this.numeroDocumento == null || this.numeroDocumento.length() == 0) {
			throw new Exception("numeroDocumento es nulo");
		}
		if (this.numeroCuenta == null || this.numeroCuenta.length() == 0) {
			throw new Exception("numeroCuenta es nulo");
		}
		if (this.nombres == null || this.nombres.length() == 0) {
			throw new Exception("nombre es nulo");
		}
		if (this.apellidos == null || this.apellidos.length() == 0) {
			throw new Exception("apellidos es nulo");
		}
		if (this.fechaNacimiento == null || this.fechaNacimiento.length() == 0) {
			throw new Exception("fechaNacimiento es nulo");
		}
		if (this.fechaExpedicion == null || this.fechaExpedicion.length() == 0) {
			throw new Exception("fechaExpedicion es nulo");
		}
		if (this.correo == null || this.correo.length() == 0) {
			throw new Exception("usuarioEmisor es nulo");
		}
		if (this.codigoProducto == null || this.codigoProducto.length() == 0) {
			throw new Exception("codigoProducto es nulo");
		}

		return true;
	}

}
