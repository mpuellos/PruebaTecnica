package com.pexto.monedero.apidto;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PageDTO<T> {
	
	Long totalElements;
    Integer totalPages;
    Boolean last;
    Integer numberOfElements;
    Integer size;
    Integer number;
    List<T> content;

}
