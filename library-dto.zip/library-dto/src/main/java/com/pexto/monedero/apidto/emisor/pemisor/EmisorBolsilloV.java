package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;
import java.util.Date;

public class EmisorBolsilloV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Date fecha;
	private String estado;
	private String nombreBolsillo;
	private String descripcionBolsillo;
	private Long idEmisor;
	private Long idBolsillo;
	
	public Long getId() {
		return id;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public Long getIdBolsillo() {
		return idBolsillo;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public String getNombreBolsillo() {
		return nombreBolsillo;
	}

	public void setNombreBolsillo(String nombreBolsillo) {
		this.nombreBolsillo = nombreBolsillo;
	}

	public String getDescripcionBolsillo() {
		return descripcionBolsillo;
	}

	public void setDescripcionBolsillo(String descripcionBolsillo) {
		this.descripcionBolsillo = descripcionBolsillo;
	}
	
}
