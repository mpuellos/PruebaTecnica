package com.pexto.monedero.apidto.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class TransactionErrorResponse {

  String transactionStatus;
  String descriptionStatus;
  String transactionCausal;
  String descriptionCausal;
  String workplaceBankCode;

}
