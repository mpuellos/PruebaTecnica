package com.pexto.monedero.apidto.integrador.comfenalco;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class PreguntasClienteRequestV implements IRequestValidator, Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("tipoDocumento")
	private String tipoDocumento;
	
	@JsonProperty("documento")
	private String numeroDocumento;
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((tipoDocumento == null) || (tipoDocumento.trim().length() == 0)
				|| (tipoDocumento.trim().length() != 1)) {
			throw new Exception ("El campo tipo de documento esta vacio o errado!");
		}
		
		if ((numeroDocumento == null) || (numeroDocumento.trim().length() == 0)
				|| (numeroDocumento.trim().length() > 15) || (!Parametros.validateOnlyDigits(numeroDocumento))) {
			throw new Exception ("El campo número de documento esta vacio o errado!");
		}
		
		return valid;
	}
	
}