package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class SenderRequestVPGP implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("objeto")
	private String objeto;
	
	@JsonProperty("mensaje")
	private String mensaje;
	
	public String getObjeto() {
		return objeto;
	}
	
	public void setObjeto(String objeto) {
		this.objeto = objeto;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SenderRequestVPGP [objeto=");
		builder.append(objeto);
		builder.append(", mensaje=");
		builder.append(mensaje);
		builder.append("]");
		return builder.toString();
	}
	
}

