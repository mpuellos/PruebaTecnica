package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class EmisorDashboardV implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String periodo;
	private String tipoTransaccion;
	private Long cantidad;
	private double valor;
	
	public EmisorDashboardV() {
		
	}
	
	public EmisorDashboardV(String periodo, double valor) {
		super();
		
		this.periodo	= periodo;
		this.valor		= valor;
	}
	
	public EmisorDashboardV(String tipoTransaccion, Long cantidad, double valor) {
		super();
		
		this.tipoTransaccion 	= tipoTransaccion;
		this.cantidad			= cantidad;
		this.valor				= valor;
	}
	
	public EmisorDashboardV(String tipoTransaccion, Long cantidad) {
		super();
		
		this.tipoTransaccion 	= tipoTransaccion;
		this.cantidad			= cantidad;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public Long getCantidad() {
		return cantidad;
	}

	public double getValor() {
		return valor;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setCantidad(Long cantidad) {
		this.cantidad = cantidad;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getPeriodo() {
		return periodo;
	}

	public void setPeriodo(String periodo) {
		this.periodo = periodo;
	}
}