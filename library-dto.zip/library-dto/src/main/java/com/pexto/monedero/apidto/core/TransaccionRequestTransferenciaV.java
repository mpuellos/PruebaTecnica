package com.pexto.monedero.apidto.core;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;

public class TransaccionRequestTransferenciaV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("numeroCuentaOrigen")
	private String numeroCuentaOrigen;
	
	@JsonProperty("numeroCuentaDestino")
	private String numeroCuentaDestino;
	
	@JsonProperty("idBolsillo")
	private Long idBolsillo;
	
	@JsonProperty("otp")
	private String otp;
	
	@JsonProperty("valor")
	private double valor;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("idCliente")
	private Long idCliente;
	
	@JsonProperty("token")
	private String token;
	
	@JsonProperty("authorization")
	private String authorization;
	
	@JsonProperty("paramRequest")
	private ParamRequestV paramRequest;
	
	public String getNumeroCuentaOrigen() {
		return numeroCuentaOrigen;
	}

	public String getNumeroCuentaDestino() {
		return numeroCuentaDestino;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public String getOtp() {
		return otp;
	}

	public double getValor() {
		return valor;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public Long getIdCliente() {
		return idCliente;
	}

	public String getToken() {
		return token;
	}

	public String getAuthorization() {
		return authorization;
	}

	public ParamRequestV getParamRequest() {
		return paramRequest;
	}

	public void setNumeroCuentaOrigen(String numeroCuentaOrigen) {
		this.numeroCuentaOrigen = numeroCuentaOrigen;
	}

	public void setNumeroCuentaDestino(String numeroCuentaDestino) {
		this.numeroCuentaDestino = numeroCuentaDestino;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public void setIdCliente(Long idCliente) {
		this.idCliente = idCliente;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}

	public void setParamRequest(ParamRequestV paramRequest) {
		this.paramRequest = paramRequest;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		//VALIDATION NULL
		
		if (this.numeroCuentaOrigen == null) {
			throw new Exception("Numero de Cuenta Origen - null!");
		}
		
		if (this.numeroCuentaDestino == null) {
			throw new Exception("Numero de Cuenta Destino - null!");
		}
		
		if (this.idBolsillo == null) {
			throw new Exception("IdBolsillo - null!");
		}
		
		if (this.otp == null) {
			throw new Exception("OTP - null!");
		}
		/*
		if (this.tipoTransaccion == null) {
			throw new Exception("TipoTransaccion - null!");
		}
		*/	
		//VALIDATION EMPTY
		
    	if (String.valueOf(this.numeroCuentaOrigen).equals("")) {
    		throw new Exception("Numero de Cuenta Origen vacio!");
		}
    	
    	if (String.valueOf(this.numeroCuentaDestino).equals("")) {
    		throw new Exception("Numero de Cuenta Destino vacio!");
		}
    	
    	if (this.numeroCuentaOrigen.equals(this.numeroCuentaDestino)) {
			throw new Exception ("Cuenta Origen y Destino son iguales");
		}
    	
    	if (this.otp.equals("")) {
    		throw new Exception("OTP vacio!");
		}
    	/*
    	if (this.tipoTransaccion.equals("")) {
    		throw new Exception("Tipo de Transaccion vacio!");
		}
    	
    	if (!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_TRANSFERENCIA)) {
    		throw new Exception("Ingrese un tipo de transaccion correcto!");
    	}
    	*/
    	if (String.valueOf(this.valor).equals("")) {
    		throw new Exception("Valor vacio!");
    	}
    	
    	/* VALIDATION DATA_VALUES */
    	
    	//validate_ValorPositivo
    	if (this.valor <= 0) {
    		throw new Exception("Ingrese un valor correcto!");
    	}
    	
		return valid;
	}

	@Override
	public String toString() {
		return "TransaccionRequestTransferenciaV [numeroCuentaOrigen=" + numeroCuentaOrigen + ", numeroCuentaDestino="
				+ numeroCuentaDestino + ", idBolsillo=" + idBolsillo + ", otp=" + otp + ", valor=" + valor
				+ ", tipoTransaccion=" + tipoTransaccion + ", numeroAutorizacion=" + numeroAutorizacion + ", idCliente="
				+ idCliente + ", token=" + token + ", authorization=" + authorization + ", paramRequest=" + paramRequest
				+ "]";
	}
	
}
