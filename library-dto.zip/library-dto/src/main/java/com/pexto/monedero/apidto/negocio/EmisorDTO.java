package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class EmisorDTO implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 8675746781911384440L;

    private Long id;
    private String hash;
    private String nombreCorto;
    private String nombre;
    private String transaccionParcial;
    private Date vigencia;
    private Date fecha;
    private String estado;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getHash() {
        return hash;
    }

    public void setHash(String hash) {
        this.hash = hash;
    }

    public String getNombreCorto() {
        return nombreCorto;
    }

    public void setNombreCorto(String nombreCorto) {
        this.nombreCorto = nombreCorto;
    }

    public String getTransaccionParcial() {
        return transaccionParcial;
    }

    public void setTransaccionParcial(String transaccionParcial) {
        this.transaccionParcial = transaccionParcial;
    }

    public Date getVigencia() {
        return vigencia;
    }

    public void setVigencia(Date vigencia) {
        this.vigencia = vigencia;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public EmisorDTO() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public EmisorDTO(Long id, String hash, String nombreCorto, String nombre,
            String transaccionParcial, Date vigencia, Date fecha, String estado) {
        this.id = id;
        this.hash = hash;
        this.nombreCorto = nombreCorto;
        this.nombre = nombre;
        this.transaccionParcial = transaccionParcial;
        this.vigencia = vigencia;
        this.fecha = fecha;
        this.estado = estado;
    }

}
