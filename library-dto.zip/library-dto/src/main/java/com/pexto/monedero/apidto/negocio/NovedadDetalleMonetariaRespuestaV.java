package com.pexto.monedero.apidto.negocio;

public class NovedadDetalleMonetariaRespuestaV {

	private String nit;
	private String fechaEnvio;
	private String consecutivoArchivo;
	private String tipoDocumento;
	private String numeroDocumento;
	private String numeroCuenta;
	private String tipoNovedad;
	private String codigoProducto;
	private Double valorNovedad;
	private String documentoPago;
	private String filler;
	private String codigoCausal;

	public NovedadDetalleMonetariaRespuestaV(String nit, String fechaEnvio, String consecutivoArchivo,
			String tipoDocumento, String numeroDocumento, String numeroCuenta, String tipoNovedad,
			String codigoProducto, Double valorNovedad, String documentoPago, String filler, String codigoCausal) {
		this.nit = nit;
		this.fechaEnvio = fechaEnvio;
		this.consecutivoArchivo = consecutivoArchivo;
		this.tipoDocumento = tipoDocumento;
		this.numeroDocumento = numeroDocumento;
		this.numeroCuenta = numeroCuenta;
		this.tipoNovedad = tipoNovedad;
		this.codigoProducto = codigoProducto;
		this.valorNovedad = valorNovedad;
		this.documentoPago = documentoPago;
		this.filler = filler;
		this.codigoCausal = codigoCausal;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getFechaEnvio() {
		return fechaEnvio;
	}

	public void setFechaEnvio(String fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}

	public String getConsecutivoArchivo() {
		return consecutivoArchivo;
	}

	public void setConsecutivoArchivo(String consecutivoArchivo) {
		this.consecutivoArchivo = consecutivoArchivo;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public Double getValorNovedad() {
		return valorNovedad;
	}

	public void setValorNovedad(Double valorNovedad) {
		this.valorNovedad = valorNovedad;
	}

	public String getDocumentoPago() {
		return documentoPago;
	}

	public void setDocumentoPago(String documentoPago) {
		this.documentoPago = documentoPago;
	}

	public String getFiller() {
		return filler;
	}

	public void setFiller(String filler) {
		this.filler = filler;
	}

	public String getCodigoCausal() {
		return codigoCausal;
	}

	public void setCodigoCausal(String codigoCausal) {
		this.codigoCausal = codigoCausal;
	}

}
