package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class ComercioLoginAppRequestV  implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("logon")
	private String logon;
	
	@JsonProperty("password")
	private String password;
	
	@JsonProperty("tokenFirebase")
	private String tokenFirebase;
	
	public String getLogon() {
		return logon;
	}
	
	public void setLogon(String logon) {
		this.logon = logon;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getTokenFirebase() {
		return tokenFirebase;
	}

	public void setTokenFirebase(String tokenFirebase) {
		this.tokenFirebase = tokenFirebase;
	}

	@Override
	public boolean validateProperties() throws Exception {
		
		if ((this.logon == null) || (this.logon.trim().equals(""))) {
			throw new Exception ("Campo Logon is null or empty!");
		}
		
		if ((this.password == null) || (this.password.trim().equals(""))) {
			throw new Exception ("Campo Password is null or empty!");
		}
		
		return true;
	}	
}