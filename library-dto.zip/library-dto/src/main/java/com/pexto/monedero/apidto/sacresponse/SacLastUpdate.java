package com.pexto.monedero.apidto.sacresponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Value;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SacLastUpdate {
  
  String accountNumber;
  String cellphone;
  String oldCellPhone;
  String email;
  String oldEmail;
  String address;
  String oldAddress;
  String workSite;
  String oldWorkSite;

}
