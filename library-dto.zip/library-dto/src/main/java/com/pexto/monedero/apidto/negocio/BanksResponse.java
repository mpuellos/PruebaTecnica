package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class BanksResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String code;
    private String name;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(BanksResponse.class + " [id=");
        builder.append(id + ", code=");
        builder.append(code + ", name=");
        builder.append(name);
        builder.append("]");

        return builder.toString();
    }
}
