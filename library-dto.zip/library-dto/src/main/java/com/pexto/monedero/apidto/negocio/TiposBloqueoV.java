package com.pexto.monedero.apidto.negocio;

public class TiposBloqueoV {
	private Long id;
	private String nombreCorto;
	private String descripcion;
	private String definitivo;
	private String estado;
	
	
	
	public TiposBloqueoV() {
		
	}
	public Long getId() {
		return id;
	}
	public void setId(Long long1) {
		this.id = long1;
	}
	public String getNombreCorto() {
		return nombreCorto;
	}
	public void setNombreCorto(String nombreCorto) {
		this.nombreCorto = nombreCorto;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getDefinitivo() {
		return definitivo;
	}
	public void setDefinitivo(String definitivo) {
		this.definitivo = definitivo;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
}
