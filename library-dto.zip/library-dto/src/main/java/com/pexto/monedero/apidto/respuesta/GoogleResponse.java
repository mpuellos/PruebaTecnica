package com.pexto.monedero.apidto.respuesta;

import java.io.Serializable;

public class GoogleResponse implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Boolean success;
	private String challenge_ts;
	private String hostname;
	
	public Boolean getSuccess() {
		return success;
	}
	
	public String getChallenge_ts() {
		return challenge_ts;
	}
	
	public String getHostname() {
		return hostname;
	}
	
	public void setSuccess(Boolean success) {
		this.success = success;
	}
	
	public void setChallenge_ts(String challenge_ts) {
		this.challenge_ts = challenge_ts;
	}
	
	public void setHostname(String hostname) {
		this.hostname = hostname;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("GoogleResponse [success=");
		builder.append(success);
		builder.append(", challenge_ts=");
		builder.append(challenge_ts);
		builder.append(", hostname=");
		builder.append(hostname);
		builder.append("]");
		return builder.toString();
	}
	
}