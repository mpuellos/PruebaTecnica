package com.pexto.monedero.apidto.utils;

import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.text.Normalizer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import com.pexto.monedero.apidto.core.TransaccionRequestVPGP;
import com.pexto.monedero.apidto.exceptions.InvalidRequestException;

public class Parametros {

    /* CONSTANTES - TRANSACCION - TIPOS DE TRANSACCION */
    public static final Long TipoTransaccion_Abono = 1L;
    public static final Long TipoTransaccion_Cargo = 2L;
    public static final Long TipoTransaccion_Compra = 3L;
    public static final Long TipoTransaccion_Retiro = 4L;
    public static final Long TipoTransaccion_TransferenciaIN = 5L;
    public static final Long TipoTransaccion_TransferenciaOUT = 6L;
    public static final Long TipoTransaccion_ConsultaSaldo = 7L;
    public static final Long TipoTransaccion_CreacionCuenta = 8L;
    public static final Long TipoTransaccion_AjusteDBCambioCuenta = 9L;
    public static final Long TipoTransaccion_AjusteCRCambioCuenta = 10L;
    public static final Long TipoTransaccion_ReversionCompre = 11L;
    public static final Long TipoTransaccion_ReversionRetiro = 12L;
    public static final Long TipoTransaccion_CompraQR = 13L;
    public static final Long TipoTransaccion_RetiroQR = 14L;
    public static final Long TipoTransaccion_ReversionCompraQR = 15L;
    public static final Long TipoTransaccion_ReversionRetiroQR = 16L;
    public static final Long TipoTransaccion_AbonoCompraRetiroQR = 17L;
    public static final Long TipoTransaccion_ReversionCompraRetiroQR = 18L;
    public static final Long TipoTransaccion_TarifaClienteComercio = 19L;

    public static final String TRANSACCION_TIPO_ABONO = "AB";// 1
    public static final String TRANSACCION_TIPO_CARGO = "CA";// 2
    public static final String TRANSACCION_TIPO_COMPRA = "CO";// 3
    public static final String TRANSACCION_TIPO_RETIRO = "RE";// 4
    public static final String TRANSACCION_TIPO_TRANSFERENCIA_IN = "TI";// 5
    public static final String TRANSACCION_TIPO_TRANSFERENCIA_OUT = "TO";// 6
    public static final String TRANSACCION_TIPO_CONSULTA_SALDO = "CS";// 7
    public static final String TRANSACCION_TIPO_CREACION_CUENTA = "CC";// 8
    public static final String TRANSACCION_TIPO_AJUSTE_DB_CAMBIO_CUENTA = "AD";// 9
    public static final String TRANSACCION_TIPO_AJUSTE_CR_CAMBIO_CUENTA = "AC";// 10
    public static final String TRANSACCION_TIPO_REVERSION_COMPRA = "RC";// 11
    public static final String TRANSACCION_TIPO_REVERSION_RETIRO = "RR";// 12
    public static final String TRANSACCION_TIPO_COMPRA_QR = "CQ";// 13
    public static final String TRANSACCION_TIPO_RETIRO_QR = "RQ";// 14
    public static final String TRANSACCION_TIPO_REVERSION_COMPRA_QR = "QC";// 15
    public static final String TRANSACCION_TIPO_REVERSION_RETIRO_QR = "QR";// 16
    public static final String TRANSACCION_TIPO_ABONO_COMPRA_RETIRO_QR = "AQ";// 17
    public static final String TRANSACCION_TIPO_REVERSION_COMPRA_RETIRO_QR = "QA";// 18
    public static final String TRANSACCION_TIPO_TARIFA_CLIENTE_COMERCIO = "TC";// 19
    public static final String TRANSACCION_TIPO_REEXPEDICION_CUENTA = "RX";// 20
    public static final String TRANSACCION_TIPO_TRANSFERENCIA_CUENTA_IN = "T1";// 21
    public static final String TRANSACCION_TIPO_TRANSFERENCIA_CUENTA_OUT = "T2";// 22
    public static final String TRANSACCION_TIPO_TRANSFERENCIA_AGNOSTICA_CUENTA_OUT = "T3";// 23

    /* CONSTANTES - TRANSACCION - ESTADOS DE TRANSACCION */
    public static final Long EstadoTransaccion_Autorizada = 1L;
    public static final Long EstadoTransaccion_NoAutorizada = 2L;

    public static final String TRANSACCION_ESTADO_AUTORIZADA = "A";
    public static final String TRANSACCION_ESTADO_NO_AUTORIZADA = "N";

    public static final String TRANSACCION_DESCRIPCION_AUTORIZADA = "Autorizada";
    public static final String TRANSACCION_DESCRIPCION_NO_AUTORIZADA = "No Autorizada";

    public static final String OTP_VALIDATION_MODE_NEW = "NEW";
    public static final String OTP_VALIDATION_MODE_OLD = "OLD";

    public static final String ONBOARDING_SCAN_MANUAL = "MANUAL";
    public static final String ONBOARDING_SCAN_AUTO = "AUTO";
    public static final String ONBOARDING_SCAN_OCR = "OCR";

    /* CONSTANTES - CLIENTES - TIPOS DE CLIENTES */

    public static final String TipoCliente_Afiliado = "A";
    public static final String TipoCliente_Referido = "R";
    public static final String TipoCliente_Comercio = "C";

    public static final String Estado_Activo = "A";
    public static final String Estado_Inactivo = "I";
    public static final String Estado_Sin_Activar = "S";// Sin realizar el proceso de alta
    public static final String Estado_Procesado = "T";
    public static final String Estado_Pagado = "T";
    public static final String Estado_Pendiente_Pago = "P";
    public static final String Estado_Pendiente = "P";

    public static final String Afirmativo = "S";
    public static final String Negativo = "N";

    public static final String NATURALEZA_CR = "cr";
    public static final String NATURALEZA_DB = "db";

    public static final String EXTENSION_TOKEN = ".pxt";
    public static final String EXTENSION_NOVEDAD_TXT = ".txt";
    public static final String EXTENSION_NOVEDAD_ASC = ".asc";
    public static final String EXTENSION_NOVEDAD_PGP = ".pgp";
    public static final String EXTENSION_NOVEDAD_GPG = ".gpg";
    public static final String EXTENSION_NOVEDAD_XLS = ".xls";
    public static final String EXTENSION_NOVEDAD_XLSX = ".xlsx";

    public static final String TIPO_TARIFA_VALOR = "$";
    public static final String TIPO_TARIFA_PORCENTAJE = "%";

    /* CONSTANTES DE COMERCIO - AUTORIZACION */
    public static final String COMERCIO_AUTORIZA_FRONTWEB = "F";
    public static final String COMERCIO_AUTORIZA_WEBSERVICE = "W";
    public static final String COMERCIO_AUTORIZA_APIESTANDAR = "AE";
    public static final String COMERCIO_AUTORIZA_APIEXTERNA = "AX";
    public static final String COMERCIO_AUTORIZA_APIREDES = "AR";

    /* CONSTANTES CREACIÓN DE CUENTA BOLSILLO - PRESTAMOS */
    public static final String PRESTAMOS_WALLET_TYPE_PRIMARY = "DEFAULT_MONETARY";
    public static final String PRESTAMOS_WALLET_TYPE_LOAN = "DEFAULT_LOAN";

    /* CONSTANTES DE COMERCIO - COMPENSACION */
    public static final String COMERCIO_COMPENSA_AUTOMATICO = "A";
    public static final String COMERCIO_COMPENSA_MANUAL = "M";

    /* CONSTANTES DE CUENTA_BOLSILLO ESTADOS */
    public static final String CUENTABOLSILLO_ESTADO_PREVENTIVO = "P";
    public static final String CUENTABOLSILLO_ESTADO_FALLECIDO = "F";
    public static final String CUENTABOLSILLO_ESTADO_ROBO = "R";
    public static final String CUENTABOLSILLO_ESTADO_ACTIVO = "A";
    public static final String CUENTABOLSILLO_ESTADO_INACTIVO = "I";

    /* CONSTANTES DE CUENTA */
    public static final String TRANSACCION_CUENTA_ORIGEN = "CUENTA_ORIGEN";
    public static final String TRANSACCION_CUENTA_DESTINO = "CUENTA_DESTINO";
    public static final String CUENTA_TIPO_AFILIADA = "CUENTA_TIPO_AFILIADA";
    public static final String CUENTA_TIPO_REFERIDO = "CUENTA_TIPO_REFERIDO";

    public static final String PARAMETRO_ENABLED_COMPRA_SERVICIOS = "APP_COMPRA_SERVICIOS";


    public static final String TRANSACCION_COBRE_ANULAR = "ANULAR";
    public static final String TRANSACCION_COBRE_AUTORIZAR = "AUTORIZAR";

    public static final String TRANSACCION_WORKPLACEBANK_ANULAR = "anulacion";
    public static final String TRANSACCION_WORKPLACEBANK_AUTORIZAR = "autorizador";

    public static final String TRANSACCION_CAUSAL_AUTORIZADA = "000";
    public static final String TRANSACCION_CAUSAL_NO_AUTORIZADA = "001";
    public static final String TRANSACCION_CAUSAL_TIPO_NOVEDAD_NO_VALIDA = "002";
    public static final String TRANSACCION_CAUSAL_CUENTA_NO_EXISTE = "003";
    public static final String TRANSACCION_CAUSAL_CUENTA_INACTIVA = "004";
    public static final String TRANSACCION_CAUSAL_BOLSILLO_NO_EXISTE = "005";
    public static final String TRANSACCION_CAUSAL_BOLSILLO_INACTIVO = "006";
    public static final String TRANSACCION_CAUSAL_NOVEDAD_NO_EXISTE = "007";
    public static final String TRANSACCION_CAUSAL_EMISOR_NO_EXISTE = "008";
    public static final String TRANSACCION_CAUSAL_USUARIO_EMISOR_NO_EXISTE = "009";
    public static final String TRANSACCION_CAUSAL_NOVEDAD_USUARIO_SIN_PERMISO = "010";
    public static final String TRANSACCION_CAUSAL_NOVEDAD_NO_PENDIENTE = "011";
    public static final String TRANSACCION_CAUSAL_NOVEDAD_SIN_DETALLE = "012";
    public static final String TRANSACCION_CAUSAL_NOVEDAD_NIT_NO_CORRESPONDE = "013";
    public static final String TRANSACCION_CAUSAL_NOVEDAD_REGISTROS_NO_CORRESPONDEN = "014";
    public static final String TRANSACCION_CAUSAL_NOVEDAD_TOTAL_NO_CORRESPONDEN = "015";
    public static final String TRANSACCION_CAUSAL_EMISOR_INACTIVO = "016";
    public static final String TRANSACCION_CAUSAL_USUARIO_EMISOR_INACTIVO = "017";
    public static final String TRANSACCION_CAUSAL_USUARIO_EMISOR_VIGENCIA_EXPIRADA = "018";
    public static final String TRANSACCION_CAUSAL_USUARIO_EMISOR_NO_ASOCIADO_EMISOR = "019";
    public static final String TRANSACCION_CAUSAL_CUENTA_NO_ASOCIADA_AL_EMISOR = "020";
    public static final String TRANSACCION_CAUSAL_CUENTA_INACTIVA_AL_EMISOR = "021";
    public static final String TRANSACCION_CAUSAL_CUENTA_ACTIVA_AL_EMISOR = "022";
    public static final String TRANSACCION_CAUSAL_CUENTA_YA_EXISTE = "023";
    public static final String TRANSACCION_CUENTA_SIN_SALDO = "024";
    public static final String TRANSACCION_CAUSAL_CUENTABOLSILLO_EXISTE = "025";
    public static final String TRANSACCION_CAUSAL_CUENTA_ACTIVA = "026";// Se usa para Desbloquear
    public static final String TRANSACCION_CAUSAL_CLIENTE_INACTIVO = "027";

    public static final String TRANSACCION_CAUSAL_TIPO_NOVEDAD_NO_EXISTE = "028";
    public static final String TRANSACCION_CAUSAL_TIPO_OPERACION_NO_EXISTE = "029";
    public static final String TRANSACCION_CAUSAL_SERVICIO_NO_DISPONIBLE = "030";// Servicio no
                                                                                 // disponible
    public static final String TRANSACCION_CAUSAL_TIPO_DOCUMENTO_NO_EXISTE = "031";
    public static final String TRANSACCION_CAUSAL_NOVEDAD_SIN_VERIFICAR = "032";
    public static final String TRANSACCION_CAUSAL_CUENTA_INVALIDA = "033";
    public static final String TRANSACCION_CAUSAL_CUENTA_SIN_BOLSILLO = "035";
    public static final String TRANSACCION_CAUSAL_APP_SESION_ACTIVA = "036";
    public static final String TRANSACCION_CAUSAL_APP_PIN_CAMBIO_EXITOSO = "037";// Su PIN ha sigo
                                                                                 // cambiado.
    public static final String TRANSACCION_CAUSAL_APP_PIN_ASIGNADO = "038";// PIN asignado
                                                                           // correctamente.
    public static final String TRANSACCION_CAUSAL_APP_CODIGO_SEGURIDAD_CORRECTO = "039";// Su codigo
                                                                                        // de
                                                                                        // seguridad
                                                                                        // ingresado
                                                                                        // es
                                                                                        // correcto,
                                                                                        // a
                                                                                        // continuacion
                                                                                        // asigne un
                                                                                        // PIN a
                                                                                        // su cuenta
    public static final String TRANSACCION_CAUSAL_APP_CODIGO_SEGURIDAD_ENVIADO = "040";// Su codigo
                                                                                       // de
                                                                                       // seguridad
                                                                                       // ha sido
                                                                                       // enviado a
                                                                                       // traves de
                                                                                       // mensajeria
                                                                                       // de texto
    public static final String TRANSACCION_CAUSAL_APP_VALOR_TRANSACCION_CERO = "041";// El valor de
                                                                                     // la
                                                                                     // transaccion
                                                                                     // debe
                                                                                     // ser superior
                                                                                     // a $0
    public static final String TRANSACCION_CAUSAL_APP_CODIGO_SEGURIDAD_GENERADO = "042";// Codigo de
                                                                                        // seguridad
                                                                                        // ha sido
                                                                                        // generado
                                                                                        // con
                                                                                        // exito.
    public static final String TRANSACCION_CAUSAL_APP_SERVIDOR_SMS_NO_DISPONIBLE = "043";// "Servidor
                                                                                         // de SMS
                                                                                         // no se
                                                                                         // encuentra
                                                                                         // activo"
    public static final String TRANSACCION_CAUSAL_APP_SALDO_INSUFICIENTE = "044";// "Saldo
                                                                                 // insuficiente"
    public static final String TRANSACCION_CAUSAL_APP_CUENTA_DESTINO_NO_EXISTE = "045";// "Cuenta a
                                                                                       // Transferir
                                                                                       // No
                                                                                       // existe"
    public static final String TRANSACCION_CAUSAL_APP_SESION_CADUCADA = "046";// Tu sesion ha
                                                                              // caducado
    public static final String TRANSACCION_CAUSAL_APP_TRANSFERENCIA_CUENTAS_IGUALES = "047";// "Cuenta
                                                                                            // Origen
                                                                                            // y
                                                                                            // Destino
                                                                                            // son
                                                                                            // iguales"
    public static final String TRANSACCION_CAUSAL_EMISOR_SIN_CONVENIO = "048";// "Emisor no tiene
                                                                              // convenio con el
                                                                              // comercio"
    public static final String TRANSACCION_CAUSAL_CUENTA_NO_REEXPEDIBLE = "049";
    public static final String TRANSACCION_CAUSAL_CUENTA_ASOCIADA_OTRO_CLIENTE = "050";
    public static final String TRANSACCION_CAUSAL_CUENTA_NO_PERMITE_ABONO = "051";
    public static final String TRANSACCION_CAUSAL_CUENTA_NO_PERMITE_CARGO = "052";
    public static final String TRANSACCION_CAUSAL_CUENTA_NO_PERMITE_TRANSFERENCIA = "053";
    public static final String TRANSACCION_CAUSAL_CUENTA_DESTINO_NO_PERMITE_TRANSFERENCIA = "054";
    public static final String TRANSACCION_CAUSAL_COMERCIO_NO_EXISTE = "055";
    public static final String TRANSACCION_CAUSAL_EMISOR_COMERCIO_RELACION_NO_EXISTE = "056";
    public static final String TRANSACCION_CAUSAL_COMPENSACION_NO_EXISTE = "057";
    public static final String TRANSACCION_CAUSAL_COMPENSACION_ESTADO_INVALIDO = "058";
    public static final String TRANSACCION_CAUSAL_CLIENTE_NO_EXISTE = "059";
    public static final String TRANSACCION_CAUSAL_FECHA_EXPEDICION_INVALIDA = "060";
    public static final String TRANSACCION_CAUSAL_ARCHIVO_CONSECUTIVO_INVALIDO = "061";
    public static final String TRANSACCION_CAUSAL_SALDO_INSUFICIENTE = "062";
    public static final String TRANSACCION_CAUSAL_ARCHIVO_FECHA_NO_CORRESPONDE = "063";
    public static final String TRANSACCION_CAUSAL_ARCHIVO_FECHA_TRAILER_INVALIDA = "064";
    public static final String TRANSACCION_CAUSAL_BLOQUEO_ESTADO_IGUAL_ANTERIOR = "065";
    public static final String TRANSACCION_CAUSAL_LIMITE_SUPERA_VALOR_PERMITIDO = "066";
    public static final String TRANSACCION_CAUSAL_CUENTA_BLOQUEADA = "067";
    public static final String TRANSACCION_CAUSAL_APP_CUENTA_BLOQUEADA = "068";
    public static final String TRANSACCION_CAUSAL_CUENTA_DESTINO_NO_PERMITE_COMPRA_RETIRO = "069";

    public static final String TRANSACCION_CAUSAL_TIPO_BLOQUEO_NO_EXISTE = "080";// Se usa para
                                                                                 // Desbloquear
    public static final String TRANSACCION_CAUSAL_TIPO_BLOQUEO_DEFINITIVO = "081";// Se usa para
                                                                                  // Desbloquear

    public static final String TRANSACCION_CAUSAL_TRANSACCION_NO_EXISTE = "082";
    public static final String TRANSACCION_CAUSAL_TRANSACCION_DETALLE_NO_EXISTE = "083";
    public static final String TRANSACCION_CAUSAL_TRANSACCION_ANULADA = "084";// La transaccion ya
                                                                              // habia sido
                                                                              // anulada/reversada
    public static final String TRANSACCION_CAUSAL_TIPO_TRANSACCION_OTP_NO_CORRESPONDE = "085";// OTP
                                                                                              // no
                                                                                              // corresponde
                                                                                              // al
                                                                                              // tipo
                                                                                              // de
                                                                                              // transaccion
                                                                                              // indicado!
    public static final String TRANSACCION_CAUSAL_TRANSACCION_OTP_NO_CORRESPONDE = "086";// OTP no
                                                                                         // corresponde
                                                                                         // a la
                                                                                         // transaccion
                                                                                         // indicada!
    public static final String TRANSACCION_CAUSAL_TRANSACCION_COMERCIO_NO_CORRESPONDE = "087";// La
                                                                                              // transaccion
                                                                                              // no
                                                                                              // corresponde
                                                                                              // a
                                                                                              // este
                                                                                              // comercio!
    public static final String TRANSACCION_CAUSAL_TRANSACCION_TERMINAL_NO_CORRESPONDE = "088";// La
                                                                                              // transaccion
                                                                                              // no
                                                                                              // corresponde
                                                                                              // a
                                                                                              // esta
                                                                                              // terminal!
    public static final String TRANSACCION_CAUSAL_TIPO_TRANSACCION_NO_EXISTE = "089";// Tipo de
                                                                                     // transaccion
                                                                                     // no existe
    public static final String TRANSACCION_CAUSAL_TIPO_TRANSACCION_INACTIVO = "090";// Tipo de
                                                                                    // transaccion
                                                                                    // inactivo
    public static final String TRANSACCION_CAUSAL_TIPO_TRANSACCION_INVALIDO = "091";// Tipo de
                                                                                    // transaccion
                                                                                    // no es valido
                                                                                    // para la
                                                                                    // operacion que
                                                                                    // intenta
                                                                                    // realizar
    public static final String TRANSACCION_CAUSAL_OTP_NO_EXISTE = "092";// OTP no encontrado, por
                                                                        // favor verifique el
                                                                        // valor y/o tipo de
                                                                        // transacion seleccionado
    public static final String TRANSACCION_CAUSAL_OTP_VIGENCIA_EXPIRO = "093";// La vigencia del OTP
                                                                              // ya expiro
    public static final String TRANSACCION_CAUSAL_CUENTA_BOSILLO_NO_EXISTE = "094";// La cuenta no
                                                                                   // tiene un
                                                                                   // bolsillo/emisor
                                                                                   // asociado
    public static final String TRANSACCION_CAUSAL_USUARIO_COMERCIO_NO_EXISTE = "095";// UsuarioComercio
                                                                                     // no existe
    public static final String TRANSACCION_CAUSAL_USUARIO_COMERCIO_INACTIVO = "096";// UsuarioComercio
                                                                                    // inactivo!
    public static final String TRANSACCION_CAUSAL_USUARIO_COMERCIO_VIGENCIA_EXPIRADA = "097";// La
                                                                                             // vigencia
                                                                                             // del
                                                                                             // usuario
                                                                                             // commercio
                                                                                             // expiro
    public static final String TRANSACCION_CAUSAL_USUARIO_COMERCIO_NO_AUTORIZADO = "098";// Usuario
                                                                                         // comercio
                                                                                         // no
                                                                                         // autorizado
                                                                                         // para
                                                                                         // realizar
                                                                                         // esta
                                                                                         // operacion
    public static final String TRANSACCION_CAUSAL_NUMERO_DOCUMENTO_DUPLICADO = "099";// Numero de
                                                                                     // documento
                                                                                     // duplicado en
                                                                                     // el archivo
    public static final String TRANSACCION_CAUSAL_NUMERO_CUENTA_DUPLICADO = "100";// Numero de
                                                                                  // cuenta
                                                                                  // duplicado en el
                                                                                  // archivo
    public static final String TRANSACCION_CAUSAL_CUENTA_CLIENTE_CUENTA_BOLSILLO_NOEXISTE = "101";// Verifique
                                                                                                  // los
                                                                                                  // parametros
                                                                                                  // (Numero
                                                                                                  // de
                                                                                                  // cuenta,
                                                                                                  // Numero
                                                                                                  // de
                                                                                                  // documento
                                                                                                  // y/o
                                                                                                  // Inscripcion
                                                                                                  // de
                                                                                                  // cuenta)
    public static final String TRANSACCION_CAUSAL_COMERCIO_INACTIVO = "102";
    public static final String TRANSACCION_CAUSAL_TERMINAL_INACTIVO = "103";
    public static final String TRANSACCION_QR_TRAMA_VACIA = "104";
    public static final String TRANSACCION_QR_TRAMA_INVALIDA = "105";

    public static final String TRANSACCION_CAUSAL_ARCHIVO_INVALIDO = "200";// Se usa para
                                                                           // Desbloquear
    public static final String TRANSACCION_CAUSAL_ARCHIVO_CONSECUTIVO_EXISTE = "201";// Se usa para
                                                                                     // Desbloquear
    public static final String TRANSACCION_CAUSAL_ARCHIVO_FECHA_INVALIDA = "202";// Se usa para
                                                                                 // Desbloquear
    public static final String TRANSACCION_CAUSAL_ARCHIVO_CODIGO_EMISOR_INVALIDO = "203";// Se usa
                                                                                         // para
                                                                                         // Desbloquear
    public static final String TRANSACCION_CAUSAL_ARCHIVO_ICM = "204";// Se usa para Desbloquear
    public static final String TRANSACCION_CAUSAL_ARCHIVO_NOMBRE_EXISTE = "205";// Se usa para
                                                                                // Desbloquear

    public static final String TRANSACCION_CAUSAL_DATOS_ERRADOS = "300";// Datos Invalidos
    public static final String TRANSACCION_CAUSAL_FECHA_EXPEDICION_ERRADA = "301";// Datos Invalidos

    public static final String TRANSACCION_CAUSAL_ENROLAMIENTO_INVALIDO = "350";// Datos Invalidos
    public static final String TRANSACCION_CAUSAL_ENROLAMIENTO_VENCIDA = "351";// Datos Invalidos
    public static final String TRANSACCION_CAUSAL_ENROLAMIENTO_USADO = "352";// Datos Invalidos
    public static final String TRANSACCION_CAUSAL_ENROLAMIENTO_OTP_INVALIDO = "353";// Datos
                                                                                    // Invalidos
    public static final String TRANSACCION_CAUSAL_ENROLAMIENTO_INACTIVO = "354";// Datos Invalidos
    public static final String TRANSACCION_CAUSAL_ENROLAMIENTO_PIN_DIFERENTES = "355";// Datos
                                                                                      // Invalidos
    public static final String TRANSACCION_CAUSAL_ENROLAMIENTO_OTP_NO_EXISTE = "356";// Datos
                                                                                     // Invalidos

    public static final String TRANSACCION_CAUSAL_PIN_INVALIDO = "380";
    public static final String TRANSACCION_CAUSAL_PIN_ERRADO = "381";
    public static final String TRANSACCION_CAUSAL_PIN_IGUAL_ANTERIOR = "382";
    public static final String TRANSACCION_CAUSAL_PIN_IGUAL_INACTIVO = "383";
    public static final String TRANSACCION_CAUSAL_PIN_NUEVOS_NO_CORRESPONDEN = "384";
    public static final String TRANSACCION_CAUSAL_PIN_CUENTA_ASOCIADA_OTRO_DISPOSITIVO = "385";
    public static final String TRANSACCION_CAUSAL_PIN_SIN_REGISTRAR = "386";

    public static final String TRANSACCION_CAUSAL_APP_SIN_AUTORIZACION = "387";
    public static final String TRANSACCION_CAUSAL_APP_AUTORIZACION_INVALIDA = "388";

    public static final String TRANSACCION_CAUSAL_APP_OBLIGAR_REGISTRO = "389";
    public static final String TRANSACCION_ABONO_CAUSAL_APP_SESION_CADUCADA = "390";
    public static final String TRANSACCION_CAUSAL_ARCHIVO_ABONO_CAMPO_NO_VALIDO = "391";

    public static final String TRANSACCION_CAUSAL_CONEXION_SERVER_SMS = "501";
    
    public static final String TRANSACCION_CAUSAL_LIMITE_COMERCIO_NO_EXISTE = "502";
    
    public static final String TRANSACCION_ORIGINAL_NO_EXISTE = "506";
    
    public static final String TRANSACCION_CAUSAL_TERMINAL_NO_EXISTE = "507";
    
    public static final String TRANSACCION_CAUSAL_CUENTA_VENCIDA_REVERSO = "508";
    
    public static final String TRANSACCION_CAUSAL_TRANSACCION_CON_REVERSO = "509";
    
    public static final String TRANSACCION_CAUSAL_TIPO_TRANSACCION_REVERSO_NO_EXISTE = "510";

    public static final String TRANSACCION_TIPO_COMPRA_MANUAL = "COM";
    public static final String TRANSACCION_TIPO_COMPRA_AUTOMATICO = "COA";
    public static final String TRANSACCION_TIPO_RETIRO_MANUAL = "REM";
    public static final String TRANSACCION_TIPO_RETIRO_AUTOMATICO = "REA";
    public static final String TRANSACCION_TIPO_REVERSION_COMPRA_MANUAL = "RCM";
    public static final String TRANSACCION_TIPO_REVERSION_COMPRA_AUTOMATICO = "RCA";
    public static final String TRANSACCION_TIPO_REVERSION_RETIRO_MANUAL = "RRM";
    public static final String TRANSACCION_TIPO_REVERSION_RETIRO_AUTOMATICO = "RRA";
    public static final String TRANSACCION_TIPO_TRANSFERENCIA = "TRA";
    public static final String TRANSACCION_TIPO_TRANSFERENCIA_INTERNA = "TRI";

    /* CONSTANTES DE NOVEDAD */
    public static final String NOVEDAD_TIPO_ENTRADA_INSCRIPCION_CUENTA =
            "ENTRADA_INSCRIPCION_CUENTA";
    public static final String NOVEDAD_TIPO_ENTRADA_ABONO_CUENTA = "ENTRADA_ABONO_CUENTA";
    public static final String NOVEDAD_TIPO_ENTRADA_CARGO_CUENTA = "ENTRADA_CARGO_CUENTA";

    public static final String NOVEDAD_TIPO_SALIDA_INSCRIPCION_CUENTA = "SALIDA_INSCRIPCION_CUENTA";
    public static final String NOVEDAD_TIPO_SALIDA_ABONO_CUENTA = "SALIDA_ABONO_CUENTA";

    // MODES OF NUMBER ACCOUNT
    public static final String CAMPO_NUMERO_CUENTA_DOCUMENTO = "DOCUMENTO";
    public static final String CAMPO_NUMERO_CUENTA_CELULAR = "CELULAR";

    // FORGOT PASSWORD OPERATION
    public static final String FORGOT_PASSWORD_KNOWN_DEVICE = "KNOWN_DEVICE";
    public static final String FORGOT_PASSWORD_UNKNOWN_DEVICE = "UNKNOWN_DEVICE";

    // TYPE OTP VALIDATED
    public static final String PARAM_SMS = "SMS";
    public static final String PARAM_EMAIL = "EMAIL";

    // DATE CONSTANTS
    public static final String CONS_YYYYMMDD = "yyyyMMdd";
    public static final String CONS_YYYY_MM_DD = "yyyy-MM-dd";

    // TYPE OTP VALIDATED
    public static final String VALIDATE_EXPEDITION_DATE_REGISTER = "VALIDATE_EXPEDITION_DATE_REGISTER";
    public static final String VALIDATE_MESSAGE_EXPEDITION_DATE_INVALID_REGISTER = "VALIDATE_MESSAGE_EXPEDITION_DATE_INVALID_REGISTER";
    public static final String FORMAT_EXPEDITION_DATE_CLIENT = "FORMAT_EXPEDITION_DATE_CLIENT";
    public static final String FORMAT_EXPEDITION_DATE_EMISOR = "FORMAT_EXPEDITION_DATE_EMISOR";
    public static final String VALIDATE_BIRTH_DATE_REGISTER = "VALIDATE_BIRTH_DATE_REGISTER";
    public static final String VALIDATE_MESSAGE_BIRTH_DATE_INVALID_REGISTER = "VALIDATE_MESSAGE_BIRTH_DATE_INVALID_REGISTER";
    public static final String FORMAT_BIRTH_DATE_CLIENT = "FORMAT_BIRTH_DATE_CLIENT";
    public static final String FORMAT_BIRTH_DATE_EMISOR = "FORMAT_BIRTH_DATE_EMISOR";

    public static final String NOVEDAD_TIPO_SALIDA_CARGO_CUENTA = "SALIDA_CARGO_CUENTA"; // Comentario
                                                                                         // para
                                                                                         // probar ñ
                                                                                         // y á
    // é ó tildes
    public static final String MENSAJE_CORREO_NUMERO_NO_COINCIDE_CON_EMISOR =
            "Estimado usuario, el número celular %s y el correo %s no corresponden a los datos registrados en la base de datos de su emisor. Lo invitamos a validar los datos con su emisor o escribiendo a soporte@cobre.co.";
    public static final String MENSAJE_NUMERO_NO_COINCIDE_CON_EMISOR =
            "Estimado usuario, el número celular %s no corresponde al número registrado en la base de datos de su emisor. Lo invitamos a validar los datos con su emisor o escribiendo a soporte@cobre.co.";
    public static final String MENSAJE_CORREO_NO_COINCIDE_CON_EMISOR =
            "Estimado usuario, el correo electrónico %s no corresponde al correo registrado en la base de datos de su emisor. Lo invitamos a validar los datos con su emisor o escribiendo a soporte@cobre.co.";

    public static final String SMS_TRANSFERENCIA_IN_DEFAULT =
            "Billetera Movil Emisor: has recibido una transferencia por valor de $%s, codigo autorizacion %s fecha %s";
    public static final String SMS_TRANSFERENCIA_OUT_DEFAULT =
            "Billetera Movil Emisor: has realizado una transferencia por valor de $%s, codigo autorizacion %s fecha %s";
    public static final String SMS_COMPRA_DEFAULT =
            "Billetera Movil Emisor: has realizado una %s por valor de $%s, codigo autorizacion %s fecha %s";
    public static final String SMS_RETIRO_DEFAULT =
            "Billetera Movil Emisor: has realizado un %s por valor de $%s, codigo autorizacion %s fecha %s";
    public static final String SMS_CARGO_DEFAULT =
            "Billetera Movil Emisor: se ha realizado un cargo/reversion por valor de $%s, codigo autorizacion %s fecha %s";
    public static final String SMS_ABONO_DEFAULT =
            "Billetera Movil Emisor: has recibido un abono por valor de $%s, codigo autorizacion %s fecha %s";
    public static final String SMS_ABONO_QR_DEFAULT =
            "Billetera Movil Emisor: has recibido un abono por valor de $%s de la cuenta %s, codigo autorizacion %s fecha %s";
    public static final String SMS_INSCRIPTION_DEFAULT =
            "Billetera Movil Emisor: su cuenta ha sido vinculada de forma exitosa.";
    public static final String SMS_OTP_DEFAULT =
            "Billetera Movil Emisor: su codigo de seguridad es %s";
    public static final String EMAIL_TITLE_OTP_DEFAULT = "Billetera Movil Emisor";
    public static final String EMAIL_OTP_DEFAULT =
            "Billetera Movil Emisor: su codigo de seguridad es %s";

    public static final String ERROR_OTP_VIA_APP_HAS_COMMERCE =
            "OTP no es valido, fue generado para autorizar via APP con un comercio especifico!";
    public static final String ERROR_OTP_VIA_APP_NOT_HAS_COMMERCE =
            "OTP no es valido, no se indico el comercio donde se efectuara la operacion!";
    public static final String ERROR_OTP_VIA_APP_COMMERCE_NOT_CORRESPOND =
            "OTP no es valido, no corresponde al comercio desde el cual fue generado!";

    // ERRORS TRANSACTIONAL
    public static final String ERROR_COMMERCE_NOT_HAS_LIMITS =
            "El comercio no tiene el tipo de transaccion/limite asociado!";


    public static final String ERROR_EXPEDITION_DATE_REGISTER =
            "La fecha de expedicion de tu documento no coincide con la que recibimos del emisor";
    public static final String ERROR_BIRTH_DATE_REGISTER =
            "La fecha de nacimiento no coincide con la que recibimos del emisor";

    private static final Random random = new Random();
    private static final String[] prefixNumbersColombia =
            {"300", "301", "302", "304", "305", "310", "311", "312", "313", "314", "315", "316",
                    "317", "318", "319", "320", "321", "322", "323", "324", "350", "351"};
    
    
    public static final String  TX_HASH_SUFFIX = "TX_HASH";

    public static String getFechaStringFormatoDefaultUnido(Date date) {
        String strFormat = "yyyyMMddHHmmss";

        return new SimpleDateFormat(strFormat).format(date);
    }

    public static String getFechaString(Date fecha) {
        String strFormat = "yyyy-MM-dd HH:mm:ss";

        return new SimpleDateFormat(strFormat).format(fecha);
    }

    public static String getFechaStringYYYYMMDD(Date fecha) {
      if (fecha == null)
        return StringUtils.EMPTY;
      String strFormat = CONS_YYYYMMDD;

      return new SimpleDateFormat(strFormat).format(fecha);
    }

    public static String getFechaStringYYYYMMDD(LocalDate fecha) {
        return fecha.format(DateTimeFormatter.ofPattern(CONS_YYYYMMDD));
    }

    public static String getFechaNormalString(LocalDate fecha) {
      return fecha.format(DateTimeFormatter.ofPattern(CONS_YYYY_MM_DD));
    }
    
    public static String getFechaNormalString(Date fecha) {
        return new SimpleDateFormat(CONS_YYYY_MM_DD).format(fecha);
    }

    public static String getHoraString(Date fecha) {
        String strFormat = "HH:mm:ss";

        return new SimpleDateFormat(strFormat).format(fecha);
    }

    public static String getFechaFormato(Date fecha, String strFormat) {
        return new SimpleDateFormat(strFormat).format(fecha);
    }

    public static Date getFechaFormato(String strFormat, String dateStr) throws ParseException {
        return new SimpleDateFormat(strFormat).parse(dateStr);
    }

    public static String getFechaActualFormatoDefault() {
        String strFormat = "yyyy-MM-dd HH:mm:ss";

        return new SimpleDateFormat(strFormat).format(new Date());
    }

    public static String getFechaActualFormatoDefaultUnido() {
        String strFormat = "yyyyMMddHHmmss";

        return new SimpleDateFormat(strFormat).format(new Date());
    }

    public static String getFechaActualFormato(String strFormat) {
        return new SimpleDateFormat(strFormat).format(new Date());
    }

    public static Boolean containsNormalizer(String data, String text) {
        return Normalizer.normalize(text, Normalizer.Form.NFD).replaceAll("[^\\p{ASCII}]", "").toLowerCase()
                .contains(Normalizer.normalize(data, Normalizer.Form.NFD)
                        .replaceAll("[^\\p{ASCII}]", "").toLowerCase());
    }

    public static Date getFechaFromString(String strDate) throws Exception {
        String strFormat = "yyyy/MM/dd";

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(strFormat);

        Date fecha = null;

        try {
            fecha = simpleDateFormat.parse(strDate);
        } catch (ParseException exc) {
            throw new Exception(exc);
        }

        return fecha;
    }

    public static boolean isPhoneNumberColombia(String numeroCuenta) {
        if (numeroCuenta != null && numeroCuenta.length() == 10) {
            String prefix = numeroCuenta.substring(0, 3);
            return Arrays.asList(prefixNumbersColombia).contains(prefix);
        }
        return false;
    }

    public static Date getDateTimeStartMonth() {
        Calendar calFechaActual = Calendar.getInstance();

        // Dia inicial del mes (fechaActual)
        calFechaActual.set(Calendar.DAY_OF_MONTH, 1);

        // Hora inicial del dia (fechaActual)
        calFechaActual.set(Calendar.HOUR_OF_DAY, 0);
        calFechaActual.set(Calendar.MINUTE, 0);
        calFechaActual.set(Calendar.SECOND, 0);

        return calFechaActual.getTime();
    }

    public static Date getDateTimeEndMonth() {
        Calendar calFechaActual = Calendar.getInstance();

        // Hora final del dia (fechaActual)
        calFechaActual.set(Calendar.HOUR_OF_DAY, 23);
        calFechaActual.set(Calendar.MINUTE, 59);
        calFechaActual.set(Calendar.SECOND, 59);

        return calFechaActual.getTime();
    }

    public static Date getDateTimeStartDay(Date fechaInicio) {
        Calendar calFechaInicio = Calendar.getInstance();

        calFechaInicio.setTime(fechaInicio);
        calFechaInicio.set(Calendar.HOUR_OF_DAY, 0);
        calFechaInicio.set(Calendar.MINUTE, 0);
        calFechaInicio.set(Calendar.SECOND, 0);
        calFechaInicio.set(Calendar.MILLISECOND, 0);

        return calFechaInicio.getTime();
    }

    public static Date getDateTimeEndDay(Date fechaFinal) {
        Calendar calFechaFinal = Calendar.getInstance();

        calFechaFinal.setTime(fechaFinal);
        calFechaFinal.set(Calendar.HOUR_OF_DAY, 23);
        calFechaFinal.set(Calendar.MINUTE, 59);
        calFechaFinal.set(Calendar.SECOND, 59);

        return calFechaFinal.getTime();
    }

    public static Date getDateTimeStartYear() {
        Calendar calFechaActual = Calendar.getInstance();

        // Mes inicial de (fechaActual)
        calFechaActual.set(Calendar.MONTH, 0);

        // Dia inicial del mes (fechaActual)
        calFechaActual.set(Calendar.DAY_OF_MONTH, 1);

        // Hora inicial del dia (fechaActual)
        calFechaActual.set(Calendar.HOUR_OF_DAY, 0);
        calFechaActual.set(Calendar.MINUTE, 0);
        calFechaActual.set(Calendar.SECOND, 0);

        return calFechaActual.getTime();
    }

    public static Date getDateTimeEndYear() {
        Calendar calFechaActual = Calendar.getInstance();

        // Dia y Mes Final de (fechaActual)
        calFechaActual.set(Calendar.DAY_OF_MONTH, 31);
        calFechaActual.set(Calendar.MONTH, Calendar.DECEMBER);

        // Hora inicial del dia (fechaActual)
        calFechaActual.set(Calendar.HOUR_OF_DAY, 23);
        calFechaActual.set(Calendar.MINUTE, 59);
        calFechaActual.set(Calendar.SECOND, 59);

        return calFechaActual.getTime();
    }

    public static String getNumeroCuentaFormato(String strNumeroCuenta) {
        if (isPhoneNumberColombia(strNumeroCuenta)) {
            return getNumeroCelularFormato(strNumeroCuenta);
        }
        if ((strNumeroCuenta != null) && (strNumeroCuenta.length() >= 6)) {
            return "**" + (strNumeroCuenta.substring(strNumeroCuenta.length() - 4));
        }

        return "******";
    }

    public static String getCorreoFormato(String strCorreo) {
        String[] arrCorreo = strCorreo.split("@");
        if (arrCorreo.length == 2) {
            return arrCorreo[0].substring(0, 3).concat("*******@").concat(arrCorreo[1]);
        }
        return strCorreo.substring(0, 3).concat("*******@*******");
    }

    public static String getNumeroCelularFormato(String strNumeroCelular) {
        if ((strNumeroCelular != null) && (strNumeroCelular.length() >= 10)) {
            return "******" + (strNumeroCelular.substring(strNumeroCelular.length() - 4));
        }

        return "**********";
    }

    public static boolean validateVigencia(Calendar fechaVigencia) {
        Calendar cal = Calendar.getInstance();

        return (fechaVigencia.getTime().before(cal.getTime()));
    }

    public static boolean validateVigencia(Date fechaVigencia) {
        Calendar calendarActual = Calendar.getInstance();
        Calendar calendarVigencia = Calendar.getInstance();

        calendarVigencia.setTime(fechaVigencia);

        return (calendarVigencia.getTime().before(calendarActual.getTime()));
    }

    public static Boolean validateTwoDatesByFormat(String format1, String str1, String format2, String str2, Boolean passNull){
        Date date1 = null;
        Date date2 = null;
        try {
            date1 = Parametros.getFechaFormato(format1, str1);
            date2 = Parametros.getFechaFormato(format2, str2);
        } catch (Exception e) {
        }
        if((date1 == null || date2 == null) && !passNull){
            return false;
        }
        if (date1 != null && date2 != null && 
            !Parametros.getFechaNormalString(date1).equals(Parametros.getFechaNormalString(date2))
        ) {
            return false;
        }
        return true;
    }

    public static String getHash(String strInput) {

        if (strInput == null) {
            return null;
        }

        return DigestUtils.sha256Hex(strInput);
    }

    public static String getUUID() {
        UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();

        return randomUUIDString;
    }

    public static String getOTP() {
        int longitud = 6;
        int numEntero = random.nextInt(999999);

        return Parametros.fillLeft(numEntero, longitud);
    }

    public static String getAutorizacion() {
        int longitud = 6;
        int numEntero = random.nextInt(999999);

        return Parametros.fillLeft(numEntero, longitud);
    }

    private static String fillLeft(int valor, int longitud) {
        String cadenaInput = String.valueOf(valor);
        String cadenaOutput = cadenaInput;
        int fill = longitud - (cadenaInput.length());

        if (cadenaInput.length() > longitud) {
            return cadenaInput.substring(0, longitud);
        }

        if (fill == 0) {
            return cadenaOutput;
        }

        for (int i = 1; i <= fill; i++) {
            cadenaOutput = "0" + cadenaOutput;
        }

        return cadenaOutput;
    }

    public static String fillLeftZero(int valor, int longitud) {
        String cadenaInput = String.valueOf(valor);
        String cadenaOutput = cadenaInput;
        int fill = longitud - (cadenaInput.length());

        if (fill == 0) {
            return cadenaOutput;
        }

        for (int i = 1; i <= fill; i++) {
            cadenaOutput = "0" + cadenaOutput;
        }

        return cadenaOutput;
    }

    public static String fillLeftZero(String cadenaInput, int longitud) {
        String cadenaOutput = cadenaInput;
        int fill = longitud - (cadenaInput.length());

        if (fill == 0) {
            return cadenaOutput;
        }

        for (int i = 1; i <= fill; i++) {
            cadenaOutput = "0" + cadenaOutput;
        }

        return cadenaOutput;
    }

    public static String fillRightSpace(String cadenaInput, int longitud) {
        String cadenaOutput = cadenaInput;
        int fill = longitud - (cadenaInput.length());

        if (fill == 0) {
            return cadenaOutput;
        }

        for (int i = 1; i <= fill; i++) {
            cadenaOutput = cadenaOutput + " ";
        }

        return cadenaOutput;
    }

    public static String encodeBase64(String strInput) throws UnsupportedEncodingException {

        if (strInput == null) {
            throw new UnsupportedEncodingException("Encode strInput can't be null");
        }

        return Base64.getEncoder().encodeToString(strInput.getBytes(StandardCharsets.UTF_8));
    }

    public static String decodeBase64(String strInputEncode) throws UnsupportedEncodingException {

        if (strInputEncode == null) {
            throw new UnsupportedEncodingException("Encode strInputEncode can't be null");
        }

        byte[] base64decodedBytes = Base64.getDecoder().decode(strInputEncode);

        return new String(base64decodedBytes, StandardCharsets.UTF_8);
    }

    public static TransaccionRequestVPGP Encrypt(String classObject, String mensaje, String id,
            String idKeyPGP) throws Exception {
        PGP pgp = new PGP();
        TransaccionRequestVPGP transaccionRequestVPGP = null;

        if (classObject == null) {
            throw new Exception("Object to encrypt is null");
        }

        if (mensaje == null) {
            throw new Exception("Mensaje to encrypt is null");
        }

        if (id == null) {
            throw new Exception("Id to encrypt is null");
        }

        try {

            transaccionRequestVPGP = new TransaccionRequestVPGP();

            transaccionRequestVPGP.setObjeto(Parametros.encodeBase64(classObject));
            transaccionRequestVPGP.setMensaje(pgp.encrypt(mensaje, idKeyPGP));
            transaccionRequestVPGP.setId(Parametros.encodeBase64(id));

        } catch (Exception exc) {
            throw new Exception(exc.getMessage());
        }

        return transaccionRequestVPGP;
    }

    public static String EncryptFromString(String strInput, String idKeyPGP) throws Exception {
        PGP pgp = new PGP();
        String strEncrypt = null;

        if (strInput == null) {
            throw new Exception("StrInput to encrypt is null");
        }

        if (idKeyPGP == null) {
            throw new Exception("IdKeyPGP to Encrypt is null");
        }

        try {
            strEncrypt = pgp.encrypt(strInput, idKeyPGP);
        } catch (Exception exc) {
            throw new Exception(exc.getMessage());
        }

        return strEncrypt;
    }

    public static boolean EncryptFromFile(String fileInput, String publicKey) throws Exception {
        PGP pgp = new PGP();
        boolean result = false;

        try {

            result = pgp.encryptFromFile(fileInput, publicKey);
        } catch (Exception exc) {
            throw new Exception(exc.getMessage());
        }

        return result;
    }

    public static TransaccionRequestVPGP Decrypt(TransaccionRequestVPGP transaccionRequestVPGP,
            String passphrase) throws Exception {
        PGP pgp = new PGP();
        TransaccionRequestVPGP transaccionRequestResultVPGP = null;

        if (transaccionRequestVPGP == null) {
            throw new Exception("Object to Decrypt is Null");
        }

        if (passphrase == null) {
            throw new Exception("Passphrase is Null");
        }

        String mensajeDecrypt = null;

        try {

            transaccionRequestResultVPGP = new TransaccionRequestVPGP();

            mensajeDecrypt = pgp.decrypt(transaccionRequestVPGP.getMensaje(), passphrase);

            transaccionRequestResultVPGP
                    .setObjeto(Parametros.decodeBase64(transaccionRequestVPGP.getObjeto()));
            transaccionRequestResultVPGP.setMensaje(mensajeDecrypt);

        } catch (Exception exc) {
            throw new Exception(exc.getMessage());
        }

        return transaccionRequestResultVPGP;
    }

    public static String DecryptFromString(String strEncrypt, String passphrase) throws Exception {
        PGP pgp = new PGP();
        String strDecrypt = null;

        if (strEncrypt == null) {
            throw new Exception("StrEncrypt to Decrypt is Null");
        }

        if (passphrase == null) {
            throw new Exception("Passphrase is Null");
        }

        try {

            strDecrypt = pgp.decrypt(strEncrypt, passphrase);

        } catch (Exception exc) {
            throw new Exception(exc.getMessage());
        }

        return strDecrypt;
    }

    public static File DecryptFromFile(File fileInputEncrypt, String fileName, String passphrase)
            throws Exception {
        PGP pgp = new PGP();
        File result = null;

        try {

            result = pgp.decryptFromFile(fileInputEncrypt, fileName, passphrase);

        } catch (Exception exc) {
            throw new Exception(exc.getMessage());
        }

        return result;
    }

    public static boolean validateOnlyDigits(String strValidate) {
        String regex = "[0-9]+";

        return strValidate.matches(regex);
    }

    public static boolean validateOnlyLetters(String strValidate) {
        Pattern pattern = Pattern.compile("^[a-zA-ZñÑ\\s]*$");
        Matcher matcher = pattern.matcher(strValidate);

        return matcher.matches();
    }

    public static boolean validateOnlyLettersAndAccents(String strValidate) {
        Pattern pattern = Pattern.compile("^[a-zA-ZÀ-ÿñÑ\\s]*$");
        Matcher matcher = pattern.matcher(strValidate);

        return matcher.matches();
    }

    public static boolean validateOnlyLettersAndDigits(String strValidate) {
        Pattern pattern = Pattern.compile("^[0-9a-zA-ZÀ-ÿñÑ\\s]*$");
        Matcher matcher = pattern.matcher(strValidate);

        return matcher.matches();
    }

    public static boolean validateEmail(String strValidate) {
        Pattern pattern = Pattern
                .compile("^([0-9a-zA-Z]+[-._+&])*[0-9a-zA-Z]+@([-0-9a-zA-Z]+[.])+[a-zA-Z]{2,6}$");
        Matcher matcher = pattern.matcher(strValidate);

        return matcher.matches();
    }

    public static String readFileOneLine(Path file) throws IOException {
        if (file == null) {
            throw new IOException("File is null");
        }

        String contenido = null;
        List<String> listaRegistros = new ArrayList<>();
        Stream<String> stream = null;

        try {

            stream = Files.lines(file);
            listaRegistros = stream.collect(Collectors.toList());

            if (listaRegistros.size() == 1) {
                contenido = listaRegistros.get(0);
            } else {
                throw new IOException("Contenido errado para el archivo seleccionado!");
            }
        } catch (IOException exc) {
            throw new IOException("Error de lectura en archivo!: " + exc.getMessage());
        } finally {
            if (stream != null) {
                stream.close();
            }
        }

        return contenido;
    }

    public static String readFile(Path file) throws IOException {
        if (file == null) {
            throw new IOException("File is null");
        }

        String contenido = "";
        List<String> listaRegistros = new ArrayList<>();

        // loadFile
        try (Stream<String> stream = Files.lines(file)) {
            listaRegistros = stream.collect(Collectors.toList());

            for (String linea : listaRegistros) {
                contenido += linea;
            }
        } catch (IOException exc) {
            throw new IOException("Error de lectura en archivo!: " + exc.getMessage());
        }

        return contenido;
    }

    public static boolean validateNovedad(String fileName) throws InvalidRequestException {
        String extensionFile = "";

        if (fileName.lastIndexOf(".") == -1) {
            throw new InvalidRequestException(
                    "Formato de archivo no valido, no tiene una extension asociada!");
        }

        extensionFile = fileName.substring(fileName.lastIndexOf("."));

        if (!extensionFile.equals(Parametros.EXTENSION_NOVEDAD_ASC)
                && !extensionFile.equals(Parametros.EXTENSION_NOVEDAD_PGP)
                && !extensionFile.equals(Parametros.EXTENSION_NOVEDAD_GPG)
                && !extensionFile.equals(Parametros.EXTENSION_NOVEDAD_XLS)
                && !extensionFile.equals(Parametros.EXTENSION_NOVEDAD_XLSX)) {

            throw new InvalidRequestException(
                    "Formato de archivo no valido, extension no soportada!");
        }

        return true;
    }

    public static boolean validateToken(String fileName) throws Exception {
        String extensionFile = "";

        if (fileName.lastIndexOf(".") == -1) {
            throw new Exception("Formato de archivo no valido!");
        }

        extensionFile = fileName.substring(fileName.lastIndexOf("."));

        if (fileName.indexOf(".") != fileName.lastIndexOf(".")) {
            throw new Exception("Formato de archivo no valido, contiene caracteres especiales!");
        }

        if (extensionFile.length() != 4) {
            throw new Exception("Formato de archivo no valido, extension de longitud errada!");
        }

        if (!extensionFile.equals(Parametros.EXTENSION_TOKEN)) {
            throw new Exception("Formato de archivo no valido, extension no soportada!");
        }

        return true;
    }

    public static byte[] decodeBase64ToBytes(String strInputEncode)
            throws UnsupportedEncodingException {

        if (strInputEncode == null) {
            throw new UnsupportedEncodingException("Encode strInputEncode can't be null");
        }

        return Base64.getMimeDecoder().decode(strInputEncode);
    }
}
