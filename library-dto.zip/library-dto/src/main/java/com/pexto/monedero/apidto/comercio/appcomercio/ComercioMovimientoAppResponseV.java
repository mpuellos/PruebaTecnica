package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;
import java.util.Date;

import com.pexto.monedero.apidto.utils.Parametros;

public class ComercioMovimientoAppResponseV implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long idTransaccion;
	private String uuidTransaccion;
	private Date fechaTransaccion;
	private String naturalezaTransaccion;
	private String numeroAutorizacion;
	private double valorTransaccion;
	private Long idComercio;
	private String uuidComercio;
	private String nombreComercio;
	private String nombreSucursal;
	private String codigoTerminal;
	private String nombreTerminal;
	private String estadoTransaccion;
	private String descripcionEstadoTransaccion;
	private String tipoTransaccion;
	private String descripcionTipoTransaccion;
	private String numeroCuenta;
	
	public ComercioMovimientoAppResponseV() {

	}
	
	public ComercioMovimientoAppResponseV(Long idComercio, String uuidComercio, String nombreComercio, Long idTransaccion, String uuidTransaccion, 
			Date fechaTransaccion, String numeroAutorizacion, double valorTransaccion, String nombreSucursal, String codigoTerminal,
			String nombreTerminal, String estadoTransaccion, String descripcionEstadoTransaccion, String tipoTransaccion, 
			String descripcionTipoTransaccion, String naturalezaTransaccion, String numeroCuenta) {

		this.idComercio 					= idComercio;
		this.uuidComercio 					= uuidComercio;
		this.nombreComercio 				= nombreComercio;
		this.idTransaccion 					= idTransaccion;
		this.uuidTransaccion 				= uuidTransaccion;
		this.fechaTransaccion 				= fechaTransaccion;
		this.naturalezaTransaccion			= naturalezaTransaccion;
		this.numeroAutorizacion 			= numeroAutorizacion;
		this.valorTransaccion 				= valorTransaccion;
		this.nombreSucursal 				= nombreSucursal;
		this.codigoTerminal 				= codigoTerminal;
		this.nombreTerminal 				= nombreTerminal;
		this.estadoTransaccion 				= estadoTransaccion;
		this.descripcionEstadoTransaccion 	= descripcionEstadoTransaccion;
		this.tipoTransaccion 				= tipoTransaccion;
		this.descripcionTipoTransaccion		= descripcionTipoTransaccion;
		
		try {
			this.numeroCuenta				= Parametros.decodeBase64(numeroCuenta);
		}catch(Exception exc) {	
			this.numeroCuenta				= numeroCuenta;
		}
	}

	public Long getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getUuidTransaccion() {
		return uuidTransaccion;
	}

	public void setUuidTransaccion(String uuidTransaccion) {
		this.uuidTransaccion = uuidTransaccion;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public double getValorTransaccion() {
		return valorTransaccion;
	}

	public void setValorTransaccion(double valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}

	public Long getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public String getUuidComercio() {
		return uuidComercio;
	}

	public void setUuidComercio(String uuidComercio) {
		this.uuidComercio = uuidComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}

	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public String getNombreSucursal() {
		return nombreSucursal;
	}

	public void setNombreSucursal(String nombreSucursal) {
		this.nombreSucursal = nombreSucursal;
	}

	public String getCodigoTerminal() {
		return codigoTerminal;
	}

	public void setCodigoTerminal(String codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}

	public String getNombreTerminal() {
		return nombreTerminal;
	}

	public void setNombreTerminal(String nombreTerminal) {
		this.nombreTerminal = nombreTerminal;
	}

	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}

	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}

	public String getDescripcionEstadoTransaccion() {
		return descripcionEstadoTransaccion;
	}

	public void setDescripcionEstadoTransaccion(String descripcionEstadoTransaccion) {
		this.descripcionEstadoTransaccion = descripcionEstadoTransaccion;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public String getDescripcionTipoTransaccion() {
		return descripcionTipoTransaccion;
	}

	public void setDescripcionTipoTransaccion(String descripcionTipoTransaccion) {
		this.descripcionTipoTransaccion = descripcionTipoTransaccion;
	}

	public String getNaturalezaTransaccion() {
		return naturalezaTransaccion;
	}

	public void setNaturalezaTransaccion(String naturalezaTransaccion) {
		this.naturalezaTransaccion = naturalezaTransaccion;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
}
