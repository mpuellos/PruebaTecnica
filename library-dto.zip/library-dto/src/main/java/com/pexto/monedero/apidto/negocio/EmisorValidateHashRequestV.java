package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class EmisorValidateHashRequestV implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private Long idEmisor;
	private String hash;
	
	public EmisorValidateHashRequestV() {
		
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public String getHash() {
		return hash;
	}
	
	public void setHash(String hash) {
		this.hash = hash;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		if (this.idEmisor == null) {
			throw new Exception ("Error campo Id Emisor is null");
		}
		
		if (this.hash == null) {
			throw new Exception ("Error campo hash is null");
		}
		
		if (this.idEmisor <= 0) {
			throw new Exception ("Error campo Id Emisor no valido!");
		}
		
		if (this.hash.trim().equals("")) {
			throw new Exception ("Error campo hash esta vacio!");
		}
		
		return true;
	}
	
}
