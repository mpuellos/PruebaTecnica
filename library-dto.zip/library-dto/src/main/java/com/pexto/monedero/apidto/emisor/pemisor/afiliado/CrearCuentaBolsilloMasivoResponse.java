package com.pexto.monedero.apidto.emisor.pemisor.afiliado;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class CrearCuentaBolsilloMasivoResponse implements Serializable {
    /**
    *
    */
    private static final long serialVersionUID = 1330854800024890416L;
    private String estado;
    private String mensaje;
    private List<Map<String, String>> masiveWallets;

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public List<Map<String, String>> getMasiveWallets() {
        return masiveWallets;
    }

    public void setMasiveWallets(List<Map<String, String>> masiveWallets) {
        this.masiveWallets = masiveWallets;
    }

}
