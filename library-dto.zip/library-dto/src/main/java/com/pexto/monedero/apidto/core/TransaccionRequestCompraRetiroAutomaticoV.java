package com.pexto.monedero.apidto.core;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionRequestCompraRetiroAutomaticoV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("tokenComercio")
	private String tokenComercio;
	
	@JsonProperty("tokenTerminal")
	private String tokenTerminal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("valor")
	private double valor;
	
	@JsonProperty("otp")
	private String otp;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("fechaTransaccion")
	private Date fechaTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("idUsuarioComercio")
	private Long idUsuarioComercio;
	
	@JsonProperty("authorization")
	private String authorization;
	
	@JsonProperty("paramRequest")
	private ParamRequestV paramRequest;
	
	public TransaccionRequestCompraRetiroAutomaticoV() {
		this.tokenComercio 		= null;
		this.tokenTerminal 		= null;
		this.numeroCuenta 		= null;
		this.valor 				= 0;
		this.otp 				= null;
		this.tipoTransaccion 	= null;
		this.fechaTransaccion	= new Date();
		this.numeroAutorizacion	= "0";
		this.idUsuarioComercio 	= 0L;
		this.authorization		= "";
		this.paramRequest		= null;
	}
	
	public String getTokenComercio() {
		return tokenComercio;
	}

	public String getTokenTerminal() {
		return tokenTerminal;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public double getValor() {
		return valor;
	}

	public String getOtp() {
		return otp;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public Long getIdUsuarioComercio() {
		return idUsuarioComercio;
	}
	
	public String getAuthorization() {
		return authorization;
	}

	public ParamRequestV getParamRequest() {
		return paramRequest;
	}

	public void setTokenComercio(String tokenComercio) {
		this.tokenComercio = tokenComercio;
	}

	public void setTokenTerminal(String tokenTerminal) {
		this.tokenTerminal = tokenTerminal;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public void setIdUsuarioComercio(Long idUsuarioComercio) {
		this.idUsuarioComercio = idUsuarioComercio;
	}
	
	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}
	
	public void setParamRequest(ParamRequestV paramRequest) {
		this.paramRequest = paramRequest;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		//VALIDATION NULL
		
		if (this.tokenComercio == null) {
			throw new Exception("TokenComercio - null!");
		}
		
		if (this.tokenTerminal == null) {
			throw new Exception("TokenTerminal - null!");
		}
		
		if (this.numeroCuenta == null) {
			throw new Exception("Numero de cuenta - null!");
		}
		
		if (this.otp == null) {
			throw new Exception("OTP - null!");
		}
		
		if (this.tipoTransaccion == null) {
			throw new Exception("TipoTransaccion - null!");
		}
		
		if (this.fechaTransaccion == null) {
			throw new Exception("FechaTransaccion - null!");
		}
		
		//VALIDATION EMPTY
		
    	if (this.tokenComercio.equals("")) {
    		throw new Exception("TokenComercio vacio!");
		}
    	
    	if (this.tokenTerminal.equals("")) {
    		throw new Exception("TokenTerminal vacio!");
		}
    	
    	if (this.numeroCuenta.equals("")) {
    		throw new Exception("Numero de cuenta vacio!");
    	}
    	
    	if (this.otp.equals("")) {
    		throw new Exception("OTP vacio!");
		}
    	
    	if (this.tipoTransaccion.equals("")) {
    		throw new Exception("Tipo Transaccion vacio!");
    	}
    	
    	if (String.valueOf(this.valor).equals("")) {
    		throw new Exception("Valor vacio!");
    	}
    	
    	//VALIDATION DATA_VALUES
    	
    	//validate_ValorPositivo
    	if (this.valor <= 0) {
    		throw new Exception("Ingrese un valor correcto!");
    	}
    	
    	//validate_tipoTransaccionCompraRetiro
    	if (!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_COMPRA) 
    			&& !this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_RETIRO) 
    				&& !this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_COMPRA) 
    					&& !this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_RETIRO)
    						&& !this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_COMPRA_QR) 
    							&& !this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_RETIRO_QR) 
    								&& !this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_COMPRA_QR) 
    									&& !this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_RETIRO_QR)) {
    		
    		throw new Exception("Ingrese un tipo de transacción correcto!");
    	}
		
		return valid;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TransaccionRequestCompraRetiroAutomaticoV [tokenComercio=");
		builder.append(tokenComercio);
		builder.append(", tokenTerminal=");
		builder.append(tokenTerminal);
		builder.append(", numeroCuenta=");
		builder.append(numeroCuenta);
		builder.append(", valor=");
		builder.append(valor);
		builder.append(", otp=");
		builder.append(otp);
		builder.append(", tipoTransaccion=");
		builder.append(tipoTransaccion);
		builder.append(", fechaTransaccion=");
		builder.append(fechaTransaccion);
		builder.append(", numeroAutorizacion=");
		builder.append(numeroAutorizacion);
		builder.append(", idUsuarioComercio=");
		builder.append(idUsuarioComercio);
		builder.append(", authorization=");
		builder.append(authorization);
		builder.append(", paramRequest=");
		builder.append(paramRequest);
		builder.append("]");
		return builder.toString();
	}
	
}
