package com.pexto.monedero.apidto.enterprises;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EnterpriseUserPut {

    Long id;
    String uuid;
    String logon;
    Long idPerfil;
    String vigencia;
    String estadoUsuario;
    String numeroDocumento;
    String nombres;
    String apellidos;
    String correo;
    String nroCelular;
    String cargo;
    String estado;

}
