package com.pexto.monedero.apidto.route53.Request;

import com.pexto.monedero.apidto.route53.LoadBalancerCore;

public class SubDomainCreateRequestRoute53 {
    private String subdomain;
    private LoadBalancerCore loadBalancer;

    public String getSubdomain() {
        return subdomain;
    }

    public void setSubdomain(String subdomain) {
        this.subdomain = subdomain;
    }

    public LoadBalancerCore getLoadBalancer() {
        return loadBalancer;
    }

    public void setLoadBalancer(LoadBalancerCore loadBalancer) {
        this.loadBalancer = loadBalancer;
    }

}
