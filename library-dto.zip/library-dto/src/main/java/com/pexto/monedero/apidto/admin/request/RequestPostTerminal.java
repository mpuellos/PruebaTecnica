package com.pexto.monedero.apidto.admin.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class RequestPostTerminal implements Serializable ,IRequestValidator{

	private static final long serialVersionUID = 1L;

	@JsonProperty("id")	
	private Long id;
	
	@JsonProperty("token")	
	private String token;
	
	@JsonProperty("codigo")	
	private String codigo;
	
	@JsonProperty("nombre")	
	private String nombre;
	
	@JsonProperty("codigoTerminalRed")	
	private String codigoTerminalRed;
	
	@JsonProperty("isDefault")	
	private String defecto;
	
	@JsonProperty("fecha")	
	private String fecha;
	
	@JsonProperty("estado")	
	private String estado;	
	
	@JsonProperty("sucursalId")	
	private String sucursalId;
	
	@JsonProperty("usuarioAdminId")	
	private String usuarioAdminId;
	
	@JsonProperty("hash")	
	private String hash;
	
	

	public String getToken() {
		return token;
	}



	public void setToken(String token) {
		this.token = token;
	}



	public String getCodigo() {
		return codigo;
	}



	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}



	public String getNombre() {
		return nombre;
	}



	public void setNombre(String nombre) {
		this.nombre = nombre;
	}



	public String getCodigoTerminalRed() {
		return codigoTerminalRed;
	}



	public void setCodigoTerminalRed(String codigoTerminalRed) {
		this.codigoTerminalRed = codigoTerminalRed;
	}



	public String getDefecto() {
		return defecto;
	}



	public void setDefecto(String defecto) {
		this.defecto = defecto;
	}



	public String getFecha() {
		return fecha;
	}



	public void setFecha(String fecha) {
		this.fecha = fecha;
	}



	public String getEstado() {
		return estado;
	}



	public void setEstado(String estado) {
		this.estado = estado;
	}



	public String getSucursalId() {
		return sucursalId;
	}



	public void setSucursalId(String sucursalId) {
		this.sucursalId = sucursalId;
	}



	public String getUsuarioAdminId() {
		return usuarioAdminId;
	}



	public void setUsuarioAdminId(String usuarioAdminId) {
		this.usuarioAdminId = usuarioAdminId;
	}



	public String getHash() {
		return hash;
	}



	public void setHash(String hash) {
		this.hash = hash;
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		return valid;
	}	
		
	
}