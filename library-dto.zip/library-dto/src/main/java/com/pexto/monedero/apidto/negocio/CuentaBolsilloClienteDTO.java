package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.List;

public class CuentaBolsilloClienteDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private ClienteDTO cliente;
	private CuentaDTO cuenta;
	private CuentaBolsilloDTO cuentaBolsillo;
	private List<CuentaBolsilloDTO> listaCuentaBolsillo;
	
	public ClienteDTO getCliente() {
		return cliente;
	}
	
	public void setCliente(ClienteDTO cliente) {
		this.cliente = cliente;
	}
	
	public CuentaDTO getCuenta() {
		return cuenta;
	}
	
	public void setCuenta(CuentaDTO cuenta) {
		this.cuenta = cuenta;
	}
	
	public CuentaBolsilloDTO getCuentaBolsillo() {
		return cuentaBolsillo;
	}
	
	public void setCuentaBolsillo(CuentaBolsilloDTO cuentaBolsillo) {
		this.cuentaBolsillo = cuentaBolsillo;
	}
	
	public List<CuentaBolsilloDTO> getListaCuentaBolsillo() {
		return listaCuentaBolsillo;
	}
	
	public void setListaCuentaBolsillo(List<CuentaBolsilloDTO> listaCuentaBolsillo) {
		this.listaCuentaBolsillo = listaCuentaBolsillo;
	}
	
}
