package com.pexto.monedero.apidto.core;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class NovedadRequestV implements Serializable, ITransaccionRequestValidator {

	private static final long serialVersionUID = 1L;

	@JsonProperty("idNovedad")
	private Long idNovedad;

	@JsonProperty("idEmisor")
	private Long idEmisor;

	@JsonProperty("idUsuarioEmisor")
	private Long idUsuarioEmisor;

	@JsonProperty("tipoNovedad")
	private String tipoNovedad;

	@JsonProperty("motivoRechazo")
	private String motivoRechazo;

	private boolean comfirmacionSaldo;

	@JsonProperty("paramRequest")
	private ParamRequestV paramRequest;

	private Long idNovedadDetalle;

	public NovedadRequestV() {

	}

	public Long getIdNovedad() {
		return idNovedad;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public Long getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public ParamRequestV getParamRequest() {
		return paramRequest;
	}

	public void setIdNovedad(Long idNovedad) {
		this.idNovedad = idNovedad;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public void setIdUsuarioEmisor(Long idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public void setParamrequest(ParamRequestV paramRequest) {
		this.paramRequest = paramRequest;
	}

	public String getMotivoRechazo() {
		return motivoRechazo;
	}

	public void setMotivoRechazo(String motivoRechazo) {
		this.motivoRechazo = motivoRechazo;
	}

	public Long getIdNovedadDetalle() {
		return idNovedadDetalle;
	}

	public void setIdNovedadDetalle(Long idNovedadDetalle) {
		this.idNovedadDetalle = idNovedadDetalle;
	}

	public boolean isComfirmacionSaldo() {
		return comfirmacionSaldo;
	}

	public void setComfirmacionSaldo(boolean comfirmacionSaldo) {
		this.comfirmacionSaldo = comfirmacionSaldo;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;

		// VALIDATION NULL

		if (this.idNovedad == null) {
			throw new Exception("IdNovedad - null!");
		}

		if (this.idEmisor == null) {
			throw new Exception("IdEmisor - null!");
		}

		if (this.idUsuarioEmisor == null) {
			throw new Exception("IdUsuarioEmisor - null!");
		}

		if (this.tipoNovedad == null) {
			throw new Exception("Tipo Novedad - null!");
		}

		// VALIDATION EMPTY

		if (String.valueOf(this.idNovedad).equals("")) {
			throw new Exception("IdNovedad vacio!");
		}

		if (String.valueOf(this.idEmisor).equals("")) {
			throw new Exception("IdEmisor vacio!");
		}

		if (String.valueOf(this.idUsuarioEmisor).equals("")) {
			throw new Exception("IdUsuarioEmisor vacio!");
		}

		// validate_tipoNovedad
		if (!this.tipoNovedad.equals(Parametros.TRANSACCION_TIPO_CREACION_CUENTA)
				&& !this.tipoNovedad.equals(Parametros.TRANSACCION_TIPO_REEXPEDICION_CUENTA)
				&& !this.tipoNovedad.equals(Parametros.TRANSACCION_TIPO_ABONO)
				&& !this.tipoNovedad.equals(Parametros.TRANSACCION_TIPO_CARGO)) {

			throw new Exception("Ingrese un tipo de novedad correcto!");
		}

		return valid;
	}

	public boolean validateComfirmacionSaldo() throws Exception {

		boolean valid = true;

		if (this.comfirmacionSaldo == false) {
			throw new Exception("Confirmacion de saldo no aceptada!");
		}

		if (String.valueOf(this.comfirmacionSaldo).equals("")) {
			throw new Exception("Confirmacion de saldo no aceptada!");
		}
		
		return valid;
	}

}