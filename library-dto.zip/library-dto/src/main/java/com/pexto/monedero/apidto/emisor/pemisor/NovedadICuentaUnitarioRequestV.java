package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;
import java.util.Date;

import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;
import org.apache.commons.lang3.StringUtils;

public class NovedadICuentaUnitarioRequestV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private Date fechaRegistro;
	private Date fechaProceso;
	private String ipOrigen;
	private String numeroCuenta;
	private String numeroCuentaHash;
	private String numeroCuentaEncode;
	private String numeroDocumento;
	private String tipoDocumento;
	private String nombres;
	private String apellidos;
	private String correoElectronico;
	private Date fechaNacimiento;
	private Date fechaExpedicion;
	private String codigoProducto;
	private double valor;
	private Date fecha;
	private String estado;
	private String tipoOperacion;
	private String tipoNovedad;
	private String numeroCelular;
	private Long idEmisor;
	private Long idBolsillo;
	private Long idTransaccion;
	private String codigoCausal;
	private Long idUsuarioEmisor;
	private String hash;
	
	private String fechaNac;
	private String fechaExp;
	
	public Long getId() {
		return id;
	}

	public String getUuid() {
		return uuid;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public Date getFechaProceso() {
		return fechaProceso;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public String getNumeroCuentaHash() {
		return numeroCuentaHash;
	}

	public String getNumeroCuentaEncode() {
		return numeroCuentaEncode;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public Date getFechaExpedicion() {
		return fechaExpedicion;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public double getValor() {
		return valor;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getEstado() {
		return estado;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public Long getIdTransaccion() {
		return idTransaccion;
	}

	public String getCodigoCausal() {
		return codigoCausal;
	}

	public Long getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public String getHash() {
		return hash;
	}

	public String getFechaNac() {
		return fechaNac;
	}

	public String getFechaExp() {
		return fechaExp;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setNumeroCuentaHash(String numeroCuentaHash) {
		this.numeroCuentaHash = numeroCuentaHash;
	}

	public void setNumeroCuentaEncode(String numeroCuentaEncode) {
		this.numeroCuentaEncode = numeroCuentaEncode;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public void setFechaExpedicion(Date fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public void setCodigoCausal(String codigoCausal) {
		this.codigoCausal = codigoCausal;
	}

	public void setIdUsuarioEmisor(Long idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public void setFechaNac(String fechaNac) {
		this.fechaNac = fechaNac;
	}

	public void setFechaExp(String fechaExp) {
		this.fechaExp = fechaExp;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		
		if (this.numeroDocumento == null || this.numeroDocumento.equals("")) {
			throw new Exception("Error en el campo Numero de Documento is null!");
		}else {
			if (!Parametros.validateOnlyDigits(numeroDocumento)) {
				throw new Exception ("Error en el campo Numero de Documento, valor errado: " + numeroDocumento);
			}
			
			Long numeroDocumentoLong = Long.parseLong(numeroDocumento);
			
			if (numeroDocumentoLong <= 0) {
				throw new Exception ("Error en el registro - campo Numero de Documento, valor inferior o igual a 0: " + numeroDocumento);
			}
		}
		
		if (this.tipoDocumento == null || this.tipoDocumento.equals("")) {
			throw new Exception("Tipo de documento - null!");
		}else {
			if (!Parametros.validateOnlyDigits(tipoDocumento)) {
				throw new Exception ("Error en el campo Tipo de Documento, valor errado: " + numeroDocumento);
			}
		}
		
		if (this.nombres == null || this.nombres.equals("")) {
			throw new Exception("Nombres - null!");
		}else {
			if (!Parametros.validateOnlyLettersAndDigits(nombres)) {
				throw new Exception ("Error en el campo Nombres, valor errado: " + nombres);
			}
		}
		
		if (this.apellidos == null || this.apellidos.equals("")) {
			throw new Exception("Apellidos - null!");
		}else {
			if (!Parametros.validateOnlyLettersAndDigits(nombres)) {
				throw new Exception ("Error en el campo Apellidos, valor errado: " + nombres);
			}
		}
		
		if (this.correoElectronico == null) {
			this.correoElectronico = StringUtils.EMPTY;
		}
		
		if (this.numeroCelular == null || this.numeroCelular.equals("")) {
			throw new Exception("Numero de celular - null!");
		}else {
			if (!Parametros.validateOnlyDigits(numeroCelular)) {
				throw new Exception ("Error en el campo numero de celular, valor errado: " + numeroCelular);
			}
			
			Long numeroCelularLong = Long.parseLong(numeroCelular);
			
			if (numeroCelularLong <= 0) {
				throw new Exception ("Error en el registro - campo Numero de Celular, valor inferior o igual a 0: " + numeroCelular);
			}
		}
		
		if (this.numeroCuenta == null || this.numeroCuenta.equals("")) {
			throw new Exception("Numero de cuenta - null!");
		}else {
			if (!Parametros.validateOnlyDigits(numeroCuenta)) {
				throw new Exception ("Error en el campo Numero de Cuenta, valor errado: " + numeroCuenta);
			}
			
			Long numeroCuentaLong = Long.parseLong(numeroCuenta);
			
			if (numeroCuentaLong <= 0) {
				throw new Exception ("Error en el campo Numero de Cuenta, valor errado, valor inferior o igual a 0: " + numeroCuenta);
			}
		}
		
		if (this.fechaNac == null || this.fechaNac.equals("")) {
			throw new Exception("Error en el campo Fecha de nacimiento - null!");
		}
		
		if (this.fechaExp == null || this.fechaExp.equals("")) {
			throw new Exception("Error en el campo Fecha de expedicion - null!");
		}
		
		if (this.idEmisor == null || String.valueOf(this.idEmisor).equals("")) {
			throw new Exception("Error en el campo Id Emisor - null!");
		}
		
		if (this.idBolsillo == null || String.valueOf(this.idBolsillo).equals("")) {
			throw new Exception("Error en el campo Id Bolsillo - null!");
		}
		
		return true;
	}
	
}
