package com.pexto.monedero.apidto.emisor.pemisor.afiliado;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class CrearCuentaBolsilloMasivoRequest implements Serializable, IRequestValidator {

	/**
	*
	*/
	private static final long serialVersionUID = 739401004899477628L;

	private List<Map<String, String>> masiveClients;
	private String workplaceBankCode;
	private String walletType;

	@Override
	public boolean validateProperties() throws Exception {

		if ((workplaceBankCode == null) || (workplaceBankCode.trim().length() == 0)) {
			throw new Exception("El campo Workplace Bank Code esta vacio o errado!");
		}

		if ((walletType == null) || (walletType.trim().length() == 0)) {
			throw new Exception("El campo Wallet Type esta vacio!");
		}

		if (!walletType.equals(Parametros.PRESTAMOS_WALLET_TYPE_PRIMARY)
				&& !walletType.equals(Parametros.PRESTAMOS_WALLET_TYPE_LOAN)) {
			throw new Exception("Campo Wallet Type no permitido!");
		}
		return false;
	}

	public String getWorkplaceBankCode() {
		return workplaceBankCode;
	}

	public void setWorkplaceBankCode(String workplaceBankCode) {
		this.workplaceBankCode = workplaceBankCode;
	}

	public String getWalletType() {
		return walletType;
	}

	public void setWalletType(String walletType) {
		this.walletType = walletType;
	}

	public List<Map<String, String>> getMasiveClients() {
		return masiveClients;
	}

	public void setMasiveClients(List<Map<String, String>> masiveClients) {
		this.masiveClients = masiveClients;
	}

}
