package com.pexto.monedero.apidto.sacresponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SacResponse {

  SacClient client;
  SacBalance balance;
  SacOtp lastOtp;
  SacTransaction lastTransaction;
  SacTransaction lastPayment;
  SacLastUpdate lasUpdate;
  
}
