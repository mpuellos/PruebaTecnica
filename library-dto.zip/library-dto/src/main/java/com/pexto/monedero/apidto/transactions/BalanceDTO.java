package com.pexto.monedero.apidto.transactions;

import java.io.Serializable;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
@AllArgsConstructor
@Builder
public class BalanceDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	Long accountNumber;
	Long workplaceBanckCode;
	String workplaceBanckName;
	Long walletId;
	String walletName;
	String walletType;
	Double ammont;
}