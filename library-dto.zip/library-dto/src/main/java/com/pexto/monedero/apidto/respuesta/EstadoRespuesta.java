package com.pexto.monedero.apidto.respuesta;

import java.io.Serializable;

public class EstadoRespuesta implements Serializable {

	private static final long serialVersionUID = 1L;

	// CONSTANTES_ESTADOS_RESPUESTA (1: True 0: False)
	public static final String ESTADO_CADUCADO = "-1";
	public static final String ESTADO_EXITOSO = "1";
	public static final String ESTADO_NO_EXITOSO = "0";
	public static final String ESTADO_IS_PHOTOCOPY 	= "2";
	public static final String ESTADO_IS_NOT_PHOTOCOPY 	= "3";

	protected String estado;
	protected String mensaje;
	protected String id;
	protected String data;
	protected String notificacion;
	private boolean showNotification;

	public EstadoRespuesta() {
		this.estado = EstadoRespuesta.ESTADO_NO_EXITOSO;
		this.mensaje = "";
		this.data = "";
		this.notificacion = "";
		this.id = null;
		this.showNotification = false;
	}

	public EstadoRespuesta(String estado, String mensaje) {
		this.setEstado(estado);
		this.mensaje = mensaje;
		this.data = "";
		this.notificacion = "";
		this.id = null;
		this.showNotification = false;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		switch (estado) {
		case "0":
			this.estado = EstadoRespuesta.ESTADO_NO_EXITOSO;
			break;

		case "1":
			this.estado = EstadoRespuesta.ESTADO_EXITOSO;
			break;

		case "-1":
			this.estado = EstadoRespuesta.ESTADO_CADUCADO;
			break;

		case "2":
			this.estado = EstadoRespuesta.ESTADO_IS_PHOTOCOPY;
			break;

		case "3":
			this.estado = EstadoRespuesta.ESTADO_IS_NOT_PHOTOCOPY;
			break;

		default:
			this.estado = EstadoRespuesta.ESTADO_NO_EXITOSO;
			break;
		}
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getNotificacion() {
		return notificacion;
	}

	public void setNotificacion(String notificacion) {
		this.notificacion = notificacion;
	}

	public boolean isShowNotification() {
		return showNotification;
	}

	public void setShowNotification(boolean showNotification) {
		this.showNotification = showNotification;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EstadoRespuesta [estado=");
		builder.append(estado);
		builder.append(", mensaje=");
		builder.append(mensaje);
		builder.append(", id=");
		builder.append(id);
		builder.append(", data=");
		builder.append(data);
		builder.append(", notificacion=");
		builder.append(notificacion);
		builder.append(", showNotification=");
		builder.append(showNotification);
		builder.append("]");
		return builder.toString();
	}

}