package com.pexto.monedero.apidto.negocio;

import com.pexto.monedero.apidto.respuesta.EstadoRespuesta;

public class EmisorLoginResponseV extends EstadoRespuesta {
	
	private static final long serialVersionUID = 1L;
	
	public static final String ESTADO_NO_EXITOSO = "0";
	public static final String ESTADO_EXITOSO = "1";
	
	private String estado;
	private String mensaje;
	private EmisorLoginResponse login;
	
	public EmisorLoginResponseV() {
		this.estado		= EmisorLoginResponseV.ESTADO_NO_EXITOSO;
		this.mensaje	= "";
		this.login		= null;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public String getMensaje() {
		return mensaje;
	}
	
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
	public EmisorLoginResponse getLogin() {
		return login;
	}
	
	public void setLogin(EmisorLoginResponse login) {
		this.login = login;
	}
}
