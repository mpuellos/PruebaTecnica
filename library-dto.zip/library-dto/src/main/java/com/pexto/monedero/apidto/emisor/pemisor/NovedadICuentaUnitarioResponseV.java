package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;
import java.util.Date;

public class NovedadICuentaUnitarioResponseV implements Serializable {
	
private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private Date fechaRegistro;
	private Date fechaProceso;
	private String ipOrigen;
	private String numeroCuenta;
	private String numeroCuentaHash;
	private String numeroCuentaEncode;
	private String numeroDocumento;
	private String tipoDocumento;
	private String nombres;
	private String apellidos;
	private String correoElectronico;
	private Date fechaNacimiento;
	private Date fechaExpedicion;
	private String codigoProducto;
	private double valor;
	private Date fecha;
	private String estado;
	private String tipoOperacion;
	private String tipoNovedad;
	private String numeroCelular;
	private Long idEmisor;
	private Long idBolsillo;
	private Long idTransaccion;
	private String codigoCausal;
	private Long idUsuarioEmisor;
	private String hash;
	
	private String fechaNac;
	private String fechaExp;
	
	public Long getId() {
		return id;
	}

	public String getUuid() {
		return uuid;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public Date getFechaProceso() {
		return fechaProceso;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public String getNumeroCuentaHash() {
		return numeroCuentaHash;
	}

	public String getNumeroCuentaEncode() {
		return numeroCuentaEncode;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public String getCorreoElectronico() {
		return correoElectronico;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public Date getFechaExpedicion() {
		return fechaExpedicion;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public double getValor() {
		return valor;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getEstado() {
		return estado;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public Long getIdTransaccion() {
		return idTransaccion;
	}

	public String getCodigoCausal() {
		return codigoCausal;
	}

	public Long getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public String getHash() {
		return hash;
	}

	public String getFechaNac() {
		return fechaNac;
	}

	public String getFechaExp() {
		return fechaExp;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setNumeroCuentaHash(String numeroCuentaHash) {
		this.numeroCuentaHash = numeroCuentaHash;
	}

	public void setNumeroCuentaEncode(String numeroCuentaEncode) {
		this.numeroCuentaEncode = numeroCuentaEncode;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public void setFechaExpedicion(Date fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public void setCodigoCausal(String codigoCausal) {
		this.codigoCausal = codigoCausal;
	}

	public void setIdUsuarioEmisor(Long idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public void setFechaNac(String fechaNac) {
		this.fechaNac = fechaNac;
	}

	public void setFechaExp(String fechaExp) {
		this.fechaExp = fechaExp;
	}
	
}
