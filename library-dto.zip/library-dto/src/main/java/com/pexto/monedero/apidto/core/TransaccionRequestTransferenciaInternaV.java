package com.pexto.monedero.apidto.core;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionRequestTransferenciaInternaV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("numeroCuentaOrigen")
	private String numeroCuentaOrigen;
	
	@JsonProperty("numeroCuentaDestino")
	private String numeroCuentaDestino;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	public String getNumeroCuentaOrigen() {
		return numeroCuentaOrigen;
	}

	public String getNumeroCuentaDestino() {
		return numeroCuentaDestino;
	}
	
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	
	public void setNumeroCuentaOrigen(String numeroCuentaOrigen) {
		this.numeroCuentaOrigen = numeroCuentaOrigen;
	}

	public void setNumeroCuentaDestino(String numeroCuentaDestino) {
		this.numeroCuentaDestino = numeroCuentaDestino;
	}
	
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		//VALIDATION NULL
		
		if (this.numeroCuentaOrigen == null || this.numeroCuentaOrigen.equals("")) {
			throw new Exception("Numero de Cuenta Origen - null o vacio!");
		}
		
		if (this.numeroCuentaDestino == null || this.numeroCuentaDestino.equals("")) {
			throw new Exception("Numero de Cuenta Destino - null o vacio!");
		}
			
		if (this.tipoTransaccion == null || this.tipoTransaccion.equals("")) {
			throw new Exception("TipoTransaccion - null o vacio!");
		}	
		
    	if (this.numeroCuentaOrigen.equals(this.numeroCuentaDestino)) {
			throw new Exception ("Cuenta Origen y Destino son iguales");
		}
    	
    	if (!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_TRANSFERENCIA_INTERNA)) {
    		throw new Exception("Ingrese un tipo de transaccion correcto!");
    	}
    	
		return valid;
	}
	
}