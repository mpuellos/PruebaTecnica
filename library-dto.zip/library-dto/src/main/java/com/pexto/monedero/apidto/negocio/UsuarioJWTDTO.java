package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class UsuarioJWTDTO implements Serializable {
    /**
    *
    */
    private static final long serialVersionUID = -5785196445897653253L;
    private String token;
    private String cuenta;
    private String cuentaUUID;
    private Long clienteId;
    private String clienteDocumento;
    private String clienteCorreo;
    private String clienteCelular;
    private String clienteNombreCompleto;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }

    public String getCuentaUUID() {
        return cuentaUUID;
    }

    public void setCuentaUUID(String cuentaUUID) {
        this.cuentaUUID = cuentaUUID;
    }

    public Long getClienteId() {
        return clienteId;
    }

    public void setClienteId(Long clienteId) {
        this.clienteId = clienteId;
    }

    public String getClienteDocumento() {
        return clienteDocumento;
    }

    public void setClienteDocumento(String clienteDocumento) {
        this.clienteDocumento = clienteDocumento;
    }

    public String getClienteCorreo() {
        return clienteCorreo;
    }

    public void setClienteCorreo(String clienteCorreo) {
        this.clienteCorreo = clienteCorreo;
    }

    public String getClienteCelular() {
        return clienteCelular;
    }

    public void setClienteCelular(String clienteCelular) {
        this.clienteCelular = clienteCelular;
    }

    public String getClienteNombreCompleto() {
        return clienteNombreCompleto;
    }

    public void setClienteNombreCompleto(String clienteNombreCompleto) {
        this.clienteNombreCompleto = clienteNombreCompleto;
    }

    public UsuarioJWTDTO() {
    }

    public UsuarioJWTDTO(String token, String cuenta, String cuentaUUID, Long clienteId,
            String clienteDocumento, String clienteCorreo, String clienteCelular,
            String clienteNombreCompleto) {
        this.token = token;
        this.cuenta = cuenta;
        this.cuentaUUID = cuentaUUID;
        this.clienteId = clienteId;
        this.clienteDocumento = clienteDocumento;
        this.clienteCorreo = clienteCorreo;
        this.clienteCelular = clienteCelular;
        this.clienteNombreCompleto = clienteNombreCompleto;
    }
    
}
