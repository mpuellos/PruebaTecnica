package com.pexto.monedero.apidto.integrador.olimpica;

import java.io.Serializable;

public class ResponseVerificarOrden implements Serializable{
	private static final long serialVersionUID = 1L;
	private boolean vigente;
	public boolean isVigente() {
		return vigente;
	}
	public void setVigente(boolean vigente) {
		this.vigente = vigente;
	}
	
	
	
	
}
