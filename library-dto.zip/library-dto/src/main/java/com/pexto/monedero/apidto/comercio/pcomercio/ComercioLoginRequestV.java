package com.pexto.monedero.apidto.comercio.pcomercio;

import com.pexto.monedero.apidto.negocio.ComercioV;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class ComercioLoginRequestV extends ComercioV implements IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private String logon;
	private String password;
	private String codigoSeguridad;
	private Long sucursal;
	private Long terminal;
	private String response;
	private String tipoOperacion;
	private String ipLocal;
	private String ipOrigen;
	private String userAgent;
	private String data;
	
	public ComercioLoginRequestV() {
		
	}
	
	public ComercioLoginRequestV(String logon, String password) {
		this.logon = logon;
		this.password = password;
	}
	
	public String getLogon() {
		return logon;
	}

	public String getPassword() {
		return password;
	}

	public String getCodigoSeguridad() {
		return codigoSeguridad;
	}

	public Long getSucursal() {
		return sucursal;
	}

	public Long getTerminal() {
		return terminal;
	}

	public String getResponse() {
		return response;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public String getIpLocal() {
		return ipLocal;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public String getData() {
		return data;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setCodigoSeguridad(String codigoSeguridad) {
		this.codigoSeguridad = codigoSeguridad;
	}

	public void setSucursal(Long sucursal) {
		this.sucursal = sucursal;
	}

	public void setTerminal(Long terminal) {
		this.terminal = terminal;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public void setIpLocal(String ipLocal) {
		this.ipLocal = ipLocal;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public void setData(String data) {
		this.data = data;
	}

	@Override
	public boolean validateProperties() throws Exception {
		
		if (this.logon == null) {
			throw new Exception ("Campo Logon is null");
		}
		
		if (this.password == null) {
			throw new Exception ("Campo Password is null");
		}
		
		if (this.response == null) {
			throw new Exception ("Error campo response is null");
		}
		
		if (this.logon.trim().equals("")) {
			throw new Exception ("Campo Logon esta vacio!");
		}
		
		if (this.password.trim().equals("")) {
			throw new Exception ("Campo Password esta vacio!");
		}
		
		if (this.response.trim().equals("")) {
			throw new Exception ("Error en casilla de verificacion, captcha no ha sido validado!");
		}
		
		if (this.sucursal != null) {
			if (this.sucursal <= 0) {
				throw new Exception ("Valor errados para sucursal");
			}
		}
		
		if (this.terminal != null) {
			if (this.terminal <= 0) {
				throw new Exception ("Valor errados para terminal");
			}
		}
		
		return true;
	}
}