package com.pexto.monedero.apidto.negocio;

public class ComercioAutorizacionCompraAppV {

	private Long idComercio;
	private String nombreComercio;
	private String tokenComercio;
	private String tokenAutorizacion;
	private String idTerminal;// Terminal por defecto

	public Long getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}

	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public String getTokenComercio() {
		return tokenComercio;
	}

	public void setTokenComercio(String tokenComercio) {
		this.tokenComercio = tokenComercio;
	}

	public String getTokenAutorizacion() {
		return tokenAutorizacion;
	}

	public void setTokenAutorizacion(String tokenAutorizacion) {
		this.tokenAutorizacion = tokenAutorizacion;
	}

	public String getIdTerminal() {
		return idTerminal;
	}

	public void setIdTerminal(String idTerminal) {
		this.idTerminal = idTerminal;
	}

}
