package com.pexto.monedero.apidto.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.invoke.MethodHandles;
import java.util.Iterator;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.bouncycastle.openpgp.PGPException;
import org.bouncycastle.openpgp.PGPPublicKey;
import org.bouncycastle.openpgp.PGPPublicKeyRing;
import org.bouncycastle.openpgp.PGPPublicKeyRingCollection;
import org.bouncycastle.openpgp.operator.bc.BcKeyFingerprintCalculator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import com.didisoft.pgp.PGPLib;

public class PGP {

    private static final Logger LOGGER = LoggerFactory.getLogger(PGP.class);

    private String gpg_result;
    private String gpg_err;

    private Properties properties;

    ClassLoader classLoader;
    PathMatchingResourcePatternResolver resolver;

    public PGP() {
        this.initProperties(false);
    }

    public PGP(Boolean showLogs) {
        this.initProperties(showLogs);
    }

    void initProperties(Boolean showLogs) {
        classLoader = MethodHandles.lookup().getClass().getClassLoader();
        resolver = new PathMatchingResourcePatternResolver(classLoader);

        Properties prop = new Properties();
        if (showLogs)
            LOGGER.info("** PGP-InitProperties **");
        try {
            Resource[] res = resolver.getResources("classpath:pgp.properties");
            if (res.length > 0) {
                InputStream inputStream = res[0].getInputStream();
                prop.load(inputStream);
                if (showLogs)
                    LOGGER.info("** PGP-Load-Properties-OK **");
                if (prop.getProperty("keys.folder") == null) {
                    String err = "The property 'keys.folder' not found";
                    if (showLogs)
                        LOGGER.info("** PGP-Load-Properties-ERROR ** : " + err);
                    throw new Exception(err);
                }else{
                    if (showLogs)
                        LOGGER.info("** PGP-Property-Keys-Folder-OK **");
                }
            } else {
                String err = "Property file 'pgp.properties' not found in the classpath";
                if (showLogs)
                    LOGGER.info("** PGP-Load-Properties-ERROR ** : " + err);
                throw new FileNotFoundException(err);
            }
        } catch (Exception e) {
            LOGGER.info("** PGP-Catch-Set-Default **");
            prop.setProperty("keys.folder", "keys-dev");
            if (showLogs)
                e.printStackTrace();
        }
        if (showLogs)
            LOGGER.info("** PGP-Keys-Folder-Loaded ** : " + prop.getProperty("keys.folder"));
        properties = prop;
    }

    public static PGPPublicKey readPublicKey(InputStream in) throws IOException, PGPException {
        in = org.bouncycastle.openpgp.PGPUtil.getDecoderStream(in);

        PGPPublicKeyRingCollection pgpPub =
                new PGPPublicKeyRingCollection(in, new BcKeyFingerprintCalculator());

        PGPPublicKey key = null;

        //
        // iterate through the key rings.
        //
        Iterator<PGPPublicKeyRing> rIt = pgpPub.getKeyRings();

        while (key == null && rIt.hasNext()) {
            PGPPublicKeyRing kRing = rIt.next();
            Iterator<PGPPublicKey> kIt = kRing.getPublicKeys();
            while (key == null && kIt.hasNext()) {
                PGPPublicKey k = kIt.next();

                if (k.isEncryptionKey()) {
                    key = k;
                }
            }
        }

        if (key == null) {
            throw new IllegalArgumentException("Can't find encryption(public) key in key ring.");
        }

        return key;
    }

    private Resource[] getKeyResources() throws IOException {

        return resolver.getResources(
                "classpath:".concat(properties.getProperty("keys.folder")).concat("/*.asc"));
    }

    // "gpg --armor --always-trust --batch --yes --encrypt -r "
    public String encrypt(String strInput, String idKey) throws Exception {

        if (strInput == null) {
            throw new Exception("Cadena a encriptar - null");
        }
        PGPPublicKey keyEncrypt = null;
        Resource keyEncryptResource = null;
        Resource[] res = getKeyResources();
        for (Resource resource : res) {
            try {
                PGPPublicKey pgpPublicKey = readPublicKey(resource.getInputStream());
                String id = Long.toHexString(pgpPublicKey.getKeyID()).toUpperCase();
                if (id.equalsIgnoreCase(idKey) || id.endsWith(idKey.toUpperCase())) {
                    keyEncrypt = pgpPublicKey;
                    keyEncryptResource = resource;
                    break;
                }
            } catch (Exception e) {
            }
        }
        if (keyEncrypt == null || keyEncryptResource == null) {
            throw new Exception("Llave para encriptar no encontrada");
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PGPLib pgp = new PGPLib();
        pgp.encryptStream(new ByteArrayInputStream(strInput.getBytes()), "message",
                keyEncryptResource.getInputStream(), out, true, true);

        gpg_result = out.toString();
        return gpg_result;
    }

    public boolean encryptFromFile(String fileName, String idKey) throws Exception {
        boolean valido = false;

        if (fileName == null) {
            throw new IOException("Archivo a encriptar - null");
        }

        PGPPublicKey keyEncrypt = null;
        Resource keyEncryptResource = null;
        Resource[] res = getKeyResources();
        for (Resource resource : res) {
            try {
                PGPPublicKey pgpPublicKey = readPublicKey(resource.getInputStream());
                String id = Long.toHexString(pgpPublicKey.getKeyID()).toUpperCase();
                if (id.equalsIgnoreCase(idKey) || id.endsWith(idKey.toUpperCase())) {
                    keyEncrypt = pgpPublicKey;
                    keyEncryptResource = resource;
                    break;
                }
            } catch (Exception e) {
            }
        }
        if (keyEncrypt == null || keyEncryptResource == null) {
            throw new Exception("Llave para encriptar no encontrada");
        }

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PGPLib pgp = new PGPLib();
        pgp.encryptStream(new FileInputStream(new File(fileName)), fileName,
                keyEncryptResource.getInputStream(), out, true, true);

        FileUtils.writeByteArrayToFile(new File(fileName.concat(".gpg")), out.toByteArray());

        return valido;
    }

    public String decrypt(String strInput, String passphrase) throws Exception {

        if (strInput == null) {
            throw new Exception("Cadena a desencriptar - null");
        }
        String output = null;
        Resource[] res = getKeyResources();
        PGPLib pgp = new PGPLib();
        for (Resource resource : res) {
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                pgp.decryptStream(new ByteArrayInputStream(strInput.getBytes()),
                        resource.getInputStream(), passphrase, out);
                if (out.size() > 0) {
                    output = out.toString();
                    break;
                }
            } catch (Exception e) {
            }
        }
        if (output == null) {
            throw new Exception("Key or passphrase for decrypt not work or not found");
        }
        gpg_result = output;

        return gpg_result;
    }

    public File decryptFromFile(File file, String fileName, String passphrase) throws Exception {
        File fileResult = new File(file.getParent() + File.separator + fileName + ".txt");

        ByteArrayOutputStream output = null;
        Resource[] res = getKeyResources();
        if (fileResult.exists())
            fileResult.delete();

        PGPLib pgp = new PGPLib();
        for (Resource resource : res) {
            try {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                pgp.decryptStream(new FileInputStream(file), resource.getInputStream(), passphrase,
                        out);
                if (out.size() > 0) {
                    output = out;
                    break;
                }
            } catch (Exception e) {
            }
        }
        if (output == null) {
            throw new Exception("Key or passphrase for decrypt not work or not found");
        }
        FileUtils.writeByteArrayToFile(fileResult, output.toByteArray());
        return fileResult;
    }

    public String getResult() {
        return gpg_result;
    }

    public String getError() {
        return gpg_err;
    }
}


class ProcessStreamReader extends Thread {
    String name;
    StringBuffer stream;
    InputStreamReader in;

    final static int BUFFER_SIZE = 256;

    ProcessStreamReader(String name, InputStream in) {
        super();

        this.name = name;
        this.in = new InputStreamReader(in);
        this.stream = new StringBuffer();
    }

    public void run() {
        try {
            int read;
            char[] c = new char[BUFFER_SIZE];

            while ((read = in.read(c, 0, BUFFER_SIZE - 1)) > 0) {
                stream.append(c, 0, read);
                if (read < BUFFER_SIZE - 1)
                    break;
            }
        } catch (IOException io) {
            System.out.println("PGP-ProcessStreamReader: run");
        }
    }

    String getString() {
        return stream.toString();
    }
}
