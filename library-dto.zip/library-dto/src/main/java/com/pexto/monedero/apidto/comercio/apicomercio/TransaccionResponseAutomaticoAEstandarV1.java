package com.pexto.monedero.apidto.comercio.apicomercio;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.utils.Parametros;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Builder(toBuilder = true)
@AllArgsConstructor
@Data
public class TransaccionResponseAutomaticoAEstandarV1 implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("transaccion")
	private String transaccion;

	@JsonProperty("fechaTransaccion")
	private String fechaTransaccion;

	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;

	@JsonProperty("valorTransaccion")
	private double valorTransaccion;

	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;

	@JsonProperty("estadoTransaccion")
	private String estadoTransaccion;

	@JsonProperty("descripcionEstado")
	private String descripcionEstado;

	@JsonProperty("causalTransaccion")
	private String causalTransaccion;

	@JsonProperty("descripcionCausal")
	private String descripcionCausal;

	@JsonProperty("numeroCuenta")
	private String numeroCuenta;

	@JsonProperty("clienteNumeroDocumento")
	private String clienteNumeroDocumento;

	@JsonProperty("codigoBolsillo")
	private String codigoBolsillo;

	@JsonProperty("descripcionBolsillo")
	private String descripcionBolsillo;

	@JsonProperty("numeroDocumentoConvenio")
	private String numeroDocumentoConvenio;

	@JsonProperty("nombreConvenio")
	private String nombreConvenio;

	public TransaccionResponseAutomaticoAEstandarV1() {
		this.transaccion = "";
		this.fechaTransaccion = Parametros.getFechaString(new Date());
		this.numeroAutorizacion = "";
		this.valorTransaccion = 0.0;
		this.tipoTransaccion = "";
		this.estadoTransaccion = Parametros.TRANSACCION_ESTADO_NO_AUTORIZADA;
		this.descripcionEstado = Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.causalTransaccion = Parametros.TRANSACCION_CAUSAL_NO_AUTORIZADA;
		this.descripcionCausal = Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.numeroCuenta = "";
		this.clienteNumeroDocumento = "";
		this.codigoBolsillo = "";
		this.descripcionBolsillo = "";
		this.numeroDocumentoConvenio = "";
		this.nombreConvenio = "";
	}

	public TransaccionResponseAutomaticoAEstandarV1(String causalTransaccion, String descripcionCausal) {
		this.transaccion = "";
		this.fechaTransaccion = Parametros.getFechaString(new Date());
		this.numeroAutorizacion = "";
		this.valorTransaccion = 0.0;
		this.tipoTransaccion = "";
		this.estadoTransaccion = Parametros.TRANSACCION_ESTADO_NO_AUTORIZADA;
		this.descripcionEstado = Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.causalTransaccion = causalTransaccion;
		this.descripcionCausal = descripcionCausal;
		this.numeroCuenta = "";
		this.clienteNumeroDocumento = "";
		this.codigoBolsillo = "";
		this.descripcionBolsillo = "";
		this.numeroDocumentoConvenio = "";
		this.nombreConvenio = "";
	}

	public String getTransaccion() {
		return transaccion;
	}

	public String getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public double getValorTransaccion() {
		return valorTransaccion;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}

	public String getDescripcionEstado() {
		return descripcionEstado;
	}

	public String getCausalTransaccion() {
		return causalTransaccion;
	}

	public String getDescripcionCausal() {
		return descripcionCausal;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	}

	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public void setValorTransaccion(double valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}

	public void setDescripcionEstado(String descripcionEstado) {
		this.descripcionEstado = descripcionEstado;
	}

	public void setCausalTransaccion(String causalTransaccion) {
		this.causalTransaccion = causalTransaccion;
	}

	public void setDescripcionCausal(String descripcionCausal) {
		this.descripcionCausal = descripcionCausal;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getClienteNumeroDocumento() {
		return clienteNumeroDocumento;
	}

	public void setClienteNumeroDocumento(String clienteNumeroDocumento) {
		this.clienteNumeroDocumento = clienteNumeroDocumento;
	}

	public String getCodigoBolsillo() {
		return codigoBolsillo;
	}

	public void setCodigoBolsillo(String codigoBolsillo) {
		this.codigoBolsillo = codigoBolsillo;
	}

	public String getDescripcionBolsillo() {
		return descripcionBolsillo;
	}

	public void setDescripcionBolsillo(String descripcionBolsillo) {
		this.descripcionBolsillo = descripcionBolsillo;
	}

	public String getNumeroDocumentoConvenio() {
		return numeroDocumentoConvenio;
	}

	public void setNumeroDocumentoConvenio(String numeroDocumentoConvenio) {
		this.numeroDocumentoConvenio = numeroDocumentoConvenio;
	}

	public String getNombreConvenio() {
		return nombreConvenio;
	}

	public void setNombreConvenio(String nombreConvenio) {
		this.nombreConvenio = nombreConvenio;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TransaccionResponseAutomaticoAEstandarV1 [transaccion=");
		builder.append(transaccion);
		builder.append(", fechaTransaccion=");
		builder.append(fechaTransaccion);
		builder.append(", numeroAutorizacion=");
		builder.append(numeroAutorizacion);
		builder.append(", valorTransaccion=");
		builder.append(valorTransaccion);
		builder.append(", tipoTransaccion=");
		builder.append(tipoTransaccion);
		builder.append(", estadoTransaccion=");
		builder.append(estadoTransaccion);
		builder.append(", descripcionEstado=");
		builder.append(descripcionEstado);
		builder.append(", causalTransaccion=");
		builder.append(causalTransaccion);
		builder.append(", descripcionCausal=");
		builder.append(descripcionCausal);
		builder.append(", numeroCuenta=");
		builder.append(numeroCuenta);
		builder.append(", clienteNumeroDocumento=");
		builder.append(clienteNumeroDocumento);
		builder.append(", codigoBolsillo=");
		builder.append(codigoBolsillo);
		builder.append(", descripcionBolsillo=");
		builder.append(descripcionBolsillo);
		builder.append(", numeroDocumentoConvenio=");
		builder.append(numeroDocumentoConvenio);
		builder.append(", nombreConvenio=");
		builder.append(nombreConvenio);
		builder.append("]");
		return builder.toString();
	}

}
