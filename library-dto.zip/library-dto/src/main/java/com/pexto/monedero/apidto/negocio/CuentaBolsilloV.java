package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class CuentaBolsilloV implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long idCuenta;
	private String numeroCuenta;
	private Long idCliente;
	private Date fechaCuenta;
	private String estadoCuenta;
	private Long idBolsillo;
	private String nombreCortoBolsillo;
	private String descripcionBolsillo;
	private Long idEmisor;
	private Long idEntidad;
	
	public CuentaBolsilloV() {
		
	}
	
	public CuentaBolsilloV(Long idCuenta, String numeroCuenta, Long idCliente, Date fechaCuenta, String estadoCuenta,
			Long idBolsillo, String nombreCortoBolsillo, String descripcionBolsillo, Long idEmisor, Long idEntidad) {
		
		super();
		
		this.idCuenta = idCuenta;
		this.numeroCuenta = numeroCuenta;
		this.idCliente = idCliente;
		this.fechaCuenta = fechaCuenta;
		this.estadoCuenta = estadoCuenta;
		this.idBolsillo = idBolsillo;
		this.nombreCortoBolsillo = nombreCortoBolsillo;
		this.descripcionBolsillo = descripcionBolsillo;
		this.idEmisor = idEmisor;
		this.idEntidad = idEntidad;
	}
	
	public Long getIdCuenta() {
		return idCuenta;
	}
	
	public void setIdCuenta(Long idCuenta) {
		this.idCuenta = idCuenta;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public Long getIdCliente() {
		return idCliente;
	}
	
	public void setIdCliente(Long idCliente) {
		this.idCliente = idCliente;
	}
	
	public Date getFechaCuenta() {
		return fechaCuenta;
	}
	
	public void setFechaCuenta(Date fechaCuenta) {
		this.fechaCuenta = fechaCuenta;
	}
	
	public String getEstadoCuenta() {
		return estadoCuenta;
	}
	
	public void setEstadoCuenta(String estadoCuenta) {
		this.estadoCuenta = estadoCuenta;
	}
	
	public Long getIdBolsillo() {
		return idBolsillo;
	}
	
	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}
	
	public String getNombreCortoBolsillo() {
		return nombreCortoBolsillo;
	}
	public void setNombreCortoBolsillo(String nombreCortoBolsillo) {
		this.nombreCortoBolsillo = nombreCortoBolsillo;
	}
	
	public String getDescripcionBolsillo() {
		return descripcionBolsillo;
	}
	
	public void setDescripcionBolsillo(String descripcionBolsillo) {
		this.descripcionBolsillo = descripcionBolsillo;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public Long getIdEntidad() {
		return idEntidad;
	}
	
	public void setIdEntidad(Long idEntidad) {
		this.idEntidad = idEntidad;
	}
	
}
