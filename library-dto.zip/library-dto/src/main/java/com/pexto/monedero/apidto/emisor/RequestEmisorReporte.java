package com.pexto.monedero.apidto.emisor;

import java.io.Serializable;

public class RequestEmisorReporte implements Serializable {
	private static final long serialVersionUID = 1L;	
	private String idEmisor;
	private String fechaInicio;
	private String fechaTermina;
	
	public String getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public String getFechaInicio() {
		return fechaInicio;
	}
	
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	
	public String getFechaTermina() {
		return fechaTermina;
	}
	
	public void setFechaTermina(String fechaTermina) {
		this.fechaTermina = fechaTermina;
	}
}