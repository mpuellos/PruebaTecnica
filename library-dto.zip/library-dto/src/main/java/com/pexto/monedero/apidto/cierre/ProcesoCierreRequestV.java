package com.pexto.monedero.apidto.cierre;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ProcesoCierreRequestV {

	@JsonProperty("idBolsillo")
	private Long idBolsillo;

	@JsonProperty("fechaCorte")
	private String fechaCorte;

	public String getFechaCorte() {
		return fechaCorte;
	}

	public void setFechaCorte(String fechaCorte) {
		this.fechaCorte = fechaCorte;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

}
