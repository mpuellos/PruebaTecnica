package com.pexto.monedero.apidto.negocio;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

public class TransactionCompaniesUploadNoveltyRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "usuario cannot be null")
    private String usuario;

    @NotNull(message = "emisor cannot be null")
    private String emisor;

    @NotNull(message = "nameFile cannot be null")
    private String nameFile;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getEmisor() {
        return emisor;
    }

    public void setEmisor(String emisor) {
        this.emisor = emisor;
    }

    public String getNameFile() {
        return nameFile;
    }

    public void setNameFile(String nameFile) {
        this.nameFile = nameFile;
    }
}
