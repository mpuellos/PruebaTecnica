package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.comercio.pcomercio.PerfilComercioV;
import com.pexto.monedero.apidto.negocio.ComercioDTO;
import com.pexto.monedero.apidto.negocio.CuentaDTO;
import com.pexto.monedero.apidto.negocio.SucursalDTO;
import com.pexto.monedero.apidto.negocio.TerminalDTO;
import com.pexto.monedero.apidto.negocio.UsuarioComercioDTO;

public class ComercioLoginAppResponseV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("token")
	private String token;
	
	@JsonProperty("saldo")
	private double saldo;
	
	@JsonProperty("comercio")
	private ComercioDTO comercio;
	
	@JsonProperty("sucursal")
	private SucursalDTO sucursal;
	
	@JsonProperty("terminal")
	private TerminalDTO terminal;
	
	@JsonProperty("cuenta")
	private CuentaDTO cuenta;
	
	@JsonProperty("usuarioComercio")
	private UsuarioComercioDTO usuarioComercio;
	
	@JsonProperty("perfilUsuario")
	private PerfilComercioV perfilUsuario;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public ComercioDTO getComercio() {
		return comercio;
	}

	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}

	public SucursalDTO getSucursal() {
		return sucursal;
	}

	public void setSucursal(SucursalDTO sucursal) {
		this.sucursal = sucursal;
	}

	public TerminalDTO getTerminal() {
		return terminal;
	}

	public void setTerminal(TerminalDTO terminal) {
		this.terminal = terminal;
	}

	public CuentaDTO getCuenta() {
		return cuenta;
	}

	public void setCuenta(CuentaDTO cuenta) {
		this.cuenta = cuenta;
	}

	public UsuarioComercioDTO getUsuarioComercio() {
		return usuarioComercio;
	}

	public void setUsuarioComercio(UsuarioComercioDTO usuarioComercio) {
		this.usuarioComercio = usuarioComercio;
	}

	public PerfilComercioV getPerfilUsuario() {
		return perfilUsuario;
	}

	public void setPerfilUsuario(PerfilComercioV perfilUsuario) {
		this.perfilUsuario = perfilUsuario;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}
}