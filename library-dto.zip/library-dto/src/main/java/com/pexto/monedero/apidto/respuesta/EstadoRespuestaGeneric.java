package com.pexto.monedero.apidto.respuesta;

import java.io.Serializable;

public class EstadoRespuestaGeneric<T> implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	//CONSTANTES_ESTADOS_RESPUESTA (1: True 0:  False)
	public static final String ESTADO_CADUCADO 		= "-1";
	public static final String ESTADO_EXITOSO 		= "1";
	public static final String ESTADO_NO_EXITOSO 	= "0";
	
	private String estado;
	private String mensaje;
	private T data;
	
	public EstadoRespuestaGeneric() {
		this.estado		= EstadoRespuestaGeneric.ESTADO_NO_EXITOSO;
		this.mensaje	= "";
		this.data 		= null;
	}
	
	public EstadoRespuestaGeneric(String estado, String mensaje) {
		this.setEstado(estado);
		this.mensaje = mensaje;
		this.data 	 = null;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		switch (estado) {
			case "0": 
				this.estado = EstadoRespuestaGeneric.ESTADO_NO_EXITOSO;
				break;
				
			case "1": 
				this.estado = EstadoRespuestaGeneric.ESTADO_EXITOSO;
				break;
				
			case "-1": 
				this.estado = EstadoRespuestaGeneric.ESTADO_CADUCADO;
				break;
				
			default:
				this.estado = EstadoRespuestaGeneric.ESTADO_NO_EXITOSO;
				break;
		}
	}
	
	public String getMensaje() {
		return mensaje;
	}
	
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EstadoRespuestaGeneric [estado=");
		builder.append(estado);
		builder.append(", mensaje=");
		builder.append(mensaje);
		builder.append(", data=");
		builder.append(data);
		builder.append("]");
		return builder.toString();
	}
}