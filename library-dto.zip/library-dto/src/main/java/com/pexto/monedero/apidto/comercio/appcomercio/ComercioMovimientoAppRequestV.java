package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;
import java.util.Date;

public class ComercioMovimientoAppRequestV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long idComercio;
	private String uuidComercio;
	private Long idUsuarioComercio;
	private String uuidUsuarioComercio;
    private Date fechaInicio;
    private Date fechaFinal;
    
	public Long getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public String getUuidComercio() {
		return uuidComercio;
	}

	public void setUuidComercio(String uuidComercio) {
		this.uuidComercio = uuidComercio;
	}

	public Long getIdUsuarioComercio() {
		return idUsuarioComercio;
	}

	public void setIdUsuarioComercio(Long idUsuarioComercio) {
		this.idUsuarioComercio = idUsuarioComercio;
	}

	public String getUuidUsuarioComercio() {
		return uuidUsuarioComercio;
	}

	public void setUuuidUsuarioComercio(String uuidUsuarioComercio) {
		this.uuidUsuarioComercio = uuidUsuarioComercio;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public Date getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public boolean validatePropertiesId() throws Exception {
		if (idComercio == null) {
			throw new Exception("IdComercio is null");
		}
		
		if (fechaInicio == null) {
			throw new Exception("Fecha de Inicio is null");
		}
		
		if (fechaFinal == null) {
			throw new Exception("Fecha Final is null");
		}
		
		if (String.valueOf(idComercio).trim().equals("")) {
			throw new Exception("IdComercio esta vacio!");
		}
		
		if (idComercio <= 0) {
			throw new Exception("IdComercio valor errado!");
		}
		
		return true;
	}
	
	public boolean validatePropertiesUUID() throws Exception {
		if (uuidComercio == null) {
			throw new Exception("UUIDComercio is null");
		}
		
		if (fechaInicio == null) {
			throw new Exception("Fecha de Inicio is null");
		}
		
		if (fechaFinal == null) {
			throw new Exception("Fecha Final is null");
		}
		
		if (String.valueOf(uuidComercio).trim().equals("")) {
			throw new Exception("UuidComercio esta vacio!");
		}
		
		return true;
	}
	
}
