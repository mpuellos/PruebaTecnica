package com.pexto.monedero.apidto.negocio;

import java.util.Calendar;

public class EntidadV {
	
	private Long id;
	private String numeroDocumento;
	private String nombre;
	private String direccion;
	private String telefono1;
	private String telefono2;
	private String correo;
	private String representanteDocumento;
	private String representanteNombre;
	private String representanteCorreo;
	private String contactoNombre;
	private String contactoTelefono;
	private String contactoCorreo;
	private Calendar fecha;
	private String estado;
	private TiposDocumentoV tiposDocumento;
	private UsuarioAdminDTO usuarioAdmin;
	
	public Long getId() {
		return id;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getDireccion() {
		return direccion;
	}
	
	public String getTelefono1() {
		return telefono1;
	}
		
	public String getTelefono2() {
		return telefono2;
	}
	
	public String getCorreo() {
		return correo;
	}
	
	public String getRepresentanteDocumento() {
		return representanteDocumento;
	}
	
	public String getRepresentanteNombre() {
		return representanteNombre;
	}
	
	public String getRepresentanteCorreo() {
		return representanteCorreo;
	}
	
	public String getContactoNombre() {
		return contactoNombre;
	}
	
	public String getContactoTelefono() {
		return contactoTelefono;
	}
	
	public String getContactoCorreo() {
		return contactoCorreo;
	}
	
	public Calendar getFecha() {
		return fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public TiposDocumentoV getTiposDocumento() {
		return tiposDocumento;
	}
	
	public UsuarioAdminDTO getUsuarioAdmin() {
		return usuarioAdmin;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void setTelefono1(String telefono1) {
		this.telefono1 = telefono1;
	}

	public void setTelefono2(String telefono2) {
		this.telefono2 = telefono2;
	}
	
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	public void setRepresentanteDocumento(String representanteDocumento) {
		this.representanteDocumento = representanteDocumento;
	}
	
	public void setRepresentanteNombre(String representanteNombre) {
		this.representanteNombre = representanteNombre;
	}
	
	public void setRepresentanteCorreo(String representanteCorreo) {
		this.representanteCorreo = representanteCorreo;
	}
	
	public void setContactoNombre(String contactoNombre) {
		this.contactoNombre = contactoNombre;
	}
	
	public void setContactoTelefono(String contactoTelefono) {
		this.contactoTelefono = contactoTelefono;
	}
	
	public void setContactoCorreo(String contactoCorreo) {
		this.contactoCorreo = contactoCorreo;
	}
	
	public void setFecha(Calendar fecha) {
		this.fecha = fecha;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public void setTiposDocumento(TiposDocumentoV tiposDocumento) {
		this.tiposDocumento = tiposDocumento;
	}
	
	public void setUsuarioAdmin(UsuarioAdminDTO usuarioAdmin) {
		this.usuarioAdmin = usuarioAdmin;
	}
	
	public static String[][] compareObject(EntidadV entidad1, EntidadV entidad2) {
		String[][] result = new String[4][4];
		
		if (!entidad1.getNombre().equals(entidad2.getNombre())) {
			result[0][0] = "Y";
			result[0][1] = "Nombre";
			result[0][2] = entidad1.getNombre();
			result[0][3] = entidad2.getNombre();
			
		}else {
			result[0][0] = "N";
			result[0][1] = "Nombre";
			result[0][2] = entidad1.getNombre();
			result[0][3] = entidad2.getNombre();
		}
		
		if (!entidad1.getNumeroDocumento().equals(entidad2.getNumeroDocumento())) {
			result[1][0] = "Y";
			result[1][1] = "NumeroDocumento";
			result[1][2] = entidad1.getNumeroDocumento();
			result[1][3] = entidad2.getNumeroDocumento();
		}else {
			result[1][0] = "N";
			result[1][1] = "NumeroDocumento";
			result[1][2] = entidad1.getNumeroDocumento();
			result[1][3] = entidad2.getNumeroDocumento();
		}
		
		if (!entidad1.getDireccion().equals(entidad2.getDireccion())) {
			result[2][0] = "Y";
			result[2][1] = "Direccion";
			result[2][2] = entidad1.getDireccion();
			result[2][3] = entidad2.getDireccion();
		}else {
			result[2][0] = "N";
			result[2][1] = "Direccion";
			result[2][2] = entidad1.getDireccion();
			result[2][3] = entidad2.getDireccion();
		}
		
		if (!entidad1.getTelefono1().equals(entidad2.getTelefono1())) {
			result[3][0] = "Y";
			result[3][1] = "Telefono1";
			result[3][2] = entidad1.getTelefono1();
			result[3][3] = entidad2.getTelefono1();
		}else {
			result[3][0] = "N";
			result[3][1] = "Telefono1";
			result[3][2] = entidad1.getTelefono1();
			result[3][3] = entidad2.getTelefono1();
		}
		
		return result;
		
	}

}
