package com.pexto.monedero.apidto.integrador.olimpica;

import java.io.Serializable;

public class ResponseAutenticador implements Serializable{
	private static final long serialVersionUID = 2848080900861623593L;
	
	private String codigoRespuesta;
	private String mensajeRespuesta;
	private String tipoMensaje;
	private String dato;
	private String perfiles;
	private String perfil;
	private Long saldoDisponible;
	private Long saldoExtracupo;
	private Long cupoAsignado;
	private String nitEmpresa;
	private String nombreEmpresa;
	private String tipoCreditoOrden;
	
	public String getCodigoRespuesta() {
		return codigoRespuesta;
	}
	
	public void setCodigoRespuesta(String codigoRespuesta) {
		this.codigoRespuesta = codigoRespuesta;
	}
	
	public String getMensajeRespuesta() {
		return mensajeRespuesta;
	}
	
	public void setMensajeRespuesta(String mensajeRespuesta) {
		this.mensajeRespuesta = mensajeRespuesta;
	}
	
	public String getTipoMensaje() {
		return tipoMensaje;
	}
	
	public void setTipoMensaje(String tipoMensaje) {
		this.tipoMensaje = tipoMensaje;
	}
	
	public String getDato() {
		return dato;
	}
	
	public void setDato(String dato) {
		this.dato = dato;
	}
	
	public String getPerfiles() {
		return perfiles;
	}
	
	public void setPerfiles(String perfiles) {
		this.perfiles = perfiles;
	}
	
	public String getPerfil() {
		return perfil;
	}
	
	public void setPerfil(String perfil) {
		this.perfil = perfil;
	}
	
	public Long getSaldoDisponible() {
		return saldoDisponible;
	}
	
	public void setSaldoDisponible(Long saldoDisponible) {
		this.saldoDisponible = saldoDisponible;
	}
	
	public Long getSaldoExtracupo() {
		return saldoExtracupo;
	}
	
	public void setSaldoExtracupo(Long saldoExtracupo) {
		this.saldoExtracupo = saldoExtracupo;
	}
	
	public Long getCupoAsignado() {
		return cupoAsignado;
	}
	
	public void setCupoAsignado(Long cupoAsignado) {
		this.cupoAsignado = cupoAsignado;
	}
	
	public String getNitEmpresa() {
		return nitEmpresa;
	}
	
	public void setNitEmpresa(String nitEmpresa) {
		this.nitEmpresa = nitEmpresa;
	}
	
	public String getNombreEmpresa() {
		return nombreEmpresa;
	}
	
	public void setNombreEmpresa(String nombreEmpresa) {
		this.nombreEmpresa = nombreEmpresa;
	}
	
	public String getTipoCreditoOrden() {
		return tipoCreditoOrden;
	}
	
	public void setTipoCreditoOrden(String tipoCreditoOrden) {
		this.tipoCreditoOrden = tipoCreditoOrden;
	}
	
}
