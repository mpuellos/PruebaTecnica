package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class SucursalV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String hash;
	private String nombre;
	private String direccion;
	private String telefono;
	private String correo;
	private Date fecha;
	private String estado;
	private Long idComercio;
	
	public SucursalV() {
		
	}
	
	public SucursalV(Long id, String uuid, String hash, String nombre) {
		this.id = id;
		this.uuid = uuid;
		this.hash = hash;
		this.nombre = nombre;
	}
	
	public SucursalV(Long id, String uuid, String hash, String nombre, Date fecha, String estado) {
		this.id = id;
		this.uuid = uuid;
		this.hash = hash;
		this.nombre = nombre;
		this.fecha = fecha;
		this.estado = estado;
	}

	public Long getId() {
		return id;
	}

	public String getUuid() {
		return uuid;
	}

	public String getHash() {
		return hash;
	}

	public String getNombre() {
		return nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getEstado() {
		return estado;
	}

	public Long getIdComercio() {
		return idComercio;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}
		
}
