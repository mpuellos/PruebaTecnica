package com.pexto.monedero.apidto.core;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionRequestTransferenciaAbonoCompraRetiroQRV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
		
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("idBolsillo")
	private Long idBolsillo;
	
	@JsonProperty("valor")
	private double valor;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("authorization")
	private String authorization;
	
	@JsonProperty("paramRequest")
	private ParamRequestV paramRequest;
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public Long getIdBolsillo() {
		return idBolsillo;
	}
	
	public double getValor() {
		return valor;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	
	public String getAuthorization() {
		return authorization;
	}

	public ParamRequestV getParamRequest() {
		return paramRequest;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}

	public void setParamRequest(ParamRequestV paramRequest) {
		this.paramRequest = paramRequest;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		//VALIDATION NULL
		
		if (this.numeroCuenta == null || this.numeroCuenta.equals("")) {
			throw new Exception("Numero de Cuenta - null o vacio!");
		}
		
		if (this.idBolsillo == null || String.valueOf(this.idBolsillo).equals("")) {
			throw new Exception("IdBolsillo - null o vacio!");
		}
	
		if (this.tipoTransaccion == null || this.tipoTransaccion.equals("")) {
			throw new Exception("TipoTransaccion - null o vacio!");
		}	
		
    	if (!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_TRANSFERENCIA_INTERNA)) {
    		throw new Exception("Ingrese un tipo de transaccion correcto!");
    	}
    	
    	if (String.valueOf(this.valor).equals("")) {
    		throw new Exception("Valor vacio!");
    	}
    	
    	/* VALIDATION DATA_VALUES */
    	//validate_ValorPositivo
    	if (this.valor <= 0) {
    		throw new Exception("Ingrese un valor correcto!");
    	}
    	
		return valid;
	}
	
}
