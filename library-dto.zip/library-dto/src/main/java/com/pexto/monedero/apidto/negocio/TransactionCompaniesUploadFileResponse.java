package com.pexto.monedero.apidto.negocio;

import lombok.*;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionCompaniesUploadFileResponse implements Serializable {

    private static final long serialVersionUID = 1L;
    private String nameFile;
    private Date applicationDate;
    private String paymentType;
    private int numberEmployees;
    private Double totalToPay;
}
