package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class EmisorResetPasswordRequest implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private String logon;
	private String email;
	
	public EmisorResetPasswordRequest() {
		
	}
	
	public EmisorResetPasswordRequest(String logon, String email) {
		this.logon = logon;
		this.email = email;
	}

	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}
	
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public boolean validateProperties() throws Exception {
		
		if (this.logon == null) {
			throw new Exception ("Error campo logon is null");
		}
		
		if (this.email == null) {
			throw new Exception ("Error campo email is null");
		}
		
		if (this.logon.trim().equals("")) {
			throw new Exception ("Error campo logon esta vacio!");
		}
		
		if (this.email.trim().equals("")) {
			throw new Exception ("Error campo email esta vacio");
		}
		
		return true;
	}
}