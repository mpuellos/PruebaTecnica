package com.pexto.monedero.apidto.negocio;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class ClienteV {

	String uuid;
	String tipoCliente;
	String numeroDocumento;
	String nombres;
	String apellidos;
	String correo;
	String celular;

}
