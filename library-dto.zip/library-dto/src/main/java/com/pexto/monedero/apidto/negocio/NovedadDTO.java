package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class NovedadDTO implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;
    private String bolsillo;
    private int cantidadRegistro;
    private double valorTotal;
    private Date fechaSolicitud;
    private String nombreArchivo;
    private String descripcion;
    private String solicitante;
    private String aprobador;
    private Date fechaAprobacion;
    private boolean archivoAdjunto;

    private NovedadDTO() {
    }

    public NovedadDTO(
            Long id, String bolsillo, int cantidadRegistros, double valorTotal, Date fecha,
            String nombreArchivo, Date fechaAprobacion, String solicitante, String aprobador, Long archivoAdjunto
    ) {
        super();
        this.id = id;
        this.bolsillo = bolsillo;
        this.cantidadRegistro = cantidadRegistros;
        this.valorTotal = valorTotal;
        this.fechaSolicitud = fecha;
        this.nombreArchivo = nombreArchivo;
        this.solicitante = solicitante;
        this.aprobador = aprobador;
        this.fechaAprobacion = fechaAprobacion;
        this.archivoAdjunto = (archivoAdjunto != null && archivoAdjunto == 1) ? true : false;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBolsillo() {
        return bolsillo;
    }

    public void setBolsillo(String bolsillo) {
        this.bolsillo = bolsillo;
    }

    public int getCantidadRegistros() {
        return cantidadRegistro;
    }

    public void setCantidadRegistros(int cantidadRegistros) {
        this.cantidadRegistro = cantidadRegistros;
    }

    public double getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(double valorTotal) {
        this.valorTotal = valorTotal;
    }

    public Date getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(Date fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public String getNombreArchivo() {
        return nombreArchivo;
    }

    public void setNombreArchivo(String nombreArchivo) {
        this.nombreArchivo = nombreArchivo;
    }

    public String getDescripcion() {
        return (descripcion != null) ? aprobador : "";
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getSolicitante() {
        return solicitante;
    }

    public void setSolicitante(String solicitante) {
        this.solicitante = solicitante;
    }

    public String getAprobador() {
        return (aprobador != null) ? aprobador : "";
    }

    public void setAprobador(String aprobador) {
        this.aprobador = aprobador;
    }

    public Date getFechaAprobacion() {
        return fechaAprobacion;
    }

    public void setFechaAprobacion(Date fechaAprobacion) {
        this.fechaAprobacion = fechaAprobacion;
    }

    public boolean getArchivoAdjunto() {
        return archivoAdjunto;
    }

    public void setArchivoAdjunto(boolean archivoAdjunto) {
        this.archivoAdjunto = archivoAdjunto;
    }


}
