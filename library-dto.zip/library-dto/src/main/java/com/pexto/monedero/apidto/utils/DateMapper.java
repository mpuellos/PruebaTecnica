package com.pexto.monedero.apidto.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;


public class DateMapper {

  private DateMapper() {

  }

  public static String asString(LocalDate date) {
    if (date == null)
      return null;
    return DateTimeFormatter.ISO_DATE.format(date);
  }

  public static String asString(LocalDateTime datetime) {
    if (datetime == null)
      return null;
    return DateTimeFormatter.ISO_DATE_TIME.format(datetime);
  }

  public static LocalDate asDate(String date) {
    if (date == null)
      return null;
    return LocalDate.parse(date, DateTimeFormatter.ISO_DATE);
  }

  public static LocalDateTime asDateTime(String datetime) {
    if (datetime == null)
      return null;
    return LocalDateTime.parse(datetime, DateTimeFormatter.ISO_DATE_TIME);
  }

  public static String asString(Date date) {
    if (date == null)
      return null;
    return asString(convertToLocalDateViaInstant(date));
  }

  public static LocalDate convertToLocalDateViaInstant(Date dateToConvert) {
    if (dateToConvert == null)
      return null;
    return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
  }

  public static Date convertToDateViaInstant(LocalDateTime dateToConvert) {
    return java.util.Date.from(dateToConvert.atZone(ZoneId.systemDefault()).toInstant());
  }

  public static Date convertToDateViaInstant(LocalDate dateToConvert) {
    return java.util.Date.from(dateToConvert.atStartOfDay(ZoneId.systemDefault()).toInstant());
  }

  public static LocalDateTime convertToLocalDateTimeViaInstant(Date dateToConvert) {
    return dateToConvert.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
  }
}
