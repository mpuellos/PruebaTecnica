package com.pexto.monedero.apidto.sacresponse;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Value;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SacTransaction {
  Date dateTime;
  String type;
  String status;
  Double previosAmount;
  Double newAmount;
  Double value;
  String walletName;
}
