package com.pexto.monedero.apidto.comercio.pcomercio;

import java.io.Serializable;

public class TiposTransaccionComercioV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String nombre;
	private String descripcion;
	private String naturaleza;
	
	public TiposTransaccionComercioV() {
		
	}
	
	public TiposTransaccionComercioV(String nombre, String descripcion, String naturaleza) {
		super();
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.naturaleza = naturaleza;
	}
	
	public String getNombre() {
		return nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public String getNaturaleza() {
		return naturaleza;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public void setNaturaleza(String naturaleza) {
		this.naturaleza = naturaleza;
	}
	
}
