package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class TransactionCompaniesDownloadBusinessAttachedRequest  implements Serializable{

	private static final long serialVersionUID = 1L;

	private String fileBase64;

	public String getFileBase64() {
		return fileBase64;
	}

	public void setFileBase64(String fileBase64) {
		this.fileBase64 = fileBase64;
	}
}
