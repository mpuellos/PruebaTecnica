package com.pexto.monedero.apidto.core;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ParamRequestV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("ipLocal")
	private String ipLocal;
	
	@JsonProperty("ipOrigen")
	private String ipOrigen;
	
	@JsonProperty("userAgent")
	private String userAgent;
	
	public ParamRequestV() {
		this.ipLocal 	= "127.0.0.1";
		this.ipOrigen 	= "127.0.0.1";
		this.userAgent  = "userAgentDefault";
	}

	public String getIpLocal() {
		return ipLocal;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setIpLocal(String ipLocal) {
		this.ipLocal = ipLocal;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}
	
}
