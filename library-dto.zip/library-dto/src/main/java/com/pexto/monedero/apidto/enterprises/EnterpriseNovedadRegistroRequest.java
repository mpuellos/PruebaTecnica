package com.pexto.monedero.apidto.enterprises;

import com.pexto.monedero.apidto.enterprises.options.TypeMethodOfPay;
import lombok.*;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
public class EnterpriseNovedadRegistroRequest {

    EnterpriseNovedadRegistroRequest.Metadata metadata;
    EnterpriseNovedadRegistroRequest.NewClient newClient;
    EnterpriseNovedadRegistroRequest.Bank bank;
    TypeMethodOfPay typeMethodOfPay;

    public EnterpriseNovedadRegistroRequest() {
        this.bank = new EnterpriseNovedadRegistroRequest.Bank();
    }

    @Getter
    @Setter
    @Builder(toBuilder = true)
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Metadata {

        Long idEmisor;
        Long usuarioEmisor;

    }

    @Getter
    @Setter
    @Builder(toBuilder = true)
    @AllArgsConstructor
    @NoArgsConstructor
    public static class NewClient {

        String typeId;
        String numberId;
        String names;
        String lastNames;
        String birthdateDate;
        String expeditionDate;
        String email;
        String phoneNumber;

    }

    @Getter
    @Setter
    @Builder(toBuilder = true)
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Bank {

        Long bankId;
        Long accountTypeId;
        String accountNumber;

    }
}
