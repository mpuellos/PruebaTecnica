package com.pexto.monedero.apidto.comercio.apicomercio;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.ComercioAutorizadorIntegradorV;
import com.pexto.monedero.apidto.negocio.ComercioAutorizadorV;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionResponseAutomaticoAExternoV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("transaccion")
	private String transaccion;
	
	@JsonProperty("fechaTransaccion")
	private String fechaTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("valorTransaccion")
	private double valorTransaccion;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("estadoTransaccion")
	private String estadoTransaccion;
	
	@JsonProperty("descripcionEstado")
	private String descripcionEstado;
	
	@JsonProperty("causalTransaccion")
	private String causalTransaccion;
	
	@JsonProperty("descripcionCausal")
	private String descripcionCausal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("comercioAutorizadorResponse")
	private ComercioAutorizadorV comercioAutorizadorResponse;
	
	@JsonProperty("comercioIntegradorResponse")
	private ComercioAutorizadorIntegradorV comercioIntegradorResponse;
	
	public TransaccionResponseAutomaticoAExternoV() {
		this.transaccion 					= "";
		this.fechaTransaccion 				= Parametros.getFechaString(new Date());
		this.numeroAutorizacion 			= "";
		this.valorTransaccion 				= 0.0;
		this.tipoTransaccion 				= "";
		this.estadoTransaccion 				= Parametros.TRANSACCION_ESTADO_NO_AUTORIZADA;
		this.descripcionEstado 				= Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.causalTransaccion 				= Parametros.TRANSACCION_CAUSAL_NO_AUTORIZADA;
		this.descripcionCausal 				= Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.numeroCuenta 					= "";
		this.comercioAutorizadorResponse	= null;
		this.comercioIntegradorResponse		= null;
	}
	
	public TransaccionResponseAutomaticoAExternoV(String causalTransaccion, String descripcionCausal) {
		this.transaccion 					= "";
		this.fechaTransaccion 				= Parametros.getFechaString(new Date());
		this.numeroAutorizacion 			= "";
		this.valorTransaccion 				= 0.0;
		this.tipoTransaccion 				= "";
		this.estadoTransaccion 				= Parametros.TRANSACCION_ESTADO_NO_AUTORIZADA;
		this.descripcionEstado 				= Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.causalTransaccion 				= causalTransaccion;
		this.descripcionCausal 				= descripcionCausal;
		this.numeroCuenta 					= "";
		this.comercioAutorizadorResponse	= null;
		this.comercioIntegradorResponse		= null;
	}
	
	public TransaccionResponseAutomaticoAExternoV(String transaccion, Date fechaTransaccion, String numeroAutorizacion, double valorTransaccion, String tipoTransaccion,
			String estadoTransaccion, String descripcionEstado, String causalTransaccion, String descripcionCausal, String numeroCuenta) {
		
		this.transaccion 					= transaccion;
		this.fechaTransaccion 				= Parametros.getFechaString(fechaTransaccion);
		this.numeroAutorizacion 			= numeroAutorizacion;
		this.valorTransaccion 				= valorTransaccion;
		this.tipoTransaccion 				= tipoTransaccion;
		this.estadoTransaccion 				= estadoTransaccion;
		this.descripcionEstado 				= descripcionEstado;
		this.causalTransaccion 				= causalTransaccion;
		this.descripcionCausal 				= descripcionCausal;
		this.numeroCuenta 					= numeroCuenta;
		this.comercioAutorizadorResponse	= null;
	}
	
	public String getTransaccion() {
		return transaccion;
	}
	
	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	}
	
	public String getFechaTransaccion() {
		return fechaTransaccion;
	}
	
	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}
	
	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}
	
	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}
	
	public double getValorTransaccion() {
		return valorTransaccion;
	}
	
	public void setValorTransaccion(double valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}
	
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}
	
	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}
	
	public String getCausalTransaccion() {
		return causalTransaccion;
	}
	
	public void setCausalTransaccion(String causalTransaccion) {
		this.causalTransaccion = causalTransaccion;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getDescripcionEstado() {
		return descripcionEstado;
	}
	
	public void setDescripcionEstado(String descripcionEstado) {
		this.descripcionEstado = descripcionEstado;
	}

	public String getDescripcionCausal() {
		return descripcionCausal;
	}

	public void setDescripcionCausal(String descripcionCausal) {
		this.descripcionCausal = descripcionCausal;
	}

	public ComercioAutorizadorV getComercioAutorizadorResponse() {
		return comercioAutorizadorResponse;
	}

	public void setComercioAutorizadorResponse(ComercioAutorizadorV comercioAutorizadorResponse) {
		this.comercioAutorizadorResponse = comercioAutorizadorResponse;
	}
	
	public ComercioAutorizadorIntegradorV getComercioIntegradorResponse() {
		return comercioIntegradorResponse;
	}

	public void setComercioIntegradorResponse(ComercioAutorizadorIntegradorV comercioIntegradorResponse) {
		this.comercioIntegradorResponse = comercioIntegradorResponse;
	}
	
}
