package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

public class SaldoRequestV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long idBolsillo;
	private Long idEmisor;
	private Long idUsuarioEmisor;
	private String numeroCuenta;
	
	public Long getIdBolsillo() {
		return idBolsillo;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public Long getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public void setIdUsuarioEmisor(Long idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SaldoRequestV [idBolsillo=");
		builder.append(idBolsillo);
		builder.append(", idEmisor=");
		builder.append(idEmisor);
		builder.append(", idUsuarioEmisor=");
		builder.append(idUsuarioEmisor);
		builder.append(", numeroCuenta=");
		builder.append(numeroCuenta);
		builder.append(", getIdBolsillo()=");
		builder.append(getIdBolsillo());
		builder.append(", getIdEmisor()=");
		builder.append(getIdEmisor());
		builder.append(", getNumeroCuenta()=");
		builder.append(getNumeroCuenta());
		builder.append(", getIdUsuarioEmisor()=");
		builder.append(getIdUsuarioEmisor());
		builder.append(", getClass()=");
		builder.append(getClass());
		builder.append(", hashCode()=");
		builder.append(hashCode());
		builder.append(", toString()=");
		builder.append(super.toString());
		builder.append("]");
		return builder.toString();
	}	
}