package com.pexto.monedero.apidto.comercio.pcomercio;

import java.util.List;

import com.pexto.monedero.apidto.negocio.SucursalV;
import com.pexto.monedero.apidto.negocio.TerminalV;
import com.pexto.monedero.apidto.respuesta.EstadoRespuesta;

public class ComercioLoginResponseV extends EstadoRespuesta {
	
	private static final long serialVersionUID = 1L;
	
	private ComercioLoginResponse comercioLogin;
	private List<SucursalV> sucursal;
	private List<TerminalV> terminal;
	
	public ComercioLoginResponseV() {
		this.estado = EstadoRespuesta.ESTADO_NO_EXITOSO;
		this.mensaje = "";
		this.comercioLogin = null;
	}
	
	public ComercioLoginResponseV(String estado, String mensaje) {
		this.setEstado(estado);
		
		this.mensaje = mensaje;
		this.sucursal = null;
		this.terminal = null;
		this.comercioLogin = null;
	}
	
	public ComercioLoginResponseV(String estado, String mensaje, 
			List<SucursalV> sucursal, List<TerminalV> terminal, ComercioLoginResponse comercioLogin) {
		
		this.setEstado(estado);
		this.mensaje = mensaje;
		this.sucursal = sucursal;
		this.terminal = terminal;
		this.comercioLogin = comercioLogin;
	}
	
	public ComercioLoginResponse getComercioLogin() {
		return comercioLogin;
	}
	
	public void setComercioLogin(ComercioLoginResponse comercioLogin) {
		this.comercioLogin = comercioLogin;
	}

	public List<SucursalV> getSucursal() {
		return sucursal;
	}

	public void setSucursal(List<SucursalV> sucursal) {
		this.sucursal = sucursal;
	}

	public List<TerminalV> getTerminal() {
		return terminal;
	}

	public void setTerminal(List<TerminalV> terminal) {
		this.terminal = terminal;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ComercioLoginResponseV [comercioLogin=");
		builder.append(comercioLogin);
		builder.append(", sucursal=");
		builder.append(sucursal);
		builder.append(", terminal=");
		builder.append(terminal);
		builder.append("]");
		return builder.toString();
	}
	
}
