package com.pexto.monedero.apidto.admin.response;

import java.io.Serializable;

import com.pexto.monedero.apidto.admin.vo.SucursalVO;

public class ResponsePostSucursal implements Serializable {
	
	private static final long serialVersionUID = -5385554123759898501L;
	
	private SucursalVO sucursalVO;

	public SucursalVO getSucursalVO() {
		return sucursalVO;
	}

	public void setSucursalVO(SucursalVO sucursalVO) {
		this.sucursalVO = sucursalVO;
	}
	
}