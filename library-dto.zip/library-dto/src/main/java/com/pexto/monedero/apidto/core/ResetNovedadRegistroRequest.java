package com.pexto.monedero.apidto.core;

import javax.validation.constraints.NotNull;

public class ResetNovedadRegistroRequest {
    @NotNull
    private String codigoNovedad;

    @NotNull
    private String nuevoEstado;

    @NotNull
    private Long idEmisor;

    public Long getIdEmisor() {
        return idEmisor;
    }

    public void setIdEmisor(Long idEmisor) {
        this.idEmisor = idEmisor;
    }

    public String getCodigoNovedad() {
        return codigoNovedad;
    }

    public void setCodigoNovedad(String codigoNovedad) {
        this.codigoNovedad = codigoNovedad;
    }

    public String getNuevoEstado() {
        return nuevoEstado;
    }

    public void setNuevoEstado(String nuevoEstado) {
        this.nuevoEstado = nuevoEstado;
    }

}
