package com.pexto.monedero.apidto.emisor;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public enum EncryptionMode {

  //@formatter:off
  PGP("PGP"),
  NONE("NONE");
  //@formatter:on

  private static final Map<String, EncryptionMode> BY_CODE = new HashMap<>();

  static {
    for (EncryptionMode e : values()) {
      BY_CODE.put(e.code, e);
    }
  }

  private final String code;

  private EncryptionMode(String code) {
    this.code = code;
  }

  public String getCode() {
    return code;
  }

  public static EncryptionMode valueOfCode(String label) {
    return BY_CODE.get(label);
  }

  public static String valuesAsString() {
    return BY_CODE.keySet().stream().map(key -> key + "=" + BY_CODE.get(key))
        .collect(Collectors.joining(", ", "{", "}"));
  }
}
