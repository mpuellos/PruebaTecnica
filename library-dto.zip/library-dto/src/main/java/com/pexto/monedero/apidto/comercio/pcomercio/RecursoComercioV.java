package com.pexto.monedero.apidto.comercio.pcomercio;

import java.io.Serializable;
import java.sql.Date;

public class RecursoComercioV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String nombre;
	private String descripcion;
	private String url;
	private String tipoRecurso;
	private Long recursoPadre;
	private Date fecha;
	private String estado;
	private Long usuarioAdmin;
	
	public Long getId() {
		return id;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public String getUrl() {
		return url;
	}
	
	public String getTipoRecurso() {
		return tipoRecurso;
	}
	
	public Long getRecursoPadre() {
		return recursoPadre;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public Long getUsuarioAdmin() {
		return usuarioAdmin;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public void setUrl(String url) {
		this.url = url;
	}
	
	public void setTipoRecurso(String tipoRecurso) {
		this.tipoRecurso = tipoRecurso;
	}
	
	public void setRecursoPadre(Long recursoPadre) {
		this.recursoPadre = recursoPadre;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public void setUsuarioAdmin(Long usuarioAdmin) {
		this.usuarioAdmin = usuarioAdmin;
	}
	
}
