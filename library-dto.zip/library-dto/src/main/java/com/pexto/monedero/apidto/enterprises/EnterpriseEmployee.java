package com.pexto.monedero.apidto.enterprises;

import java.util.Date;

import lombok.*;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class EnterpriseEmployee {

    EnterpriseEmployee.Employee employee;
    EnterpriseEmployee.FavoriteTransferV bank;
    String typeMethodOfPay;

    @Getter
    @Setter
    @Builder(toBuilder = true)
    @AllArgsConstructor
    @NoArgsConstructor
    public static class Employee {

        String typeDocument;
        String numberDocument;
        String names;
        String lastNames;
        String email;
        String phoneNumber;
        Date birthdateDate;
        Date expeditionDate;
        String state;

    }

    @Getter
    @Setter
    @Builder(toBuilder = true)
    @AllArgsConstructor
    @NoArgsConstructor
    public static class FavoriteTransferV {

        String bankId;
        String bankCode;
        String name;
        String accountTypeId;
        String accountTypeCode;
        String accountTypeName;
        String accountNumber;

    }

}
