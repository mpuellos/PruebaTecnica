package com.pexto.monedero.apidto.core;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.ClienteV;
import com.pexto.monedero.apidto.negocio.ComercioV;
import com.pexto.monedero.apidto.negocio.EmisorV;
import com.pexto.monedero.apidto.negocio.TransactionTransferToBankResponse;
import com.pexto.monedero.apidto.respuesta.EstadoRespuesta;

public class TransaccionResponseCoreV extends EstadoRespuesta implements Serializable {

	private static final long serialVersionUID = 1L;

	@JsonProperty("transaccionOrigen")
	private TransaccionResponseV transaccionOrigen;

	@JsonProperty("transaccionDestino")
	private TransaccionResponseV transaccionDestino;

	@JsonProperty("comercio")
	private ComercioV comercio;

	@JsonProperty("emisor")
	private EmisorV emisor;

	@JsonProperty("cliente")
	private ClienteV cliente;

	@JsonProperty("saldo")
	private double saldo;

	@JsonProperty("transferData")
	private TransactionTransferToBankResponse transferData;

	public TransaccionResponseCoreV() {
		super();
	}

	public TransaccionResponseCoreV(String estado, String mensaje) {
		super(estado, mensaje);
	}

	public TransaccionResponseV getTransaccionOrigen() {
		return transaccionOrigen;
	}

	public void setTransaccionOrigen(TransaccionResponseV transaccionOrigen) {
		this.transaccionOrigen = transaccionOrigen;
	}

	public TransaccionResponseV getTransaccionDestino() {
		return transaccionDestino;
	}

	public void setTransaccionDestino(TransaccionResponseV transaccionDestino) {
		this.transaccionDestino = transaccionDestino;
	}

	public ComercioV getComercio() {
		return comercio;
	}

	public void setComercio(ComercioV comercio) {
		this.comercio = comercio;
	}

	public EmisorV getEmisor() {
		return emisor;
	}

	public void setEmisor(EmisorV emisor) {
		this.emisor = emisor;
	}

	public ClienteV getCliente() {
		return cliente;
	}

	public void setCliente(ClienteV cliente) {
		this.cliente = cliente;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public TransactionTransferToBankResponse getTransferData() {
		return transferData;
	}

	public void setTransferData(TransactionTransferToBankResponse transferData) {
		this.transferData = transferData;
	}

}
