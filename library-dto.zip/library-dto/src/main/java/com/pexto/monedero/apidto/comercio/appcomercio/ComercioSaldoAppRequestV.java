package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

public class ComercioSaldoAppRequestV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long idCuenta;
	private Long idEmisor;
	private Long idBolsillo;
	private String numeroCuenta;
	
	public Long getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Long idCuenta) {
		this.idCuenta = idCuenta;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public boolean validateProperties() throws Exception {
		if (numeroCuenta == null) {
			throw new Exception("Número de cuenta is null");
		}
		
		if (String.valueOf(numeroCuenta).trim().equals("")) {
			throw new Exception("Número de cuenta esta vacio!");
		}
		
		return true;
	}
}
