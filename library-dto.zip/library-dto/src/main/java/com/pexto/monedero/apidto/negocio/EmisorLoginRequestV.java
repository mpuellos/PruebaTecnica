package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class EmisorLoginRequestV implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private String logon;
	private String password;
	private String response;
	
	public EmisorLoginRequestV() {
		
	}
	
	public EmisorLoginRequestV(String logon, String password) {
		this.logon = logon;
		this.password = password;
		this.response = "";
	}
	
	public EmisorLoginRequestV(String logon, String password, String response) {
		this.logon = logon;
		this.password = password;
		this.response = response;
	}

	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		
		if (this.logon == null) {
			throw new Exception ("Error campo logon is null");
		}
		
		if (this.password == null) {
			throw new Exception ("Error campo passsword is null");
		}
		
		if (this.response == null) {
			throw new Exception ("Error campo response is null");
		}
		
		if (this.logon.trim().equals("")) {
			throw new Exception ("Error campo logon esta vacio!");
		}
		
		if (this.password.trim().equals("")) {
			throw new Exception ("Error campo password esta vacio");
		}
		
		if (this.response.trim().equals("")) {
			throw new Exception ("Error en casilla de verificacion, captcha no ha sido validado!");
		}
		
		return true;
	}
}