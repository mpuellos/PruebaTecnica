package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class ComercioDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String hash;
	private String token;
	private String nombreCorto;
	private Date vigencia;
	private String tipoCompensacion;
	private Date fecha;
	private String estado;
	private Long idTipoComercio;
	private Long idTipoOperacion;
	private EntidadDTO entidad;
	private Long idEntidad;
	private Long idCuenta;
	private Long idUsuarioAdmin;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getHash() {
		return hash;
	}
	public void setHash(String hash) {
		this.hash = hash;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getNombreCorto() {
		return nombreCorto;
	}
	public void setNombreCorto(String nombreCorto) {
		this.nombreCorto = nombreCorto;
	}
	public Date getVigencia() {
		return vigencia;
	}
	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}
	public String getTipoCompensacion() {
		return tipoCompensacion;
	}
	public void setTipoCompensacion(String tipoCompensacion) {
		this.tipoCompensacion = tipoCompensacion;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public Long getIdTipoComercio() {
		return idTipoComercio;
	}
	public void setIdTipoComercio(Long idTipoComercio) {
		this.idTipoComercio = idTipoComercio;
	}
	public Long getIdTipoOperacion() {
		return idTipoOperacion;
	}
	public void setIdTipoOperacion(Long idTipoOperacion) {
		this.idTipoOperacion = idTipoOperacion;
	}
	public EntidadDTO getEntidad() {
		return entidad;
	}
	public void setEntidad(EntidadDTO entidad) {
		this.entidad = entidad;
	}
	public Long getIdEntidad() {
		return idEntidad;
	}
	public void setIdEntidad(Long idEntidad) {
		this.idEntidad = idEntidad;
	}
	public Long getIdCuenta() {
		return idCuenta;
	}
	public void setIdCuenta(Long idCuenta) {
		this.idCuenta = idCuenta;
	}
	public Long getIdUsuarioAdmin() {
		return idUsuarioAdmin;
	}
	public void setIdUsuarioAdmin(Long idUsuarioAdmin) {
		this.idUsuarioAdmin = idUsuarioAdmin;
	}
	
}