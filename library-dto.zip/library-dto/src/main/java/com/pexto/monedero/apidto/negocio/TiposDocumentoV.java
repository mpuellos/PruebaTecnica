package com.pexto.monedero.apidto.negocio;

public class TiposDocumentoV {

}
