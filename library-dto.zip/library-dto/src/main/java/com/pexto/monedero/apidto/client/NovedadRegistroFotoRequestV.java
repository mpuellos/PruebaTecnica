package com.pexto.monedero.apidto.client;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class NovedadRegistroFotoRequestV implements IRequestValidator, Serializable {
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("tipoDocumento")
	private String tipoDocumento;
	
	@JsonProperty("documento")
	private String numeroDocumento;
	
	@JsonProperty("foto1")
	private String foto1;
	
	@JsonProperty("foto2")
	private String foto2;
	
	@JsonProperty("foto3")
	private String foto3;
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getFoto1() {
		return foto1;
	}

	public void setFoto1(String foto1) {
		this.foto1 = foto1;
	}

	public String getFoto2() {
		return foto2;
	}

	public void setFoto2(String foto2) {
		this.foto2 = foto2;
	}

	public String getFoto3() {
		return foto3;
	}

	public void setFoto3(String foto3) {
		this.foto3 = foto3;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((tipoDocumento == null) || (tipoDocumento.trim().length() == 0)
				|| (tipoDocumento.trim().length() != 1)) {
			throw new Exception ("El campo tipo de documento esta vacio o errado!");
		}
		
		if ((numeroDocumento == null) || (numeroDocumento.trim().length() == 0)
				|| (numeroDocumento.trim().length() > 15) || (!Parametros.validateOnlyDigits(numeroDocumento))) {
			throw new Exception ("El campo número de documento esta vacio o errado!");
		}
		
		if ((foto1 == null) || (foto1.trim().equals(""))) {
			throw new Exception ("El campo Foto 1 esta vacio o errado!");
		}
		
		if ((foto2 == null) || (foto2.trim().equals(""))) {
			throw new Exception ("El campo Foto 2 esta vacio o errado!");
		}
		
		if ((foto3 == null) || (foto3.trim().equals(""))) {
			throw new Exception ("El campo Foto 3 esta vacio o errado!");
		}
		
		return valid;
	}
}