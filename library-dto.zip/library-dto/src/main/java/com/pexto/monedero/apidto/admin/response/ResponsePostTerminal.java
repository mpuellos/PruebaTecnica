package com.pexto.monedero.apidto.admin.response;

import java.io.Serializable;

import com.pexto.monedero.apidto.admin.vo.TerminalVO;

public class ResponsePostTerminal implements Serializable {
	
	private static final long serialVersionUID = 5242731435147463143L;
	
	private TerminalVO terminalVO;

	public TerminalVO getTerminalVO() {
		return terminalVO;
	}

	public void setTerminalVO(TerminalVO terminalVO) {
		this.terminalVO = terminalVO;
	}
	
}