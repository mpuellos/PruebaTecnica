package com.pexto.monedero.apidto;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
@Getter
public enum StatusEnum {
  A("Activo"),
  I("Inactivo"),
  S("Pendiente");
  
  private final String description;
  
  
}
