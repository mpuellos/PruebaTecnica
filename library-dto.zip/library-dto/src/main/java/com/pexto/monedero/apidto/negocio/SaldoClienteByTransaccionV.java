package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class SaldoClienteByTransaccionV implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idEmisor;
	private Long idBolsillo;
	private Long idTransaccion;
	private Double valor;

	public SaldoClienteByTransaccionV() {

	}

	public SaldoClienteByTransaccionV(Long idEmisor, Long idBolsillo, Long idTransaccion, Double valor) {
		this.idEmisor = idEmisor;
		this.idBolsillo = idBolsillo;
		this.idTransaccion = idTransaccion;
		this.valor = valor;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public Long getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SaldoClienteByTransaccionV [idEmisor=");
		builder.append(idEmisor);
		builder.append(", idBolsillo=");
		builder.append(idBolsillo);
		builder.append(", idTransaccion=");
		builder.append(idTransaccion);
		builder.append(", valor=");
		builder.append(valor);
		builder.append("]");
		return builder.toString();
	}

}
