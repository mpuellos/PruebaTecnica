package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class CierreArchivoRequestV implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("idEmisor")
	private Long idEmisor;
	
	@JsonProperty("tipoArchivo")
	private Long tipoArchivo;
	
	@JsonProperty("estado")
	private String estado;
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public Long getTipoArchivo() {
		return tipoArchivo;
	}
	
	public void setTipoArchivo(Long tipoArchivo) {
		this.tipoArchivo = tipoArchivo;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		
		if ((this.idEmisor == null)) {
			throw new Exception ("Campo Id Emisor is null!");
		}
		
		if (this.idEmisor <= 0) {
			throw new Exception ("Ingrese un valor correcto para el campo Id Emisor");
		}
		
		return true;
	}
	
}
