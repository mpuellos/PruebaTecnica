package com.pexto.monedero.apidto.admin.vo;

import java.io.Serializable;
import java.util.Date;



public class SucursalVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String nombre;
	private String contacto;
	private String direccion;
	private String telefono;
	private String correo;
	private String departamento;
	private String municipio;
	private String localidad;
	private String barrio;
	private String codigoUnicoRed;
	private String isDefault;
	private Date fecha;
	private String estado;
	private Long comercioId;
	private String comercioNombre;
	private Long usuarioAdminId;
	private String hash;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getContacto() {
		return contacto;
	}

	public void setContacto(String contacto) {
		this.contacto = contacto;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}


	

	public Long getComercioId() {
		return comercioId;
	}

	public void setComercioId(Long comercioId) {
		this.comercioId = comercioId;
	}

	public Long getUsuarioAdminId() {
		return usuarioAdminId;
	}

	public void setUsuarioAdminId(Long usuarioAdminId) {
		this.usuarioAdminId = usuarioAdminId;
	}

	public String getDepartamento() {
		return departamento;
	}

	public String getMunicipio() {
		return municipio;
	}

	public String getLocalidad() {
		return localidad;
	}

	public String getBarrio() {
		return barrio;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public void setBarrio(String barrio) {
		this.barrio = barrio;
	}
	
	public String getIsDefault() {
		return isDefault;
	}

	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}

	public String getCodigoUnicoRed() {
		return codigoUnicoRed;
	}

	public void setCodigoUnicoRed(String codigoUnicoRed) {
		this.codigoUnicoRed = codigoUnicoRed;
	}

	public String getComercioNombre() {
		return comercioNombre;
	}

	public void setComercioNombre(String comercioNombre) {
		this.comercioNombre = comercioNombre;
	}
	
}
