package com.pexto.monedero.apidto.enterprises;

import com.pexto.monedero.apidto.core.ParamRequestV;
import lombok.*;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EnterpriseNovedadRequestV {

    private static final long serialVersionUID = 1L;

    private Long idNovedad;
    private Long idEmisor;
    private Long idUsuarioEmisor;
    private String tipoNovedad;
    private String motivoRechazo;
    private boolean comfirmacionSaldo;
    private ParamRequestV paramRequest;
    private Long idNovedadDetalle;

    public boolean validateComfirmacionSaldo() throws Exception {

        boolean valid = true;

        if (this.comfirmacionSaldo == false) {
            throw new Exception("Confirmacion de saldo no aceptada!");
        }

        if (String.valueOf(this.comfirmacionSaldo).equals("")) {
            throw new Exception("Confirmacion de saldo no aceptada!");
        }

        return valid;
    }

}