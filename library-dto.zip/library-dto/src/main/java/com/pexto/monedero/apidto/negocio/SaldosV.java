package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

import com.pexto.monedero.apidto.utils.Parametros;

public class SaldosV implements Serializable {

	private static final long serialVersionUID = 1L;

	private String nit;
	private String tipoIdentificacion;
	private String numeroIdentificacion;
	private String numeroCuenta;
	private double saldo = 0;
	private String codigoProducto;
	private String nombreProducto;
	private String estadoCuenta;
	private String estadoCuentaBolsillo;
	private String codigoEmisor;
	private Double saldoCliente = 0.0;
	private String fechaInscripcion;
	private String fechaUltAbono;

	public SaldosV() {
	}

	public SaldosV(String nit, String tipoIdentificacion, String numeroIdentificacion, String numeroCuenta,
			String codigoProducto, String estadoCuenta) {
		super();
		this.nit = nit;
		this.tipoIdentificacion = tipoIdentificacion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.numeroCuenta = numeroCuenta;
		this.codigoProducto = codigoProducto;
		this.estadoCuenta = estadoCuenta;
	}

	public SaldosV(String nit, String tipoIdentificacion, String numeroIdentificacion, String numeroCuenta,
			String codigoProducto, String estadoCuenta, String estadoCuentaBolsillo) {
		super();
		this.nit = nit;
		this.tipoIdentificacion = tipoIdentificacion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.numeroCuenta = numeroCuenta;
		this.codigoProducto = codigoProducto;
		this.estadoCuenta = estadoCuenta;
		this.estadoCuentaBolsillo = estadoCuentaBolsillo;
	}

	public SaldosV(String nit, String tipoIdentificacion, String numeroIdentificacion, String numeroCuenta,
			String codigoProducto, String estadoCuenta, String estadoCuentaBolsillo, String codigoEmisor,
			Double saldoCliente) {

		super();

		this.nit = nit;
		this.tipoIdentificacion = tipoIdentificacion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.numeroCuenta = numeroCuenta;
		this.codigoProducto = codigoProducto;
		this.estadoCuenta = estadoCuenta;
		this.estadoCuentaBolsillo = estadoCuentaBolsillo;
		this.codigoEmisor = codigoEmisor;
		this.saldoCliente = saldoCliente;
	}
	
	public SaldosV(String nit, String tipoIdentificacion, String numeroIdentificacion, String numeroCuenta,
			String codigoProducto, String nombreProducto, String estadoCuenta, String estadoCuentaBolsillo, String codigoEmisor,
			Double saldoCliente, Date fechaInscripcion, Date fechaUltAbono) {

		super();

		this.nit = nit;
		this.tipoIdentificacion = tipoIdentificacion;
		this.numeroIdentificacion = numeroIdentificacion;
		this.numeroCuenta = numeroCuenta;
		this.codigoProducto = (codigoProducto != null)? codigoProducto: "No definido";
		this.nombreProducto = (nombreProducto != null)? nombreProducto: "No definido";
		this.estadoCuenta = estadoCuenta;
		this.estadoCuentaBolsillo = estadoCuentaBolsillo;
		this.codigoEmisor = codigoEmisor;
		this.saldoCliente = saldoCliente;
		this.fechaInscripcion = (fechaInscripcion != null)? Parametros.getFechaNormalString(fechaInscripcion): "";
		this.fechaUltAbono = (fechaUltAbono != null)? Parametros.getFechaNormalString(fechaUltAbono): "";
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getTipoIdentificacion() {
		return tipoIdentificacion;
	}

	public void setTipoIdentificacion(String tipoIdentificacion) {
		this.tipoIdentificacion = tipoIdentificacion;
	}

	public String getNumeroIdentificacion() {
		return numeroIdentificacion;
	}

	public void setNumeroIdentificacion(String numeroIdentificacion) {
		this.numeroIdentificacion = numeroIdentificacion;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public double getSaldo() {
		return saldo;
	}

	public void setSaldo(double saldo) {
		this.saldo = saldo;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public String getNombreProducto() {
		return nombreProducto;
	}

	public void setNombreProducto(String nombreProducto) {
		this.nombreProducto = nombreProducto;
	}

	public String getEstadoCuenta() {
		return estadoCuenta;
	}

	public void setEstadoCuenta(String estadoCuenta) {
		this.estadoCuenta = estadoCuenta;
	}

	public String getEstadoCuentaBolsillo() {
		return estadoCuentaBolsillo;
	}

	public void setEstadoCuentaBolsillo(String estadoCuentaBolsillo) {
		this.estadoCuentaBolsillo = estadoCuentaBolsillo;
	}

	public String getCodigoEmisor() {
		return codigoEmisor;
	}

	public void setCodigoEmisor(String codigoEmisor) {
		this.codigoEmisor = codigoEmisor;
	}

	public Double getSaldoCliente() {
		return saldoCliente;
	}

	public void setSaldoCliente(Double saldoCliente) {
		this.saldoCliente = saldoCliente;
	}

	public String getFechaInscripcion() {
		return fechaInscripcion;
	}

	public void setFechaInscripcion(String fechaInscripcion) {
		this.fechaInscripcion = fechaInscripcion;
	}

	public String getFechaUltAbono() {
		return fechaUltAbono;
	}

	public void setFechaUltAbono(String fechaUltAbono) {
		this.fechaUltAbono = fechaUltAbono;
	}

}
