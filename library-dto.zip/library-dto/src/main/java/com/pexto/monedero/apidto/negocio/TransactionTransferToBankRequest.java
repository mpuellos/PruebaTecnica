package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

import com.pexto.monedero.apidto.exceptions.InvalidRequestException;

public class TransactionTransferToBankRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String clientTypeId;
	private String clientNumberId;
	private String walletId;
	private Double amount;
	private String typeTransfer;

	public String getClientTypeId() {
		return clientTypeId;
	}

	public void setClientTypeId(String clientTypeId) {
		this.clientTypeId = clientTypeId;
	}

	public String getClientNumberId() {
		return clientNumberId;
	}

	public void setClientNumberId(String clientNumberId) {
		this.clientNumberId = clientNumberId;
	}

	public Double getAmount() {
		return amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	public String getWalletId() {
		return walletId;
	}

	public void setWalletId(String walletId) {
		this.walletId = walletId;
	}

	public String getTypeTransfer() {
		return typeTransfer;
	}

	public void setTypeTransfer(String typeTransfer) {
		this.typeTransfer = typeTransfer;
	}

	public boolean validateProperties() throws InvalidRequestException {

		if (this.clientTypeId == null || this.clientTypeId.trim().isEmpty()) {
			throw new InvalidRequestException("El campo tipo de documento del cliente esta vacio o errado!");
		}

		if (this.clientNumberId == null || this.clientNumberId.trim().isEmpty()) {
			throw new InvalidRequestException("El campo numero de documento del cliente esta vacio o errado!");
		}

		if (this.walletId == null || this.walletId.trim().isEmpty()) {
			throw new InvalidRequestException("El campo codigo de bolsillo esta vacio o errado!");
		}

		if (this.amount == null || this.amount.intValue() <= 0) {
			throw new InvalidRequestException("El campo monto esta vacio o errado!");
		}

		return true;
	}

}
