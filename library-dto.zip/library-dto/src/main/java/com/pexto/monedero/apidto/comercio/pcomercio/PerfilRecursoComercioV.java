package com.pexto.monedero.apidto.comercio.pcomercio;

import java.io.Serializable;
import java.sql.Date;

public class PerfilRecursoComercioV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String descripcion;
	private Date fecha;
	private String estado;
	private PerfilComercioV perfilComercio;
	private RecursoComercioV recursoComercio;
	private Long usuarioAdmin;
	
	public Long getId() {
		return id;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public PerfilComercioV getPerfilComercio() {
		return perfilComercio;
	}
	
	public RecursoComercioV getRecursoComercio() {
		return recursoComercio;
	}
	
	public Long getUsuarioAdmin() {
		return usuarioAdmin;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public void setPerfilComercio(PerfilComercioV perfilComercio) {
		this.perfilComercio = perfilComercio;
	}
	
	public void setRecursoComercio(RecursoComercioV recursoComercio) {
		this.recursoComercio = recursoComercio;
	}
	
	public void setUsuarioAdmin(Long usuarioAdmin) {
		this.usuarioAdmin = usuarioAdmin;
	}
	
}
