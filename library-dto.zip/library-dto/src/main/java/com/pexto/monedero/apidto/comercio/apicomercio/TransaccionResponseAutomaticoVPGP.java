package com.pexto.monedero.apidto.comercio.apicomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.utils.PGP;

public class TransaccionResponseAutomaticoVPGP implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("transaccion")
	private String transaccion;
	
	@JsonProperty("fechaTransaccion")
	private String fechaTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("valorTransaccion")
	private String valorTransaccion;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("estadoTransaccion")
	private String estadoTransaccion;
	
	@JsonProperty("descripcionEstado")
	private String descripcionEstado;
	
	@JsonProperty("causalTransaccion")
	private String causalTransaccion;
	
	@JsonProperty("descripcionCausal")
	private String descripcionCausal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	public TransaccionResponseAutomaticoVPGP() {
		
	}
	
	public String getTransaccion() {
		return transaccion;
	}
	
	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	}
	
	public String getFechaTransaccion() {
		return fechaTransaccion;
	}
	
	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}
	
	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}
	
	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}
	
	public String getValorTransaccion() {
		return valorTransaccion;
	}
	
	public void setValorTransaccion(String valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}
	
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}
	
	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}
	
	public String getCausalTransaccion() {
		return causalTransaccion;
	}
	
	public void setCausalTransaccion(String causalTransaccion) {
		this.causalTransaccion = causalTransaccion;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getDescripcionEstado() {
		return descripcionEstado;
	}

	public void setDescripcionEstado(String descripcionEstado) {
		this.descripcionEstado = descripcionEstado;
	}

	public String getDescripcionCausal() {
		return descripcionCausal;
	}

	public void setDescripcionCausal(String descripcionCausal) {
		this.descripcionCausal = descripcionCausal;
	}
	
	public static TransaccionResponseAutomaticoVPGP Encrypt(TransaccionResponseAutomaticoAEstandarV transaccionAutomaticoV, String idPublicKey) throws Exception {
		TransaccionResponseAutomaticoVPGP transaccionAutomaticoVPGP = new TransaccionResponseAutomaticoVPGP();
		PGP pgp = new PGP();
		
		if (transaccionAutomaticoV == null) {
			throw new Exception("Error Encrypt [transaccionAutomaticoV -  null]");
		}
		
		if (idPublicKey == null) {
			throw new Exception("Error Encrypt [idPublicKey - null]");
		}
		
		try {
			
			String transaccion 			= pgp.encrypt(transaccionAutomaticoV.getTransaccion(),idPublicKey);
		    String fechaTransaccion 	= pgp.encrypt(transaccionAutomaticoV.getFechaTransaccion(), idPublicKey);
		    String numeroAutorizacion 	= pgp.encrypt(transaccionAutomaticoV.getNumeroAutorizacion(), idPublicKey); 
		    String valorTransaccion		= pgp.encrypt(String.valueOf(transaccionAutomaticoV.getValorTransaccion()), idPublicKey);
		    String tipoTransaccion		= pgp.encrypt(transaccionAutomaticoV.getTipoTransaccion(), idPublicKey);
		    String estadoTransaccion	= pgp.encrypt(transaccionAutomaticoV.getEstadoTransaccion(), idPublicKey);
		    String descripcionEstado	= pgp.encrypt(transaccionAutomaticoV.getDescripcionEstado(), idPublicKey);
		    String causalTransaccion	= pgp.encrypt(transaccionAutomaticoV.getCausalTransaccion(), idPublicKey);
		    String descripcionCausal	= pgp.encrypt(transaccionAutomaticoV.getDescripcionCausal(), idPublicKey);
		    String numeroCuenta			= pgp.encrypt(transaccionAutomaticoV.getNumeroCuenta(), idPublicKey);
			
		    transaccionAutomaticoVPGP.setTransaccion(transaccion);
		    transaccionAutomaticoVPGP.setFechaTransaccion(fechaTransaccion);
		    transaccionAutomaticoVPGP.setNumeroAutorizacion(numeroAutorizacion);
		    transaccionAutomaticoVPGP.setValorTransaccion(valorTransaccion);
		    transaccionAutomaticoVPGP.setTipoTransaccion(tipoTransaccion);
		    transaccionAutomaticoVPGP.setEstadoTransaccion(estadoTransaccion);
		    transaccionAutomaticoVPGP.setDescripcionEstado(descripcionEstado);
		    transaccionAutomaticoVPGP.setCausalTransaccion(causalTransaccion);
		    transaccionAutomaticoVPGP.setDescripcionCausal(descripcionCausal);
		    transaccionAutomaticoVPGP.setNumeroCuenta(numeroCuenta);
			
		} catch (Exception exc) {
			throw new Exception("Error Encrypt: " + exc.getMessage());
		}
		
		return transaccionAutomaticoVPGP;
	}
	
	public static TransaccionResponseAutomaticoAEstandarV Decrypt(TransaccionResponseAutomaticoVPGP transaccionAutomaticoVPGP, String passphrase) throws Exception {
		TransaccionResponseAutomaticoAEstandarV transaccionAutomaticoV = new TransaccionResponseAutomaticoAEstandarV();
		PGP pgp = new PGP();
		
		if (transaccionAutomaticoVPGP == null) {
			throw new Exception("Error Decrypt [transaccionAutomaticoVPGP -  null]");
		}
		
		if (passphrase == null) {
			throw new Exception("Error Decrypt [Passphrase - null]");
		}
		
		try {
			
			String transaccion 			= pgp.decrypt(transaccionAutomaticoVPGP.getTransaccion(),passphrase);
		    String fechaTransaccion 	= pgp.decrypt(transaccionAutomaticoVPGP.getFechaTransaccion(), passphrase);
		    String numeroAutorizacion 	= pgp.decrypt(transaccionAutomaticoVPGP.getNumeroAutorizacion(), passphrase);
		    String valorTransaccion		= pgp.decrypt(transaccionAutomaticoVPGP.getValorTransaccion(), passphrase);
		    String tipoTransaccion		= pgp.decrypt(transaccionAutomaticoVPGP.getTipoTransaccion(), passphrase);
		    String estadoTransaccion	= pgp.decrypt(transaccionAutomaticoVPGP.getEstadoTransaccion(), passphrase);
		    String descripcionEstado	= pgp.decrypt(transaccionAutomaticoVPGP.getDescripcionEstado(), passphrase);
		    String causalTransaccion	= pgp.decrypt(transaccionAutomaticoVPGP.getCausalTransaccion(), passphrase);
		    String descripcionCausal	= pgp.decrypt(transaccionAutomaticoVPGP.getDescripcionCausal(), passphrase);
		    String numeroCuenta			= pgp.decrypt(transaccionAutomaticoVPGP.getNumeroCuenta(), passphrase);
		    
		    transaccionAutomaticoV.setTransaccion(transaccion);
		    transaccionAutomaticoV.setFechaTransaccion(fechaTransaccion);
		    transaccionAutomaticoV.setNumeroAutorizacion(numeroAutorizacion);
		    transaccionAutomaticoV.setValorTransaccion(Double.parseDouble(valorTransaccion));
		    transaccionAutomaticoV.setTipoTransaccion(tipoTransaccion);
		    transaccionAutomaticoV.setEstadoTransaccion(estadoTransaccion);
		    transaccionAutomaticoV.setDescripcionEstado(descripcionEstado);
		    transaccionAutomaticoV.setCausalTransaccion(causalTransaccion);
		    transaccionAutomaticoV.setDescripcionCausal(descripcionCausal);
		    transaccionAutomaticoV.setNumeroCuenta(numeroCuenta);
			
		} catch (Exception exc) {
			throw new Exception("Error Decrypt: " + exc.getMessage());
		}
		
		return transaccionAutomaticoV;
	}
	
}
