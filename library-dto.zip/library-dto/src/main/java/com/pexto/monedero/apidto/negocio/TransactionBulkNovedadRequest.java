package com.pexto.monedero.apidto.negocio;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class TransactionBulkNovedadRequest implements Serializable {

  private static final long serialVersionUID = 1L;

  @NotNull(message = "object general cannot be null")
  private General general;

  @NotNull(message = "object of classes TransaccionNovedadDetalleEmpresas cannot be null")
  private List<TransaccionNovedadDetalleEmpresas> novedadDetalles;

  public TransactionBulkNovedadRequest() {
    this.general = new General();
    this.novedadDetalles = new ArrayList<>();
  }

  public class General implements Serializable {

    private static final long serialVersionUID = 854541595267291465L;

    @NotNull(message = "nitPagador cannot be null")
    private String nitPagador;

    @NotNull(message = "tipoPago cannot be null")
    private String tipoPago;

    @NotNull(message = "aplicacion cannot be null")
    private String aplicacion;

    @NotNull(message = "secuenciaEnvio cannot be null")
    private String secuenciaEnvio;

    @NotNull(message = "numeroCuentaADebitar cannot be null")
    private String numeroCuentaADebitar;

    @NotNull(message = "tipoCuentaADebitar cannot be null")
    private String tipoCuentaADebitar;

    @NotNull(message = "descripcionDelPago cannot be null")
    private String descripcionDelPago;

    private Double totalAPagar;

    public String getNitPagador() {
      return nitPagador;
    }

    public void setNitPagador(String nitPagador) {
      this.nitPagador = nitPagador;
    }

    public String getTipoPago() {
      return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
      this.tipoPago = tipoPago;
    }

    public String getAplicacion() {
      return aplicacion;
    }

    public void setAplicacion(String aplicacion) {
      this.aplicacion = aplicacion;
    }

    public String getSecuenciaEnvio() {
      return secuenciaEnvio;
    }

    public void setSecuenciaEnvio(String secuenciaEnvio) {
      this.secuenciaEnvio = secuenciaEnvio;
    }

    public String getNumeroCuentaADebitar() {
      return numeroCuentaADebitar;
    }

    public void setNumeroCuentaADebitar(String numeroCuentaADebitar) {
      this.numeroCuentaADebitar = numeroCuentaADebitar;
    }

    public String getTipoCuentaADebitar() {
      return tipoCuentaADebitar;
    }

    public void setTipoCuentaADebitar(String tipoCuentaADebitar) {
      this.tipoCuentaADebitar = tipoCuentaADebitar;
    }

    public String getDescripcionDelPago() {
      return descripcionDelPago;
    }

    public void setDescripcionDelPago(String descripcionDelPago) {
      this.descripcionDelPago = descripcionDelPago;
    }

    public Double getTotalAPagar() {
      return totalAPagar;
    }

    public void setTotalAPagar(Double totalAPagar) {
      this.totalAPagar = totalAPagar;
    }

  }

  @Override
  public String toString() {
    StringBuilder builder = new StringBuilder();
    builder.append(TransactionBulkNovedadRequest.class + " [general.nitPagador=");
    builder.append(general.nitPagador + ", general.tipoPago=");
    builder.append(general.tipoPago + ", general.aplicacion=");
    builder.append(general.aplicacion + ", general.secuenciaEnvio=");
    builder.append(general.secuenciaEnvio + ", general.numeroCuentaADebitar=");
    builder.append(general.numeroCuentaADebitar + ", general.tipoCuentaADebitar=");
    builder.append(general.tipoCuentaADebitar + ", general.totalAPagar=");
    builder.append(general.totalAPagar + ", general.descripcionDelPago=");
    builder.append(general.descripcionDelPago);
    builder.append("]");

    return builder.toString();
  }

  public General getGeneral() {
    return general;
  }

  public void setGeneral(General general) {
    this.general = general;
  }

  public List<TransaccionNovedadDetalleEmpresas> getNovedadDetalles() {
    return novedadDetalles;
  }

  public void setNovedadDetalles(List<TransaccionNovedadDetalleEmpresas> novedadDetalles) {
    this.novedadDetalles = novedadDetalles;
  }

}
