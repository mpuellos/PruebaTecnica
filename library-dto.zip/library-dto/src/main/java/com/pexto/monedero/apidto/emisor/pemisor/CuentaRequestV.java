package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class CuentaRequestV implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("idEmisor")
	private Long idEmisor;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("idBolsillo")
	private Long idBolsillo;
	
	@JsonProperty("idCuenta")
	private String idCuenta;
	
	public Long getIdBolsillo() {
		return idBolsillo;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public String getIdCuenta() {
		return idCuenta;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public void setIdCuenta(String idCuenta) {
		this.idCuenta = idCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	@Override
	public boolean validateProperties() throws Exception {
		
		if ((this.numeroCuenta == null) || this.numeroCuenta.trim().equals("")) {
			throw new Exception ("Campo Número de cuenta is null or empty!");
		}
		
		if (this.idEmisor == null) {
			throw new Exception ("Campo Id Emisor is null or empty!");
		}
		
		if (this.idEmisor <= 0) {
			throw new Exception ("Ingrese un valor correcto para el campo Id Emisor");
		}
		
		return true;
	}
	
}
