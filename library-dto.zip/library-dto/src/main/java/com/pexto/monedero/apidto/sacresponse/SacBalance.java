package com.pexto.monedero.apidto.sacresponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Value;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SacBalance {
  Long walletId;
  String walletName;
  Double ammount;
  String workPlaceBanckName;
}
