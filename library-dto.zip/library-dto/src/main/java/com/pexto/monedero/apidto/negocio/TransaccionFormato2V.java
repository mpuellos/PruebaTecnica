package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionFormato2V implements Serializable {

	private static final long serialVersionUID = 1L;

	private String transaccionFecha;
	private String transaccionFechaStr;
	private String transaccionHoraStr;
	private String transaccionHash;
	private String transaccionUuid;
	private String transaccionTipoTransaccionCodigo;
	private String transaccionTipoTransaccionNombre;
	private String transaccionNumeroAutorizacion;
	private Double transaccionValor;
	private String novedadDocumentoPago;
	private String novedadPeriodoLiquidado;
	private String bolsilloCodigo;
	private String bolsilloNombre;
	private String clienteTipoDocumento;
	private String clienteNumeroDocumento;
	private String clienteNumeroCuenta;
	private String comercioNombre;
	private String sucursalCodigoEmisor;
	private String sucursalCodigoInterno;
	private String sucursalNombre;

	public TransaccionFormato2V(Date transaccionFecha, String transaccionHash, String transaccionUuid, String transaccionTipoTransaccionCodigo,
			String transaccionTipoTransaccionNombre, String transaccionNumeroAutorizacion, Double transaccionValor, Double transaccionValorParcial,
			String novedadDocumentoPago, String novedadPeriodoLiquidado, String bolsilloCodigo, String bolsilloNombre,
			String clienteTipoDocumento, String clienteNumeroDocumento, String clienteNumeroCuenta,
			String comercioNombre, String sucursalCodigoEmisor, String sucursalCodigoInterno, String sucursalNombre, 
			String transaccionTipoTransaccionNaturaleza) {
		
		this.transaccionFecha = (transaccionFecha != null)? Parametros.getFechaString(transaccionFecha): "";
		this.transaccionFechaStr = (transaccionFecha != null)? Parametros.getFechaStringYYYYMMDD(transaccionFecha): "";
		this.transaccionHoraStr = (transaccionFecha != null)? Parametros.getHoraString(transaccionFecha): "";
		this.transaccionHash = transaccionHash;
		this.transaccionUuid = transaccionUuid;
		this.transaccionTipoTransaccionCodigo = transaccionTipoTransaccionCodigo;
		this.transaccionTipoTransaccionNombre = transaccionTipoTransaccionNombre;
		this.transaccionNumeroAutorizacion = transaccionNumeroAutorizacion;
		this.transaccionValor = (transaccionTipoTransaccionNaturaleza != null && transaccionTipoTransaccionNaturaleza.equals("CR"))? transaccionValor: transaccionValorParcial;
		this.novedadDocumentoPago = (novedadDocumentoPago != null)? novedadDocumentoPago: "";
		this.novedadPeriodoLiquidado = (novedadPeriodoLiquidado != null)? novedadPeriodoLiquidado: "";
		this.bolsilloCodigo = (bolsilloCodigo != null)? bolsilloCodigo: "";
		this.bolsilloNombre = (bolsilloNombre != null)? bolsilloNombre: "";
		this.clienteTipoDocumento = (clienteTipoDocumento != null)? clienteTipoDocumento: "";
		this.clienteNumeroDocumento = (clienteNumeroDocumento != null)? clienteNumeroDocumento: "";
		this.clienteNumeroCuenta = (clienteNumeroCuenta != null)? clienteNumeroCuenta: "";
		this.comercioNombre = (comercioNombre != null)? comercioNombre: "";
		this.sucursalCodigoEmisor = (sucursalCodigoEmisor != null)? sucursalCodigoEmisor: "";
		this.sucursalCodigoInterno = (sucursalCodigoInterno != null)? sucursalCodigoInterno: "";
		this.sucursalNombre = (sucursalNombre != null)? sucursalNombre: "";
	}

	public String getTransaccionFecha() {
		return transaccionFecha;
	}

	public void setTransaccionFecha(String transaccionFecha) {
		this.transaccionFecha = transaccionFecha;
	}

	public String getTransaccionFechaStr() {
		return transaccionFechaStr;
	}

	public void setTransaccionFechaStr(String transaccionFechaStr) {
		this.transaccionFechaStr = transaccionFechaStr;
	}

	public String getTransaccionHoraStr() {
		return transaccionHoraStr;
	}

	public void setTransaccionHoraStr(String transaccionHoraStr) {
		this.transaccionHoraStr = transaccionHoraStr;
	}

	public String getTransaccionHash() {
		return transaccionHash;
	}

	public void setTransaccionHash(String transaccionHash) {
		this.transaccionHash = transaccionHash;
	}

	public String getTransaccionUuid() {
		return transaccionUuid;
	}

	public void setTransaccionUuid(String transaccionUuid) {
		this.transaccionUuid = transaccionUuid;
	}

	public String getTransaccionTipoTransaccionCodigo() {
		return transaccionTipoTransaccionCodigo;
	}

	public void setTransaccionTipoTransaccionCodigo(String transaccionTipoTransaccionCodigo) {
		this.transaccionTipoTransaccionCodigo = transaccionTipoTransaccionCodigo;
	}

	public String getTransaccionTipoTransaccionNombre() {
		return transaccionTipoTransaccionNombre;
	}

	public void setTransaccionTipoTransaccionNombre(String transaccionTipoTransaccionNombre) {
		this.transaccionTipoTransaccionNombre = transaccionTipoTransaccionNombre;
	}

	public String getTransaccionNumeroAutorizacion() {
		return transaccionNumeroAutorizacion;
	}

	public void setTransaccionNumeroAutorizacion(String transaccionNumeroAutorizacion) {
		this.transaccionNumeroAutorizacion = transaccionNumeroAutorizacion;
	}

	public Double getTransaccionValor() {
		return transaccionValor;
	}

	public void setTransaccionValor(Double transaccionValor) {
		this.transaccionValor = transaccionValor;
	}

	public String getNovedadDocumentoPago() {
		return novedadDocumentoPago;
	}

	public void setNovedadDocumentoPago(String novedadDocumentoPago) {
		this.novedadDocumentoPago = novedadDocumentoPago;
	}

	public String getNovedadPeriodoLiquidado() {
		return novedadPeriodoLiquidado;
	}

	public void setNovedadPeriodoLiquidado(String novedadPeriodoLiquidado) {
		this.novedadPeriodoLiquidado = novedadPeriodoLiquidado;
	}

	public String getBolsilloCodigo() {
		return bolsilloCodigo;
	}

	public void setBolsilloCodigo(String bolsilloCodigo) {
		this.bolsilloCodigo = bolsilloCodigo;
	}

	public String getBolsilloNombre() {
		return bolsilloNombre;
	}

	public void setBolsilloNombre(String bolsilloNombre) {
		this.bolsilloNombre = bolsilloNombre;
	}

	public String getClienteTipoDocumento() {
		return clienteTipoDocumento;
	}

	public void setClienteTipoDocumento(String clienteTipoDocumento) {
		this.clienteTipoDocumento = clienteTipoDocumento;
	}

	public String getClienteNumeroDocumento() {
		return clienteNumeroDocumento;
	}

	public void setClienteNumeroDocumento(String clienteNumeroDocumento) {
		this.clienteNumeroDocumento = clienteNumeroDocumento;
	}

	public String getClienteNumeroCuenta() {
		return clienteNumeroCuenta;
	}

	public void setClienteNumeroCuenta(String clienteNumeroCuenta) {
		this.clienteNumeroCuenta = clienteNumeroCuenta;
	}

	public String getComercioNombre() {
		return comercioNombre;
	}

	public void setComercioNombre(String comercioNombre) {
		this.comercioNombre = comercioNombre;
	}

	public String getSucursalCodigoEmisor() {
		return sucursalCodigoEmisor;
	}

	public void setSucursalCodigoEmisor(String sucursalCodigoEmisor) {
		this.sucursalCodigoEmisor = sucursalCodigoEmisor;
	}

	public String getSucursalCodigoInterno() {
		return sucursalCodigoInterno;
	}

	public void setSucursalCodigoInterno(String sucursalCodigoInterno) {
		this.sucursalCodigoInterno = sucursalCodigoInterno;
	}

	public String getSucursalNombre() {
		return sucursalNombre;
	}

	public void setSucursalNombre(String sucursalNombre) {
		this.sucursalNombre = sucursalNombre;
	}

}
