package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class EnrolamientoV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String tipoDocumento;
	private String documento;
	private String numeroCuenta;
	private Date fecha;	 
	
	
	public EnrolamientoV() {
		
	}
	
	public EnrolamientoV(String tipoDocumento, String documento, String numeroCuenta, Date fecha) {
		this.tipoDocumento = tipoDocumento;
		this.documento = documento;
		this.numeroCuenta = numeroCuenta;
		this.fecha = fecha;
	}
	
	public EnrolamientoV(String tipoDocumento, String documento, String numeroCuenta) {
		this.tipoDocumento = tipoDocumento;
		this.documento = documento;
		this.numeroCuenta = numeroCuenta;
	}


	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public String getDocumento() {
		return documento;
	}

	public void setDocumento(String documento) {
		this.documento = documento;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
}
