package com.pexto.monedero.apidto.enrollment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GetEnrollmentResponse {
  String name;
  String secondName;
  String lastName;
  String secondLastName;
  String document;
  String documentType;
  String cellphone;
  String email;
  String NovedadRegistroStatus;
}
