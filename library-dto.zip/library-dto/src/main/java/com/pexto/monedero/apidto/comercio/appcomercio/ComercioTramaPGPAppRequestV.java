package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ComercioTramaPGPAppRequestV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("trama")
	private String trama;
	
	public String getTrama() {
		return trama;
	}
	
	public void setTrama(String trama) {
		this.trama = trama;
	}
	
	public boolean validateProperties() throws Exception {
		if (trama == null) {
			throw new Exception("Trama to Encrypt is null");
		}
		
		if (String.valueOf(trama).trim().equals("")) {
			throw new Exception("La trama enviada esta vacia!");
		}
		
		return true;
	}
}