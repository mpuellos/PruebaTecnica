package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class NovedadRegistroEstadoRequestV implements Serializable, IRequestValidator { 	
	
	private static final long serialVersionUID = 1L;
	
	private String tipoDocumento;
	private String numeroDocumento;
	private String fechaNacimiento;
	private String fechaExpedicion;
	private String numeroTelefono;
	private String correo;
	private String estado;
	private String motivo;
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(String fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getNumeroTelefono() {
		return numeroTelefono;
	}

	public void setNumeroTelefono(String numeroTelefono) {
		this.numeroTelefono = numeroTelefono;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(String fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((tipoDocumento == null) || (tipoDocumento.trim().length() == 0)
				|| (tipoDocumento.trim().length() != 1)) {
			throw new Exception ("El campo tipo de documento esta vacio o errado!");
		}
		
		if ((numeroDocumento == null) || (numeroDocumento.trim().length() == 0)
				|| (numeroDocumento.trim().length() > 15) || (!Parametros.validateOnlyDigits(numeroDocumento))) {
			throw new Exception ("El campo número de documento esta vacio o errado!");
		}
		
		return valid;
	}
}