package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class ComercioPGPV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long idComercio;
	private String publicKey;
	private String privateKey;
	private String passPhrase;
	private Date fecha;
	private Date vigencia;
	private String estado;
	
	public Long getIdComercio() {
		return idComercio;
	}
	
	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}
	
	public String getPublicKey() {
		return publicKey;
	}
	
	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}
	
	public String getPrivateKey() {
		return privateKey;
	}
	
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	
	public String getPassPhrase() {
		return passPhrase;
	}
	
	public void setPassPhrase(String passPhrase) {
		this.passPhrase = passPhrase;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public Date getVigencia() {
		return vigencia;
	}
	
	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
}
