package com.pexto.monedero.apidto.route53;

public class LoadBalancerCore extends LoadBalancerCustom {

	// CONSTANTS FOR TYPES OF LOAD BALANCERS OF APP
	public static final String TYPE_EMISOR = "emisor";
	public static final String TYPE_COMERCIO = "comercio";

	private String type;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		switch (type) {
			case TYPE_EMISOR:
				this.type = TYPE_EMISOR;
				break;
			case TYPE_COMERCIO:
				this.type = TYPE_COMERCIO;
				break;
			default:
				this.type = TYPE_EMISOR;
				break;
		}
	}

	public static String[] getTypeNames() {
		return new String[] { TYPE_EMISOR, TYPE_COMERCIO };
	}
}
