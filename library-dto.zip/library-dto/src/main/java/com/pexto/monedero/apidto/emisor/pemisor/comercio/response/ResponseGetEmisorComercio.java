package com.pexto.monedero.apidto.emisor.pemisor.comercio.response;

import java.io.Serializable;

import com.pexto.monedero.apidto.admin.vo.ComercioVO;
import com.pexto.monedero.apidto.admin.vo.EntidadVO;

public class ResponseGetEmisorComercio implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private EntidadVO entidad;
	private ComercioVO comercio;
	
	public EntidadVO getEntidad() {
		return entidad;
	}
	
	public void setEntidad(EntidadVO entidad) {
		this.entidad = entidad;
	}
	
	public ComercioVO getComercio() {
		return comercio;
	}
	
	public void setComercio(ComercioVO comercio) {
		this.comercio = comercio;
	}
	
}