package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class CompensacionComercioV implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long idEmisor;
	private Long idComercio;
	private String numeroDocumento;
	private String razonSocial;
	private String nombreComercio;
	private Date fechaCompensacion;
	
	public CompensacionComercioV() {
		
	}
	
	public CompensacionComercioV(Long idEmisor, Long idComercio, String nombreComercio) {
		this.idEmisor 			= idEmisor;
		this.idComercio 		= idComercio;
		this.nombreComercio 	= nombreComercio;
		this.fechaCompensacion	= null;
	}
	
	public CompensacionComercioV(Long idEmisor, Long idComercio, String nombreComercio, Date fechaCompensacion) {
		this.idEmisor 			= idEmisor;
		this.idComercio 		= idComercio;
		this.nombreComercio 	= nombreComercio;
		this.fechaCompensacion	= fechaCompensacion;
	}
	
	public CompensacionComercioV(Long idEmisor, Long idComercio, String numeroDocumento, String razonSocial, String nombreComercio, 
			Date fechaCompensacion) {
		
		this.idEmisor 			= idEmisor;
		this.idComercio 		= idComercio;
		this.numeroDocumento	= numeroDocumento;
		this.razonSocial		= razonSocial;
		this.nombreComercio 	= nombreComercio;
		this.fechaCompensacion	= fechaCompensacion;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public Long getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}
	
	public Date getFechaCompensacion() {
		return fechaCompensacion;
	}
	
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}
	
	public void setFechaCompensacion(Date fechaCompensacion) {
		this.fechaCompensacion = fechaCompensacion;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
}
