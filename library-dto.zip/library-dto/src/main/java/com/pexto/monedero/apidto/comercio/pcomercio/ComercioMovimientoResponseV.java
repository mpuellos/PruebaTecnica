package com.pexto.monedero.apidto.comercio.pcomercio;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.Date;

import com.pexto.monedero.apidto.negocio.ComercioV;
import com.pexto.monedero.apidto.utils.Parametros;

public class ComercioMovimientoResponseV extends ComercioV implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idTransaccion;
	private String uuidTransaccion;
	private String hashTransaccion;
	private Long idTransaccionDetalle;
	private Date fechaTransaccion;
	private String numeroAutorizacion;
	private double valorTransaccion;
	private String nombreSucursal;
	private String codigoTerminal;
	private String nombreTerminal;
	private String estadoTransaccion;
	private String descripcionEstado;
	private String tipoTransaccion;
	private String descripcionTipo;

	private String fechaStr;
	private String horaStr;
	private String numeroDocumento;
	private String nombres;
	private String apellidos;
	private String numeroCuenta;
	private String bolsillo;

	public ComercioMovimientoResponseV() {

	}

	public ComercioMovimientoResponseV(Long idComercio, String uuidComercio, String nombreComercio, Long idTransaccion,
			String uuidTransaccion, Date fechaTransaccion, String numeroAutorizacion, double valorTransaccion,
			String nombreSucursal, String codigoTerminal, String nombreTerminal, String estadoTransaccion,
			String tipoTransaccion) {

		this.idComercio = idComercio;
		this.uuidComercio = uuidComercio;
		this.nombreComercio = nombreComercio;
		this.idTransaccion = idTransaccion;
		this.uuidTransaccion = uuidTransaccion;
		this.fechaTransaccion = fechaTransaccion;
		this.numeroAutorizacion = numeroAutorizacion;
		this.valorTransaccion = valorTransaccion;
		this.nombreSucursal = nombreSucursal;
		this.codigoTerminal = codigoTerminal;
		this.nombreTerminal = nombreTerminal;
		this.estadoTransaccion = estadoTransaccion;
		this.tipoTransaccion = tipoTransaccion;
	}

	public ComercioMovimientoResponseV(Long idComercio, String uuidComercio, String nombreComercio, Long idTransaccion,
			String uuidTransaccion, String hashTransaccion, Date fechaTransaccion, String numeroAutorizacion, double valorTransaccion,
			String nombreSucursal, String codigoTerminal, String nombreTerminal, String estadoTransaccion,
			String descripcionEstado, String tipoTransaccion, String descripcionTipo, String numeroDocumento,
			String nombres, String apellidos, String numeroCuenta, String bolsillo) {

		this.idComercio = idComercio;
		this.uuidComercio = uuidComercio;
		this.nombreComercio = nombreComercio;
		this.idTransaccion = idTransaccion;
		this.uuidTransaccion = uuidTransaccion;
		this.hashTransaccion = hashTransaccion;
		this.fechaTransaccion = fechaTransaccion;
		this.numeroAutorizacion = numeroAutorizacion;
		this.valorTransaccion = valorTransaccion;
		this.nombreSucursal = nombreSucursal;
		this.codigoTerminal = codigoTerminal;
		this.nombreTerminal = nombreTerminal;
		this.estadoTransaccion = estadoTransaccion + " - " + descripcionEstado;
		this.descripcionEstado = descripcionEstado;
		this.tipoTransaccion = tipoTransaccion + " - " + descripcionTipo;
		this.descripcionTipo = descripcionTipo;

		this.fechaStr = Parametros.getFechaNormalString(fechaTransaccion);
		this.horaStr = Parametros.getHoraString(fechaTransaccion);
		this.numeroDocumento = numeroDocumento;
		this.nombres = nombres;
		this.apellidos = apellidos;
		try {
			this.numeroCuenta = (numeroCuenta != null)
					? Parametros.getNumeroCuentaFormato(Parametros.decodeBase64(numeroCuenta))
					: "****";
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		this.bolsillo = bolsillo;
	}

	public ComercioMovimientoResponseV(Long idComercio, String uuidComercio, String nombreComercio, Long idTransaccion,
			String uuidTransaccion, Date fechaTransaccion, String numeroAutorizacion, double valorTransaccion,
			String nombreSucursal, String codigoTerminal, String nombreTerminal, String estadoTransaccion,
			String tipoTransaccion, Long idTransaccionDetalle) {

		this.idComercio = idComercio;
		this.uuidComercio = uuidComercio;
		this.nombreComercio = nombreComercio;
		this.idTransaccion = idTransaccion;
		this.uuidTransaccion = uuidTransaccion;
		this.fechaTransaccion = fechaTransaccion;
		this.numeroAutorizacion = numeroAutorizacion;
		this.valorTransaccion = valorTransaccion;
		this.nombreSucursal = nombreSucursal;
		this.codigoTerminal = codigoTerminal;
		this.nombreTerminal = nombreTerminal;
		this.estadoTransaccion = estadoTransaccion;
		this.tipoTransaccion = tipoTransaccion;
		this.idTransaccionDetalle = idTransaccionDetalle;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public String getCodigoTerminal() {
		return codigoTerminal;
	}

	public void setCodigoTerminal(String codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}

	public String getNombreTerminal() {
		return nombreTerminal;
	}

	public void setNombreTerminal(String nombreTerminal) {
		this.nombreTerminal = nombreTerminal;
	}

	public String getEstadoTransaccion() {
		return this.estadoTransaccion;
	}

	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public Long getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public double getValorTransaccion() {
		return valorTransaccion;
	}

	public void setValorTransaccion(double valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}

	public String getNombreSucursal() {
		return nombreSucursal;
	}

	public void setNombreSucursal(String nombreSucursal) {
		this.nombreSucursal = nombreSucursal;
	}

	public Long getIdTransaccionDetalle() {
		return idTransaccionDetalle;
	}

	public void setIdTransaccionDetalle(Long idTransaccionDetalle) {
		this.idTransaccionDetalle = idTransaccionDetalle;
	}

	public String getUuidTransaccion() {
		return uuidTransaccion;
	}

	public void setUuidTransaccion(String uuidTransaccion) {
		this.uuidTransaccion = uuidTransaccion;
	}

	public String getFechaStr() {
		return fechaStr;
	}

	public void setFechaStr(String fechaStr) {
		this.fechaStr = fechaStr;
	}

	public void setHoraStr(String horaStr) {
		this.horaStr = horaStr;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getBolsillo() {
		return bolsillo;
	}

	public void setBolsillo(String bolsillo) {
		this.bolsillo = bolsillo;
	}

	public String getHashTransaccion() {
		return hashTransaccion;
	}

	public void setHashTransaccion(String hashTransaccion) {
		this.hashTransaccion = hashTransaccion;
	}

	public String getDescripcionEstado() {
		return descripcionEstado;
	}

	public void setDescripcionEstado(String descripcionEstado) {
		this.descripcionEstado = descripcionEstado;
	}

	public String getDescripcionTipo() {
		return descripcionTipo;
	}

	public void setDescripcionTipo(String descripcionTipo) {
		this.descripcionTipo = descripcionTipo;
	}

	public String getHoraStr() {
		return horaStr;
	}

}
