package com.pexto.monedero.apidto.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class ReversalAccountResponse {

  String reversalTransactionUuid;
  String reversalTransactionHash;
  String reversalAuthorizationDate;
  String reversalTransactionType;
  String reversalTransactionStatus;
  String reversalDescriptionStatus;
  String reversalTransactionCausal;
  String reversalDescriptionCausal;
  String reversalAuthorizationNumber;
  String transactionHash;
  String transactionUuid;
  String authorizationDate;
  String authorizationNumber;
  Double authorizationAmount;
  String transactionType;
  String accountNumber;
  String clientDocumentNumber;
  String walletCode;
  String walletCodeDescription;
  String workplaceBankCode;
  String workplaceBankDocumentNumber;
  String checksum;
}
