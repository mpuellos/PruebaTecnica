package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class EmisorCambioClaveRequestV implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private String logon;
	private String password;
	private String passwordNuevo;
	
	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getPasswordNuevo() {
		return passwordNuevo;
	}

	public void setPasswordNuevo(String passwordNuevo) {
		this.passwordNuevo = passwordNuevo;
	}

	@Override
	public boolean validateProperties() throws Exception {
		
		if ((this.logon == null) || (this.logon.trim().equals(""))) {
			throw new Exception ("Error campo logon is null or empty!");
		}
		
		if ((this.password == null) || (this.password.trim().equals(""))) {
			throw new Exception ("Error campo passsword is null or empty!");
		}
		
		if ((this.passwordNuevo == null) || (this.passwordNuevo.trim().equals(""))) {
			throw new Exception ("Error campo passsword nuevo is null or epmty!");
		}
		
		if ((this.passwordNuevo.trim().length() < 6) || (this.passwordNuevo.trim().length() > 15)) {
			throw new Exception ("Error campo password la longitud debe ser entre 6 y 15 caracteres!");
		}
		
		return true;
	}
}