package com.pexto.monedero.apidto.comercio.insurance;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CreateInsuranceResponseMobile {
    
  String workplaceBankAuthorizationNumber;
  String cobreAuthorizationNumber;
  String authorizationDate;
  String authorizationValue;
}
