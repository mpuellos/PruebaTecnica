package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class ComercioValidateHashRequestV implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private Long idComercio;
	private String hash;
	
	public ComercioValidateHashRequestV() {
		
	}
	
	public Long getIdComercio() {
		return idComercio;
	}
	
	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}
	
	public String getHash() {
		return hash;
	}
	
	public void setHash(String hash) {
		this.hash = hash;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		
		if (this.idComercio == null) {
			throw new Exception ("Error campo Id Comercio is null");
		}
		
		if (this.hash == null) {
			throw new Exception ("Error campo hash is null");
		}
		
		if (this.idComercio <= 0) {
			throw new Exception ("Error campo Id Comercio no valido!");
		}
		
		if (this.hash.trim().equals("")) {
			throw new Exception ("Error campo hash esta vacio!");
		}
		
		return true;
	}
	
}
