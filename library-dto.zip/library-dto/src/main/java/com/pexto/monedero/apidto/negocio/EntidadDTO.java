package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class EntidadDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String numeroDocumento;
	private String nombre;
	private String direccion;
	private String telefono1;
	private String telefono2;
	private String correo;
	private String representanteDocumento;
	private String representanteNombre;
	private String representanteCorreo;
	private String contactoNombre;
	private String contactoTelefono;
	private String contactoCorreo;
	private Date fecha;
	private String estado;
	private Long idTiposDocumento;
	private Long idUsuarioAdmin;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public String getDireccion() {
		return direccion;
	}
	
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
	public String getTelefono1() {
		return telefono1;
	}
	
	public void setTelefono1(String telefono1) {
		this.telefono1 = telefono1;
	}
	
	public String getTelefono2() {
		return telefono2;
	}
	
	public void setTelefono2(String telefono2) {
		this.telefono2 = telefono2;
	}
	public String getCorreo() {
		return correo;
	}
	
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	
	public String getRepresentanteDocumento() {
		return representanteDocumento;
	}
	
	public void setRepresentanteDocumento(String representanteDocumento) {
		this.representanteDocumento = representanteDocumento;
	}
	
	public String getRepresentanteNombre() {
		return representanteNombre;
	}
	
	public void setRepresentanteNombre(String representanteNombre) {
		this.representanteNombre = representanteNombre;
	}
	public String getRepresentanteCorreo() {
		return representanteCorreo;
	}
	
	public void setRepresentanteCorreo(String representanteCorreo) {
		this.representanteCorreo = representanteCorreo;
	}
	
	public String getContactoNombre() {
		return contactoNombre;
	}
	
	public void setContactoNombre(String contactoNombre) {
		this.contactoNombre = contactoNombre;
	}
	
	public String getContactoTelefono() {
		return contactoTelefono;
	}
	
	public void setContactoTelefono(String contactoTelefono) {
		this.contactoTelefono = contactoTelefono;
	}
	
	public String getContactoCorreo() {
		return contactoCorreo;
	}
	
	public void setContactoCorreo(String contactoCorreo) {
		this.contactoCorreo = contactoCorreo;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Long getIdTiposDocumento() {
		return idTiposDocumento;
	}
	
	public void setIdTiposDocumento(Long idTiposDocumento) {
		this.idTiposDocumento = idTiposDocumento;
	}
	
	public Long getIdUsuarioAdmin() {
		return idUsuarioAdmin;
	}
	
	public void setIdUsuarioAdmin(Long idUsuarioAdmin) {
		this.idUsuarioAdmin = idUsuarioAdmin;
	}
}