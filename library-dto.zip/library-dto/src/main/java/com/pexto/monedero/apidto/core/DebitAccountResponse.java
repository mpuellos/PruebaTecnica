package com.pexto.monedero.apidto.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Setter
@Getter
public class DebitAccountResponse {
  String transactionHash;
  String transactionUuid;
  String authorizationDate;
  String authorizationNumber;
  Double authorizationValue;
  String transactionType;
  String transactionStatus;
  String descriptionStatus;
  String transactionCausal;
  String descriptionCausal;
  String accountNumber;
  Long walletId;
  String workplaceBankCode;
  String checksum;
}
