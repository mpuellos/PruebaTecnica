package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class AlertaDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String alerta;
	private Date fecha;
	private String estado;
	private Long idTipoAlerta;
	private Long idTransaccion;
	private Long idEmisor;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getAlerta() {
		return alerta;
	}
	
	public void setAlerta(String alerta) {
		this.alerta = alerta;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Long getIdTipoAlerta() {
		return idTipoAlerta;
	}
	
	public void setIdTipoAlerta(Long idTipoAlerta) {
		this.idTipoAlerta = idTipoAlerta;
	}
	
	public Long getIdTransaccion() {
		return idTransaccion;
	}
	
	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
}
