package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class NovedadesV implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String nombreArchivo;
	private int cantidadRegistros;
	private double valorTotal;
	private String estado;
	private String fechaArchivo;
	private String consecutivo;
	private String tipoNovedad;
	private String bolsillo;
	private String tipoNovedadArchivo;
	private String codigoCausal;
	private String descripcionCausal = "";
	
	public NovedadesV () {
		
	}
	
	public NovedadesV(Long id, String nombreArchivo, int cantidadRegistros, double valorTotal, String estado,
			String fechaArchivo, String consecutivo, String tipoNovedad, String bolsillo) {
		super();
		this.id = id;
		this.nombreArchivo = nombreArchivo;
		this.cantidadRegistros = cantidadRegistros;
		this.valorTotal = valorTotal;
		this.estado = estado;
		this.fechaArchivo = fechaArchivo;
		this.consecutivo = consecutivo;
		this.tipoNovedad = tipoNovedad;
		this.bolsillo = bolsillo;
	}
	
	public NovedadesV(Long id, String nombreArchivo, int cantidadRegistros, double valorTotal, String estado,
			String fechaArchivo, String consecutivo, String tipoNovedad, String bolsillo,String tipoNovedadArchivo, String codigoCausal) {
		super();
		this.id = id;
		this.nombreArchivo = nombreArchivo;
		this.cantidadRegistros = cantidadRegistros;
		this.valorTotal = valorTotal;
		this.estado = estado;
		this.fechaArchivo = fechaArchivo;
		this.consecutivo = consecutivo;
		this.tipoNovedad = tipoNovedad;
		this.bolsillo = bolsillo;
		this.tipoNovedadArchivo = tipoNovedadArchivo;
		this.codigoCausal = codigoCausal;
	}


	public Long getId() {
		return id;
	}


	public void setId(Long id) {
		this.id = id;
	}


	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public int getCantidadRegistros() {
		return cantidadRegistros;
	}

	public void setCantidadRegistros(int cantidadRegistros) {
		this.cantidadRegistros = cantidadRegistros;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getFechaArchivo() {
		return fechaArchivo;
	}

	public void setFechaArchivo(String fechaArchivo) {
		this.fechaArchivo = fechaArchivo;
	}

	public String getConsecutivo() {
		return consecutivo;
	}

	public void setConsecutivo(String consecutivo) {
		this.consecutivo = consecutivo;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public String getBolsillo() {
		return bolsillo;
	}

	public void setBolsillo(String bolsillo) {
		this.bolsillo = bolsillo;
	}

	public String getTipoNovedadArchivo() {
		return tipoNovedadArchivo;
	}

	public void setTipoNovedadArchivo(String tipoNovedadArchivo) {
		this.tipoNovedadArchivo = tipoNovedadArchivo;
	}

	public String getCodigoCausal() {
		return codigoCausal;
	}

	public void setCodigoCausal(String codigoCausal) {
		this.codigoCausal = codigoCausal;
	}

	public String getDescripcionCausal() {
		return descripcionCausal;
	}

	public void setDescripcionCausal(String descripcionCausal) {
		this.descripcionCausal = descripcionCausal;
	}
	
	
}
