package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class CompensacionV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String fechaInicio;
	private String fechaFinal;
	
	private Long idCompensacion;
	private Long idComercio;
	private Long idEmisor;
	private String nombreComercio;
	private String nombreEmisor;
	private String estado;
	private Date fecha;
	private Date periodoInicio;
	private Date periodoFinal;
	private double cantidadTransacciones;
	private double valorTotal;

	public CompensacionV() {

	}
	
	public CompensacionV(Long idCompensacion, Long idComercio, Long idEmisor, String estado, Date fecha,
			Date periodoInicio, Date periodoFinal, double cantidadTransacciones, double valorTotal) {
		
		super();
		
		this.idCompensacion 		= idCompensacion;
		this.idComercio 			= idComercio;
		this.idEmisor 				= idEmisor;
		this.estado 				= estado;
		this.fecha 					= fecha;
		this.periodoInicio 			= periodoInicio;
		this.periodoFinal 			= periodoFinal;
		this.cantidadTransacciones 	= cantidadTransacciones;
		this.valorTotal 			= valorTotal;
	}
	
	public CompensacionV(Long idCompensacion, Long idComercio, Long idEmisor, String nombreComercio, String nombreEmisor, String estado, 
			Date fecha, Date periodoInicio, Date periodoFinal, double cantidadTransacciones, double valorTotal) {
		
		super();
		
		this.idCompensacion 		= idCompensacion;
		this.idComercio 			= idComercio;
		this.idEmisor 				= idEmisor;
		this.nombreComercio 		= nombreComercio;
		this.nombreEmisor	 		= nombreEmisor;
		this.estado 				= estado;
		this.fecha 					= fecha;
		this.periodoInicio 			= periodoInicio;
		this.periodoFinal 			= periodoFinal;
		this.cantidadTransacciones 	= cantidadTransacciones;
		this.valorTotal 			= valorTotal;
	}
	
	public Long getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public Long getIdCompensacion() {
		return idCompensacion;
	}

	public void setIdCompensacion(Long idCompensacion) {
		this.idCompensacion = idCompensacion;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public Date getPeriodoInicio() {
		return periodoInicio;
	}

	public void setPeriodoInicio(Date periodoInicio) {
		this.periodoInicio = periodoInicio;
	}

	public Date getPeriodoFinal() {
		return periodoFinal;
	}

	public void setPeriodoFinal(Date periodoFinal) {
		this.periodoFinal = periodoFinal;
	}

	public double getCantidadTransacciones() {
		return cantidadTransacciones;
	}

	public void setCantidadTransacciones(double cantidadTransacciones) {
		this.cantidadTransacciones = cantidadTransacciones;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public String getFechaFinal() {
		return fechaFinal;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}
	
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public String getNombreEmisor() {
		return nombreEmisor;
	}

	public void setNombreEmisor(String nombreEmisor) {
		this.nombreEmisor = nombreEmisor;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("CompensacionV [fechaInicio=");
		builder.append(fechaInicio);
		builder.append(", fechaFinal=");
		builder.append(fechaFinal);
		builder.append(", idCompensacion=");
		builder.append(idCompensacion);
		builder.append(", idComercio=");
		builder.append(idComercio);
		builder.append(", idEmisor=");
		builder.append(idEmisor);
		builder.append(", nombreComercio=");
		builder.append(nombreComercio);
		builder.append(", nombreEmisor=");
		builder.append(nombreEmisor);
		builder.append(", estado=");
		builder.append(estado);
		builder.append(", fecha=");
		builder.append(fecha);
		builder.append(", periodoInicio=");
		builder.append(periodoInicio);
		builder.append(", periodoFinal=");
		builder.append(periodoFinal);
		builder.append(", cantidadTransacciones=");
		builder.append(cantidadTransacciones);
		builder.append(", valorTotal=");
		builder.append(valorTotal);
		builder.append("]");
		return builder.toString();
	}
	
}
