package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class EmisorPGPV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long idEmisor;
	private String publicKey;
	private String privateKey;
	private String passPhrase;
	private String publicKeyEncrypt;
	private Date fecha;
	private Date vigencia;
	private String estado;
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public String getPublicKey() {
		return publicKey;
	}
	
	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}
	
	public String getPrivateKey() {
		return privateKey;
	}
	
	public void setPrivateKey(String privateKey) {
		this.privateKey = privateKey;
	}
	
	public String getPassPhrase() {
		return passPhrase;
	}
	
	public void setPassPhrase(String passPhrase) {
		this.passPhrase = passPhrase;
	}
	
	public String getPublicKeyEncrypt() {
		return publicKeyEncrypt;
	}

	public void setPublicKeyEncrypt(String publicKeyEncrypt) {
		this.publicKeyEncrypt = publicKeyEncrypt;
	}

	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public Date getVigencia() {
		return vigencia;
	}
	
	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("EmisorPGPV [idEmisor=");
		builder.append(idEmisor);
		builder.append(", publicKey=");
		builder.append(publicKey);
		builder.append(", privateKey=");
		builder.append(privateKey);
		builder.append(", passPhrase=");
		builder.append(passPhrase);
		builder.append(", publicKeyEncrypt=");
		builder.append(publicKeyEncrypt);
		builder.append(", fecha=");
		builder.append(fecha);
		builder.append(", vigencia=");
		builder.append(vigencia);
		builder.append(", estado=");
		builder.append(estado);
		builder.append("]");
		return builder.toString();
	}
}