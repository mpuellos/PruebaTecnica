package com.pexto.monedero.apidto.comercio.pcomercio;

import java.io.Serializable;
import java.sql.Date;

public class PerfilComercioV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String tipoPerfil;
	private String nombre;
	private String descripcion;
	private String autorizacion;
	private String anulacion;
	private String compensacion;
	private String cobro;
	private String saldo;
	private String movimiento;
	private Date fecha;
	private String estado;
	
	public Long getId() {
		return id;
	}

	public String getUuid() {
		return uuid;
	}

	public String getNombre() {
		return nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public String getAutorizacion() {
		return autorizacion;
	}

	public String getAnulacion() {
		return anulacion;
	}

	public String getCompensacion() {
		return compensacion;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getEstado() {
		return estado;
	}
	
	public void setId(Long id) {
		this.id = id;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public void setAutorizacion(String autorizacion) {
		this.autorizacion = autorizacion;
	}

	public void setAnulacion(String anulacion) {
		this.anulacion = anulacion;
	}

	public void setCompensacion(String compensacion) {
		this.compensacion = compensacion;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getTipoPerfil() {
		return tipoPerfil;
	}

	public void setTipoPerfil(String tipoPerfil) {
		this.tipoPerfil = tipoPerfil;
	}

	public String getSaldo() {
		return saldo;
	}

	public void setSaldo(String saldo) {
		this.saldo = saldo;
	}

	public String getMovimiento() {
		return movimiento;
	}

	public void setMovimiento(String movimiento) {
		this.movimiento = movimiento;
	}

	public String getCobro() {
		return cobro;
	}

	public void setCobro(String cobro) {
		this.cobro = cobro;
	}
		
}
