package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class CompensacionEmisorV implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long idEmisor;
	private Long idComercio;
	private String nombreComercio;
	private Date fechaCompensacion;
	
	public CompensacionEmisorV() {
		
	}
	
	public CompensacionEmisorV(Long idComercio, Long idEmisor, String nombreComercio, Date fechaCompensacion) {
		this.idComercio 		= idComercio;
		this.idEmisor 			= idEmisor;
		this.nombreComercio 	= nombreComercio;
		this.fechaCompensacion	= fechaCompensacion;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public Long getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}
	
	public Date getFechaCompensacion() {
		return fechaCompensacion;
	}
	
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}
	
	public void setFechaCompensacion(Date fechaCompensacion) {
		this.fechaCompensacion = fechaCompensacion;
	}
}
