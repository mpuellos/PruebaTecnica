package com.pexto.monedero.apidto.core;

import java.io.Serializable;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.PGP;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionRequestCompraRetiroAutomaticoVPGP implements Serializable, IRequestValidator {
	
private static final long serialVersionUID = 1L;
	
	@JsonProperty("tokenComercio")
	private String tokenComercio;
	
	@JsonProperty("tokenTerminal")
	private String tokenTerminal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("valor")
	private String valor;
	
	@JsonProperty("otp")
	private String otp;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("fechaTransaccion")
	private String fechaTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("idUsuarioComercio")
	private String idUsuarioComercio;
	
	@JsonProperty("authorization")
	private String authorization;
	
	@JsonProperty("paramRequest")
	private ParamRequestV paramRequest;
	
	public String getTokenComercio() {
		return tokenComercio;
	}

	public String getTokenTerminal() {
		return tokenTerminal;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public String getValor() {
		return valor;
	}

	public String getOtp() {
		return otp;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public String getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public String getIdUsuarioComercio() {
		return idUsuarioComercio;
	}

	public String getAuthorization() {
		return authorization;
	}

	public ParamRequestV getParamRequest() {
		return paramRequest;
	}

	public void setTokenComercio(String tokenComercio) {
		this.tokenComercio = tokenComercio;
	}

	public void setTokenTerminal(String tokenTerminal) {
		this.tokenTerminal = tokenTerminal;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public void setIdUsuarioComercio(String idUsuarioComercio) {
		this.idUsuarioComercio = idUsuarioComercio;
	}

	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}

	public void setParamRequest(ParamRequestV paramRequest) {
		this.paramRequest = paramRequest;
	}

	public static TransaccionRequestCompraRetiroAutomaticoVPGP Encrypt(TransaccionRequestCompraRetiroAutomaticoV transaccionRequestCompraRetiroAutomaticoV, String idPublicKey) throws Exception {
		TransaccionRequestCompraRetiroAutomaticoVPGP transaccionRequestCompraRetiroAutomaticoVPGP = null;
		ParamRequestV paramRequestV = null;
		PGP pgp = new PGP();
		
		if (transaccionRequestCompraRetiroAutomaticoV == null) {
			throw new Exception("Error Encrypt [transaccionRequestCompraRetiroAutomaticoV - null]");
		}
		
		if (idPublicKey == null) {
			throw new Exception("Error Encrypt [idPublicKey - null]");
		}
		
		try {
			
			String tokenComercio 		= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getTokenComercio(),idPublicKey);
		    String tokenTerminal 		= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getTokenTerminal(), idPublicKey);
		    String otp 					= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getOtp(), idPublicKey); 
		    String numeroCuenta			= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getNumeroCuenta(), idPublicKey);
		    String valor				= pgp.encrypt(String.valueOf(transaccionRequestCompraRetiroAutomaticoV.getValor()), idPublicKey);
		    String tipoTransaccion		= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getTipoTransaccion(), idPublicKey);
		    String fechaTransaccion		= pgp.encrypt(Parametros.getFechaString(transaccionRequestCompraRetiroAutomaticoV.getFechaTransaccion()), idPublicKey);
		    String numeroAutorizacion	= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getNumeroAutorizacion(), idPublicKey);
		    String idUsuarioComercio	= pgp.encrypt(String.valueOf(transaccionRequestCompraRetiroAutomaticoV.getIdUsuarioComercio()), idPublicKey);
		    
		    String ipLocal				= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getParamRequest().getIpLocal(), idPublicKey);
		    String ipOrigen				= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getParamRequest().getIpOrigen(), idPublicKey);
		    String userAgent			= pgp.encrypt(transaccionRequestCompraRetiroAutomaticoV.getParamRequest().getUserAgent(), idPublicKey);
			
		    transaccionRequestCompraRetiroAutomaticoVPGP = new TransaccionRequestCompraRetiroAutomaticoVPGP();
		    paramRequestV = new ParamRequestV();
		    
		    paramRequestV.setIpLocal(ipLocal);
		    paramRequestV.setIpOrigen(ipOrigen);
		    paramRequestV.setUserAgent(userAgent);
		    
		    transaccionRequestCompraRetiroAutomaticoVPGP.setTokenComercio(tokenComercio);
		    transaccionRequestCompraRetiroAutomaticoVPGP.setTokenTerminal(tokenTerminal);
		    transaccionRequestCompraRetiroAutomaticoVPGP.setOtp(otp);
		    transaccionRequestCompraRetiroAutomaticoVPGP.setNumeroCuenta(numeroCuenta);
		    transaccionRequestCompraRetiroAutomaticoVPGP.setValor(valor);
		    transaccionRequestCompraRetiroAutomaticoVPGP.setTipoTransaccion(tipoTransaccion);
		    transaccionRequestCompraRetiroAutomaticoVPGP.setFechaTransaccion(fechaTransaccion);
		    transaccionRequestCompraRetiroAutomaticoVPGP.setNumeroAutorizacion(numeroAutorizacion);
		    transaccionRequestCompraRetiroAutomaticoVPGP.setIdUsuarioComercio(idUsuarioComercio);
		    
		    transaccionRequestCompraRetiroAutomaticoVPGP.setParamRequest(paramRequestV);
			
		} catch (Exception exc) {
			throw new Exception(exc.getMessage() + " : " +  pgp.getError());
		}
		
		return transaccionRequestCompraRetiroAutomaticoVPGP;
	}
	
	public static TransaccionRequestCompraRetiroAutomaticoV Decrypt(TransaccionRequestCompraRetiroAutomaticoVPGP transaccionRequestCompraRetiroAutomaticoVPGP, String passphrase) throws Exception {
		TransaccionRequestCompraRetiroAutomaticoV transaccionRequestCompraRetiroAutomaticoV = null;
		ParamRequestV paramRequestV = null;
		PGP pgp = new PGP();
		
		if (transaccionRequestCompraRetiroAutomaticoVPGP == null) {
			throw new Exception("Error Decrypt [transaccionRequestCompraRetiroAutomaticoVPGP - null]");
		}
		
		if (passphrase == null) {
			throw new Exception("Error Decrypt [Passphrase - null]");
		}
		
		try {
			
			String tokenComercio 		= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getTokenComercio(), passphrase);
		    String tokenTerminal 		= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getTokenTerminal(), passphrase);
		    String otp 					= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getOtp(), passphrase); 
		    String numeroCuenta			= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getNumeroCuenta(), passphrase);
		    double valor				= Double.parseDouble(pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getValor(), passphrase));
		    String tipoTransaccion		= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getTipoTransaccion(), passphrase);
		    String fechaTransaccionStr	= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getFechaTransaccion(), passphrase);
		    String numeroAutorizacion 	= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getNumeroAutorizacion(), passphrase);
		    Long idUsuarioComercio	 	= Long.parseLong(pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getIdUsuarioComercio(), passphrase));
		    
		    String ipLocal			 	= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getParamRequest().getIpLocal(), passphrase);
		    String ipOrigen			 	= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getParamRequest().getIpOrigen(), passphrase);
		    String userAgent		 	= pgp.decrypt(transaccionRequestCompraRetiroAutomaticoVPGP.getParamRequest().getUserAgent(), passphrase);
			
		    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		    
		    transaccionRequestCompraRetiroAutomaticoV = new TransaccionRequestCompraRetiroAutomaticoV();
		    paramRequestV = new ParamRequestV();
		    
		    paramRequestV.setIpLocal(ipLocal);
		    paramRequestV.setIpOrigen(ipOrigen);
		    paramRequestV.setUserAgent(userAgent);
		    
		    transaccionRequestCompraRetiroAutomaticoV.setTokenComercio(tokenComercio);
		    transaccionRequestCompraRetiroAutomaticoV.setTokenTerminal(tokenTerminal);
		    transaccionRequestCompraRetiroAutomaticoV.setOtp(otp);
		    transaccionRequestCompraRetiroAutomaticoV.setNumeroCuenta(numeroCuenta);
		    transaccionRequestCompraRetiroAutomaticoV.setValor(valor);
		    transaccionRequestCompraRetiroAutomaticoV.setTipoTransaccion(tipoTransaccion);
		    transaccionRequestCompraRetiroAutomaticoV.setFechaTransaccion(dateFormat.parse(fechaTransaccionStr));
		    transaccionRequestCompraRetiroAutomaticoV.setNumeroAutorizacion(numeroAutorizacion);
		    transaccionRequestCompraRetiroAutomaticoV.setIdUsuarioComercio(idUsuarioComercio);
		    
		    transaccionRequestCompraRetiroAutomaticoV.setParamRequest(paramRequestV);
			
		} catch (Exception exc) {
			throw new Exception(exc.getMessage() + " : " +  pgp.getError());
		}
		
		return transaccionRequestCompraRetiroAutomaticoV;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		//VALIDATION NULL
		
		if (this.tokenComercio == null) {
			throw new Exception("TokenComercio - null!");
		}
		
		if (this.tokenTerminal == null) {
			throw new Exception("TokenTerminal - null!");
		}
		
		if (this.otp == null) {
			throw new Exception("OTP - null!");
		}
		
		if (this.numeroCuenta == null) {
			throw new Exception("Numero de cuenta - null!");
		}
		
		if (this.valor == null) {
			throw new Exception("Valor - null!");
		}
		
		if (this.tipoTransaccion == null) {
			throw new Exception("TipoTransaccion - null!");
		}
		
		if (this.fechaTransaccion == null) {
			throw new Exception("FechaTransaccion - null!");
		}
		
		//VALIDATION EMPTY
    	if (String.valueOf(this.tokenComercio).equals("")) {
    		throw new Exception("TokenComercio vacio!");
		}
    	
    	if (String.valueOf(this.tokenTerminal).equals("")) {
    		throw new Exception("TokenTerminal vacio!");
		}
    	
    	if (this.otp.equals("")) {
    		throw new Exception("OTP vacio!");
		}
    	
    	if (this.valor.equals("")) {
    		throw new Exception("Valor vacio!");
    	}
    	
    	if (this.numeroCuenta.equals("")) {
    		throw new Exception("Numero de cuenta vacio!");
    	}
    	
    	if (this.tipoTransaccion.equals("")) {
    		throw new Exception("Tipo Transaccion vacio!");
    	}
    	
    	return valid;
	}
}
