package com.pexto.monedero.apidto.exceptions;

public class FieldException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = -3594456433029176121L;

    private String code;
    private String text;

    public FieldException(String message, String code) {
        super(message);
        this.code = code;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

}
