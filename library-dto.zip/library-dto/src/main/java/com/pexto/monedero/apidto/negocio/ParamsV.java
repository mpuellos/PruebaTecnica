package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class ParamsV implements Serializable {

	private static final long serialVersionUID = 1L;
	private String id;
	private String fecha;
	private String idEmisor;
	private String idBolsillo;
	private String idUsuarioEmisor;
	private String numeroDocumento;
	private String nroReferente;
	private String numeroCuenta;
	private String tipoDocumento;
	private String fechaExpedicion;
	private String plataforma;
	private String otp;
	private String id_enrolamiento;
	private String pin1;
	private String pin2;
	private String pin3;
	private String hash;
	private String uuid;
	private String hash_otp;
	private String tramaQR;

	public ParamsV() {
        this.idEmisor="1";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public void setIdUsuarioEmisor(String idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public String getId_enrolamiento() {
		return id_enrolamiento;
	}

	public void setId_enrolamiento(String id_enrolamiento) {
		this.id_enrolamiento = id_enrolamiento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(String fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getPlataforma() {
		return plataforma;
	}

	public void setPlataforma(String plataforma) {
		this.plataforma = plataforma;
	}

	public String getOtp() {
		return otp;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getPin1() {
		return pin1;
	}

	public void setPin1(String pin1) {
		this.pin1 = pin1;
	}

	public String getPin2() {
		return pin2;
	}

	public void setPin2(String pin2) {
		this.pin2 = pin2;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public String getPin3() {
		return pin3;
	}

	public void setPin3(String pin3) {
		this.pin3 = pin3;
	}

	public String getHash_otp() {
		return hash_otp;
	}

	public void setHash_otp(String hash_otp) {
		this.hash_otp = hash_otp;
	}

	public String getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(String idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ParamsV [fecha=");
		builder.append(fecha);
		builder.append(", idEmisor=");
		builder.append(idEmisor);
		builder.append(", idBolsillo=");
		builder.append(idBolsillo);
		builder.append(", idUsuarioEmisor=");
		builder.append(idUsuarioEmisor);
		builder.append(", numeroDocumento=");
		builder.append(numeroDocumento);
		builder.append(", numeroCuenta=");
		builder.append(numeroCuenta);
		builder.append(", tipoDocumento=");
		builder.append(tipoDocumento);
		builder.append(", fechaExpedicion=");
		builder.append(fechaExpedicion);
		builder.append(", plataforma=");
		builder.append(plataforma);
		builder.append(", otp=");
		builder.append(otp);
		builder.append(", nroReferente=");
		builder.append(nroReferente);
		builder.append(", id_enrolamiento=");
		builder.append(id_enrolamiento);
		builder.append(", pin1=");
		builder.append(pin1);
		builder.append(", pin2=");
		builder.append(pin2);
		builder.append(", pin3=");
		builder.append(pin3);
		builder.append(", hash=");
		builder.append(hash);
		builder.append(", hash_otp=");
		builder.append(hash_otp);
		builder.append("]");
		return builder.toString();
	}

	public String getTramaQR() {
		return tramaQR;
	}

	public void setTramaQR(String tramaQR) {
		this.tramaQR = tramaQR;
	}

    public String getNroReferente() {
        return nroReferente;
    }

    public void setNroReferente(String nroReferente) {
        this.nroReferente = nroReferente;
    }
	
}
