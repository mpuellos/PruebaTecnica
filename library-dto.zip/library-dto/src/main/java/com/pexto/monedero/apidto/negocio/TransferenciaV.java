package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class TransferenciaV implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String numeroCuentaOrigen;
	private String numeroCuentaDestino;
	private String otp;
	private Long idbolsillo;
	private double valor;
	private String token;
	
	public String getNumeroCuentaOrigen() {
		return numeroCuentaOrigen;
	}
	
	public void setNumeroCuentaOrigen(String numeroCuentaOrigen) {
		this.numeroCuentaOrigen = numeroCuentaOrigen;
	}
	
	public String getNumeroCuentaDestino() {
		return numeroCuentaDestino;
	}
	
	public void setNumeroCuentaDestino(String numeroCuentaDestino) {
		this.numeroCuentaDestino = numeroCuentaDestino;
	}
	
	public Long getIdbolsillo() {
		return idbolsillo;
	}
	
	public void setIdbolsillo(Long idbolsillo) {
		this.idbolsillo = idbolsillo;
	}
	
	public double getValor() {
		return valor;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public String getOtp() {
		return otp;
	}
	
	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	
}
