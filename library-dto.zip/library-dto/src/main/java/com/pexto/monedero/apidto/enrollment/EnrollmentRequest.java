package com.pexto.monedero.apidto.enrollment;

import java.time.LocalDate;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EnrollmentRequest {

  String uuid;
  String deviceUuid;
  String name;
  String secondName;
  String lastName;
  String secondLastName;
  String birthdate;
  String gender;
  String bloodType;
  String document;
  DocumentType documentType;
  String documentDate;
  String cellphone;
  String email;
  String address;
  String enrollmentType;
  String enrollmentStatus;
  String referredCode;
  String referrerCode;
}
