package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class TransactionTransferToBankResponse implements Serializable {

	private static final long serialVersionUID = 1L;

	public Transaccion transaccion;
	public Client client;

	public TransactionTransferToBankResponse() {
		this.transaccion = new Transaccion();
		this.client = new Client();
	}

	public class Transaccion {

		@NotNull(message = "transaction id cannot be null")
		public String id;

		@NotNull(message = "transaction ui of the client cannot be null")
		public String uuid;
		
		@NotNull(message = "transaction hash of the client cannot be null")
		public String hash;

		@NotNull(message = "date of the transaction cannot be null")
		public String date;

		@NotNull(message = "number of authorization of the transaction cannot be null")
		public String numberAuthorization;
	}

	public class Client {

		@NotNull(message = "typeId of the client cannot be null")
		public String typeId;

		@NotNull(message = "numberId of the client cannot be null")
		public String numberId;

		@NotNull(message = "name of the client cannot be null")
		public String name;

		@NotNull(message = "name of the client cannot be null")
		public String surname;

		@NotNull(message = "email of the client cannot be null")
		public String email;

		@NotNull(message = "cellphoneNumber of the client cannot be null")
		public String cellphoneNumber;

		@NotNull(message = "accountNumber of the client cannot be null")
		public String accountNumber;

		@NotNull(message = "birthday of the client cannot be null")
		public String birthday;

		@NotNull(message = "expeditionDate of the client cannot be null")
		public String expeditionDate;
	}
}
