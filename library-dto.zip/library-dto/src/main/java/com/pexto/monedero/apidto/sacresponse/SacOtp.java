package com.pexto.monedero.apidto.sacresponse;

import java.math.BigInteger;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Value;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SacOtp {
  String autorizationNumber;
  String type;
  BigInteger value;
  String status;
}
