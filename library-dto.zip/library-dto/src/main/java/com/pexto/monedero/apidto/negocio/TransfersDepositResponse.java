package com.pexto.monedero.apidto.negocio;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class TransfersDepositResponse {

    private String uuid;
    private String hash;
    private String date;
    private String numberAuthorization;

}
