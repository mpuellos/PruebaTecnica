package com.pexto.monedero.apidto.emisor.pemisor.afiliado;

import java.io.Serializable;

public class CrearCuentaBolsilloResponse implements Serializable {
    /**
    *
    */
    private static final long serialVersionUID = 1330854800024890416L;
    private String estado;
    private String mensaje;
    private String documentId;
    private String documentType;
    private String walletId;

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getWalletId() {
        return walletId;
    }

    public void setWalletId(String walletId) {
        this.walletId = walletId;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

}
