package com.pexto.monedero.apidto.push;

import java.io.Serializable;

public class DataVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String mensaje;

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}