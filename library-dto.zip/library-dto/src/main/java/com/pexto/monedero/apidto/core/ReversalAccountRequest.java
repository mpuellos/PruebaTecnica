package com.pexto.monedero.apidto.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@AllArgsConstructor
public class ReversalAccountRequest {

  String commerceToken;
  String terminalToken;
  String authorization;
  String accountNumber;
  String transactionAuthorization;
  Double amount;
  String transactionType;
  String transactionDate;
  String walletUuid;
  Long walletId;
  String otp;
  String localIp;
  String origin;
  String transactionInfo;
  String originIp;
  String userAgent;
  String checksum;
}
