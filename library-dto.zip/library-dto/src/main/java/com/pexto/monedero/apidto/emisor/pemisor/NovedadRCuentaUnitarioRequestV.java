package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;
import java.util.Date;

import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class NovedadRCuentaUnitarioRequestV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private Date fechaRegistro;
	private String ipOrigen;
	private String numeroDocumento;
	private String tipoDocumento;
	private String nombres;
	private String apellidos;
	private Date fechaNacimiento;
	private Date fechaExpedicion;
	private String correo;
	private String numeroCuenta;
	private String numeroCuentaNuevo;
	private String numeroTicket;
	private String validacionBiometrica;
	private String validacionSeguridad;
	private Date fecha;
	private String estado;
	private String codigoProducto;
	private String tipoOperacion;
	private String tipoNovedad;
	private Long idEmisor;
	private Long idBolsillo;
	private Long idCliente;
	private Long idCuenta;
	private Long idUsuarioEmisor;
	
	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public Date getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(Date fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getNumeroCuentaNuevo() {
		return numeroCuentaNuevo;
	}

	public void setNumeroCuentaNuevo(String numeroCuentaNuevo) {
		this.numeroCuentaNuevo = numeroCuentaNuevo;
	}

	public String getNumeroTicket() {
		return numeroTicket;
	}

	public void setNumeroTicket(String numeroTicket) {
		this.numeroTicket = numeroTicket;
	}

	public String getValidacionBiometrica() {
		return validacionBiometrica;
	}

	public void setValidacionBiometrica(String validacionBiometrica) {
		this.validacionBiometrica = validacionBiometrica;
	}

	public String getValidacionSeguridad() {
		return validacionSeguridad;
	}

	public void setValidacionSeguridad(String validacionSeguridad) {
		this.validacionSeguridad = validacionSeguridad;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public Long getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(Long idCliente) {
		this.idCliente = idCliente;
	}

	public Long getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Long idCuenta) {
		this.idCuenta = idCuenta;
	}

	public Long getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public void setIdUsuarioEmisor(Long idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	@Override
	public boolean validateProperties() throws Exception {
		//VALIDATION_NULL
		
		if (this.numeroDocumento == null || this.numeroDocumento.equals("")) {
			throw new Exception("Error en el campo Número de Documento is null!");
		}else {
			if (!Parametros.validateOnlyDigits(numeroDocumento)) {
				throw new Exception ("Error en el campo Número de Documento, valor errado: " + numeroDocumento);
			}
			
			Long numeroDocumentoLong = Long.parseLong(numeroDocumento);
			
			if (numeroDocumentoLong <= 0) {
				throw new Exception ("Error en el registro - campo Número de Documento, valor inferior o igual a 0: " + numeroDocumento);
			}
		}
		
		if (this.tipoDocumento == null || this.tipoDocumento.equals("")) {
			throw new Exception("Tipo de documento - null!");
		}else {
			if (!Parametros.validateOnlyDigits(tipoDocumento)) {
				throw new Exception ("Error en el campo Tipo de Documento, valor errado: " + numeroDocumento);
			}
		}
		
		if (this.nombres == null || this.nombres.equals("")) {
			throw new Exception("Nombres - null!");
		}else {
			if (!Parametros.validateOnlyLettersAndDigits(nombres)) {
				throw new Exception ("Error en el campo Nombres, valor errado: " + nombres);
			}
		}
		
		if (this.apellidos == null || this.apellidos.equals("")) {
			throw new Exception("Apellidos - null!");
		}else {
			if (!Parametros.validateOnlyLettersAndDigits(nombres)) {
				throw new Exception ("Error en el campo Apellidos, valor errado: " + nombres);
			}
		}
		
		if (this.correo == null || this.correo.equals("")) {
			throw new Exception("Correo electrónico - null!");
		}
		
		if (this.numeroCuenta == null || this.numeroCuenta.equals("")) {
			throw new Exception("Número de cuenta - null!");
		}else {
			if (!Parametros.validateOnlyDigits(numeroCuenta)) {
				throw new Exception ("Error en el campo Número de Cuenta, valor errado: " + numeroCuenta);
			}
			
			Long numeroCuentaLong = Long.parseLong(numeroCuenta);
			
			if (numeroCuentaLong <= 0) {
				throw new Exception ("Error en el campo Número de Cuenta Nuevo, valor errado, número menor o igual a 0: " + numeroCuentaLong);
			}
		}
		
		if (this.numeroCuentaNuevo == null || this.numeroCuentaNuevo.equals("")) {
			throw new Exception("Número de cuenta nuevo - null!");
		}else {
			if (!Parametros.validateOnlyDigits(numeroCuentaNuevo)) {
				throw new Exception ("Error en el campo Número de Cuenta Nuevo, valor errado: " + numeroCuentaNuevo);
			}
			
			Long numeroCuentaNuevoLong = Long.parseLong(numeroCuentaNuevo);
			
			if (numeroCuentaNuevoLong <= 0) {
				throw new Exception ("Error en el campo Número de Cuenta Nuevo, valor errado, número menor o igual a 0: " + numeroCuentaNuevoLong);
			}
		}
		
		if (this.idEmisor == null || String.valueOf(this.idEmisor).equals("")) {
			throw new Exception("Error en el campo Id Emisor - null!");
		}
		
		if (this.idBolsillo == null || String.valueOf(this.idBolsillo).equals("")) {
			throw new Exception("Error en el campo Id Bolsillo - null!");
		}
		
		return true;
	}
	
}