package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class NovedadV implements Serializable, IRequestValidator {

	private static final long serialVersionUID = 1L;

	private String nombreArchivo;
	private String cantidadRegistros;
	private String valorTotal;
	private String direccionIP;
	private String tipoOperacion;
	private String tipoNovedad;
	private String tipoNovedadArchivo;
	private String idEmisor;
	private String bolsillo;
	private String usuarioEmisor;
	private String nit;
	private String fechaArchivo;
	private String consecutivo;
	private String id;
	private String estadoNovedad;
	private String codigoEmisor;
	private String descripcion;
	private Date fechaCorte;
	private String documentoPago;

	public String getConsecutivo() {
		return consecutivo;
	}

	public void setConsecutivo(String consecutivo) {
		this.consecutivo = consecutivo;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}

	public String getCantidadRegistros() {
		return cantidadRegistros;
	}

	public void setCantidadRegistros(String cantidadRegistros) {
		this.cantidadRegistros = cantidadRegistros;
	}

	public String getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(String valorTotal) {
		this.valorTotal = valorTotal;
	}

	public String getDireccionIP() {
		return direccionIP;
	}

	public void setDireccionIP(String direccionIP) {
		this.direccionIP = direccionIP;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public String getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getUsuarioEmisor() {
		return usuarioEmisor;
	}

	public void setUsuarioEmisor(String usuarioEmisor) {
		this.usuarioEmisor = usuarioEmisor;
	}

	public String getBolsillo() {
		return bolsillo;
	}

	public void setBolsillo(String bolsillo) {
		this.bolsillo = bolsillo;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getFechaArchivo() {
		return fechaArchivo;
	}

	public void setFechaArchivo(String fechaArchivo) {
		this.fechaArchivo = fechaArchivo;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTipoNovedadArchivo() {
		return tipoNovedadArchivo;
	}

	public void setTipoNovedadArchivo(String tipoNovedadArchivo) {
		this.tipoNovedadArchivo = tipoNovedadArchivo;
	}

	public String getEstadoNovedad() {
		return estadoNovedad;
	}

	public void setEstadoNovedad(String estadoNovedad) {
		this.estadoNovedad = estadoNovedad;
	}

	public Date getFechaCorte() {
		return fechaCorte;
	}

	public void setFechaCorte(Date fechaCorte) {
		this.fechaCorte = fechaCorte;
	}

	public String getCodigoEmisor() {
		return codigoEmisor;
	}

	public void setCodigoEmisor(String codigoEmisor) {
		this.codigoEmisor = codigoEmisor;
	}
	
	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getDocumentoPago() {
		return documentoPago;
	}

	public void setDocumentoPago(String documentoPago) {
		this.documentoPago = documentoPago;
	}

	@Override
	public boolean validateProperties() throws Exception {

		if (this.nombreArchivo == null || this.nombreArchivo.length() == 0) {
			throw new Exception("nombreArchivo es nulo");
		}

		if (this.cantidadRegistros == null || this.cantidadRegistros.length() == 0) {
			throw new Exception("cantidadRegistro es nulo");
		}

		if (this.direccionIP == null || this.direccionIP.length() == 0) {
			throw new Exception("direccionIP es nulo");
		}

		if (this.tipoOperacion == null || this.tipoOperacion.length() == 0) {
			throw new Exception("tipoOperacion es nulo");
		}

		if (this.tipoNovedad == null || this.tipoNovedad.length() == 0) {
			throw new Exception("tipoNovedad es nulo");
		}

		if (this.tipoNovedad.equals("M")) {
			if (this.valorTotal == null || this.valorTotal.length() == 0) {
				throw new Exception("valorTotal es nulo");
			}
		}

		if (this.idEmisor == null || this.idEmisor.length() == 0) {
			throw new Exception("idEmisor es nulo");
		}

		if (this.usuarioEmisor == null || this.usuarioEmisor.length() == 0) {
			throw new Exception("usuarioEmisor es nulo");
		}

		if (this.bolsillo == null || this.bolsillo.length() == 0) {
			throw new Exception("bolsillo es nulo");
		}

		if (this.nit == null || this.nit.length() == 0) {
			throw new Exception("nit es nulo");
		}

		if (this.fechaArchivo == null || this.fechaArchivo.length() == 0) {
			throw new Exception("fechaArchivo es nulo");
		}

		if (this.consecutivo == null || this.consecutivo.length() == 0) {
			throw new Exception("consecutivo es nulo");
		}

		return true;
	}

	public boolean validatePropertiesSalidaArchivo() throws Exception {

		if (this.id == null) {
			throw new Exception("Id Novedad es nulo");
		}

		if (this.tipoNovedad == null || this.tipoNovedad.length() == 0) {
			throw new Exception("Tipo de Novedad es nulo");
		}

		if (this.idEmisor == null || this.idEmisor.length() == 0) {
			throw new Exception("Id Emisor es nulo");
		}

		if (this.usuarioEmisor == null || this.usuarioEmisor.length() == 0) {
			throw new Exception("Usuario Emisor es nulo");
		}

		return true;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("NovedadV [nombreArchivo=");
		builder.append(nombreArchivo);
		builder.append(", cantidadRegistros=");
		builder.append(cantidadRegistros);
		builder.append(", valorTotal=");
		builder.append(valorTotal);
		builder.append(", direccionIP=");
		builder.append(direccionIP);
		builder.append(", tipoOperacion=");
		builder.append(tipoOperacion);
		builder.append(", tipoNovedad=");
		builder.append(tipoNovedad);
		builder.append(", tipoNovedadArchivo=");
		builder.append(tipoNovedadArchivo);
		builder.append(", idEmisor=");
		builder.append(idEmisor);
		builder.append(", bolsillo=");
		builder.append(bolsillo);
		builder.append(", usuarioEmisor=");
		builder.append(usuarioEmisor);
		builder.append(", nit=");
		builder.append(nit);
		builder.append(", fechaArchivo=");
		builder.append(fechaArchivo);
		builder.append(", consecutivo=");
		builder.append(consecutivo);
		builder.append(", id=");
		builder.append(id);
		builder.append("]");
		return builder.toString();
	}

}
