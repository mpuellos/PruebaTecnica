package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class TerminalV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String hash;
	private String codigo;
	private String nombre;
	private String token;
	private Date fecha;
	private String estado;
	private Long idSucursal;
	
	public TerminalV() {
		
	}
	
	public TerminalV(Long id, String uuid, String hash, String codigo, String nombre, Long idSucursal) {
		super();
		
		this.id = id;
		this.uuid = uuid;
		this.hash = hash;
		this.codigo = codigo;
		this.nombre = nombre;
		this.idSucursal = idSucursal;
	}
	
	public TerminalV(Long id, String uuid, String hash, String codigo, String nombre, Date fecha, String estado,
			String token, Long idSucursal) {
		
		super();
		
		this.id = id;
		this.uuid = uuid;
		this.hash = hash;
		this.codigo = codigo;
		this.nombre = nombre;
		this.fecha = fecha;
		this.estado = estado;
		this.token = token;
		this.idSucursal = idSucursal;
	}

	public Long getId() {
		return id;
	}

	public String getUuid() {
		return uuid;
	}

	public String getHash() {
		return hash;
	}

	public String getCodigo() {
		return codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getEstado() {
		return estado;
	}

	public String getToken() {
		return token;
	}

	public Long getIdSucursal() {
		return idSucursal;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public void setIdSucursal(Long idSucursal) {
		this.idSucursal = idSucursal;
	}
	
}
