package com.pexto.monedero.apidto.admin.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class RequestPostSucursal implements Serializable ,IRequestValidator{

	private static final long serialVersionUID = 1L;

	@JsonProperty("id")	
	private Long id;
	
	@JsonProperty("nombre")	
	private String nombre;
	
	@JsonProperty("contacto")	
	private String contacto;
	
	@JsonProperty("direccion")	
	private String direccion;
	
	@JsonProperty("telefono")	
	private String telefono;
	
	@JsonProperty("correo")	
	private String correo;
	
	@JsonProperty("departamento")	
	private String departamento;
	
	@JsonProperty("municipio")	
	private String municipio;	
	
	@JsonProperty("localidad")	
	private String localidad;
	
	@JsonProperty("barrio")	
	private String barrio;
	
	@JsonProperty("codigoUnicoRed")	
	private String codigoUnicoRed;
	
	@JsonProperty("isDefault")	
	private String defecto;
	
	@JsonProperty("fecha")	
	private String fecha;
	
	@JsonProperty("estado")	
	private String estado;
	
	@JsonProperty("comercioId")	
	private String comercioId;
	
	@JsonProperty("usuarioAdminId")	
	private String usuarioAdminId;
		
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getContacto() {
		return contacto;
	}

	public void setContacto(String contacto) {
		this.contacto = contacto;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCorreo() {
		return correo;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getDepartamento() {
		return departamento;
	}

	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}

	public String getMunicipio() {
		return municipio;
	}

	public void setMunicipio(String municipio) {
		this.municipio = municipio;
	}

	public String getLocalidad() {
		return localidad;
	}

	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}

	public String getBarrio() {
		return barrio;
	}

	public void setBarrio(String barrio) {
		this.barrio = barrio;
	}

	public String getCodigoUnicoRed() {
		return codigoUnicoRed;
	}

	public void setCodigoUnicoRed(String codigoUnicoRed) {
		this.codigoUnicoRed = codigoUnicoRed;
	}

	public String getDefecto() {
		return defecto;
	}

	public void setDefecto(String defecto) {
		this.defecto = defecto;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getComercioId() {
		return comercioId;
	}

	public void setComercioId(String comercioId) {
		this.comercioId = comercioId;
	}

	public String getUsuarioAdminId() {
		return usuarioAdminId;
	}

	public void setUsuarioAdminId(String usuarioAdminId) {
		this.usuarioAdminId = usuarioAdminId;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		return valid;
	}	
}