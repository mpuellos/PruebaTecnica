package com.pexto.monedero.apidto.admin.vo;

import java.io.Serializable;
import java.util.Date;

public class ComercioVO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String hash;
	private String token;
	private String nombreCorto;
	private Date vigencia;
	private String autorizacionApp;
	private String tokenApp;
	private String tipoCompensacion;
	private Date fecha;
	private String estado;
	private Long idTiposComercio;
	private Long idTiposOperacion;
	private String tiposComercio;
	private String tiposOperacion;
	private EntidadVO entidad;
	private Long idEntidad;
	private Long idCuenta;
	private Long idUsuarioAdmin;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public String getHash() {
		return hash;
	}
	
	public void setHash(String hash) {
		this.hash = hash;
	}
	
	public String getToken() {
		return token;
	}
	
	public void setToken(String token) {
		this.token = token;
	}
	
	public String getNombreCorto() {
		return nombreCorto;
	}
	public void setNombreCorto(String nombreCorto) {
		this.nombreCorto = nombreCorto;
	}
	
	public Date getVigencia() {
		return vigencia;
	}
	
	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}
	
	public String getAutorizacionApp() {
		return autorizacionApp;
	}
	
	public void setAutorizacionApp(String autorizacionApp) {
		this.autorizacionApp = autorizacionApp;
	}
	
	public String getTokenApp() {
		return tokenApp;
	}
	
	public void setTokenApp(String tokenApp) {
		this.tokenApp = tokenApp;
	}
	
	public String getTipoCompensacion() {
		return tipoCompensacion;
	}
	
	public void setTipoCompensacion(String tipoCompensacion) {
		this.tipoCompensacion = tipoCompensacion;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Long getIdTiposComercio() {
		return idTiposComercio;
	}
	
	public void setIdTiposComercio(Long idTiposComercio) {
		this.idTiposComercio = idTiposComercio;
	}
	
	public Long getIdTiposOperacion() {
		return idTiposOperacion;
	}
	
	public void setIdTiposOperacion(Long idTiposOperacion) {
		this.idTiposOperacion = idTiposOperacion;
	}
	
	public Long getIdEntidad() {
		return idEntidad;
	}
	
	public void setIdEntidad(Long idEntidad) {
		this.idEntidad = idEntidad;
	}
	
	public Long getIdCuenta() {
		return idCuenta;
	}
	
	public void setIdCuenta(Long idCuenta) {
		this.idCuenta = idCuenta;
	}
	
	public Long getIdUsuarioAdmin() {
		return idUsuarioAdmin;
	}
	
	public void setIdUsuarioAdmin(Long idUsuarioAdmin) {
		this.idUsuarioAdmin = idUsuarioAdmin;
	}

	public EntidadVO getEntidad() {
		return entidad;
	}

	public void setEntidad(EntidadVO entidad) {
		this.entidad = entidad;
	}

	public String getTiposComercio() {
		return tiposComercio;
	}

	public void setTiposComercio(String tiposComercio) {
		this.tiposComercio = tiposComercio;
	}

	public String getTiposOperacion() {
		return tiposOperacion;
	}

	public void setTiposOperacion(String tiposOperacion) {
		this.tiposOperacion = tiposOperacion;
	}
}