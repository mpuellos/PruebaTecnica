package com.pexto.monedero.apidto.enrollment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EnrollmentPinRequest {
  String pin;
  String ipAddress;
  String workplaceBank;
  String deviceUuid;
  String enrollmentUuid;
  String platform;
  String appVersion;
}
