package com.pexto.monedero.apidto.enrollment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RejectEnrollmentRequest {

  String document;
  String documentType;
  String workplaceBank;
  String messageReject;
  
}
