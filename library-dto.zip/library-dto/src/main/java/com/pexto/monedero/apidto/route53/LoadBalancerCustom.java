package com.pexto.monedero.apidto.route53;

public class LoadBalancerCustom {

	private String dns;
	private String zoneId;

	public String getDns() {
		return dns;
	}

	public void setDns(String dns) {
		this.dns = dns;
	}

	public String getZoneId() {
		return zoneId;
	}

	public void setZoneId(String zoneId) {
		this.zoneId = zoneId;
	}

}
