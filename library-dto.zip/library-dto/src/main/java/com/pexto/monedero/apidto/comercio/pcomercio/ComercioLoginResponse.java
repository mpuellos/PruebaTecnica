package com.pexto.monedero.apidto.comercio.pcomercio;

import com.pexto.monedero.apidto.negocio.ComercioV;
import com.pexto.monedero.apidto.utils.Parametros;

public class ComercioLoginResponse extends ComercioV {
	
	private static final long serialVersionUID = 1L;
	
	private Long usuarioComercioId;
	private String usuarioComercioUUID;
	private String usuarioComercioLogon;
	private String usuarioComercioAutorizador;
	private String usuarioComercioAnulacion;
	private String comercioUUID;
	private String comercioHash;
	private String comercioNumeroDocumento;
	private String comercioNombre;
	private String comercioTipoOperacion;
	private String usuarioNombre;
	private String usuarioNumeroDocumento;
	private Long idSucursal;
	private String sucursalUUID;
	private String sucursalHash;
	private String sucursalNombre;
	private Long idTerminal;
	private String terminalUUID;
	private String terminalHash;
	private String terminalCodigo;
	private String terminalNombre;
	private String token;
	private String isCambioClave;
	private String logon;
	
	public ComercioLoginResponse() {
		
	}
	
	public ComercioLoginResponse(Long usuarioComercioId, String usuarioComercioUUID, String usuarioComercioLogon,
			String usuarioComercioAutorizador, String usuarioComercioAnulacion, 
			Long idComercio, String comercioUUID, String comercioHash, 
			String comercioNumeroDocumento, String comercioNombre, 
			String comercioTipoOperacion, String usuarioNombre, 
			String usuarioNumeroDocumento, Long idSucursal, String sucursalUUID, 
			String sucursalHash, String sucursalNombre, Long idTerminal, String terminalUUID, 
			String terminalHash, String terminalCodigo, String terminalNombre) {
		
		this.usuarioComercioId = usuarioComercioId;
		this.usuarioComercioUUID = usuarioComercioUUID;
		this.usuarioComercioLogon = usuarioComercioLogon;
		this.usuarioComercioAutorizador = usuarioComercioAutorizador;
		this.usuarioComercioAnulacion = usuarioComercioAnulacion;
		this.idComercio = idComercio;
		this.comercioUUID = comercioUUID;
		this.comercioHash = comercioHash;
		this.comercioNumeroDocumento = comercioNumeroDocumento;
		this.comercioNombre = comercioNombre;
		this.comercioTipoOperacion = comercioTipoOperacion;
		this.usuarioNombre = usuarioNombre;
		this.usuarioNumeroDocumento = usuarioNumeroDocumento;
		this.idSucursal = idSucursal;
		this.sucursalUUID = sucursalUUID;
		this.sucursalHash = sucursalHash;
		this.sucursalNombre = sucursalNombre;
		this.idTerminal = idTerminal;
		this.terminalUUID = terminalUUID;
		this.terminalHash = terminalHash;
		this.terminalCodigo = terminalCodigo;
		this.terminalNombre = terminalNombre;
	}
	
	public ComercioLoginResponse(Long usuarioComercioId, String usuarioComercioUUID, String usuarioComercioLogon, 
			String usuarioComercioAutorizador, String usuarioComercioAnulacion, 
			Long idComercio, String comercioUUID, String comercioHash, String comercioNumeroDocumento, String comercioNombre, 
			String comercioTipoOperacion, String usuarioNombre, String usuarioNumeroDocumento) {
		
		this.usuarioComercioId = usuarioComercioId;
		this.usuarioComercioUUID = usuarioComercioUUID;
		this.usuarioComercioLogon = usuarioComercioLogon;
		this.usuarioComercioAutorizador = usuarioComercioAutorizador;
		this.usuarioComercioAnulacion = usuarioComercioAnulacion;
		this.idComercio = idComercio;
		this.comercioUUID = comercioUUID;
		this.comercioHash = comercioHash;
		this.comercioNumeroDocumento = comercioNumeroDocumento;
		this.comercioNombre = comercioNombre;
		this.comercioTipoOperacion = comercioTipoOperacion;
		this.usuarioNombre = usuarioNombre;
		this.usuarioNumeroDocumento = usuarioNumeroDocumento;
	}
	
	public Long getUsuarioComercioId() {
		return usuarioComercioId;
	}

	public String getUsuarioComercioUUID() {
		return usuarioComercioUUID;
	}

	public String getUsuarioComercioLogon() {
		return usuarioComercioLogon;
	}

	public String getUsuarioComercioAutorizador() {
		return usuarioComercioAutorizador;
	}

	public String getUsuarioComercioAnulacion() {
		return usuarioComercioAnulacion;
	}

	public String getComercioUUID() {
		return comercioUUID;
	}

	public String getComercioHash() {
		return comercioHash;
	}

	public String getComercioNumeroDocumento() {
		return comercioNumeroDocumento;
	}

	public String getComercioNombre() {
		return comercioNombre;
	}

	public String getComercioTipoOperacion() {
		return comercioTipoOperacion;
	}

	public String getUsuarioNombre() {
		return usuarioNombre;
	}

	public String getUsuarioNumeroDocumento() {
		return usuarioNumeroDocumento;
	}

	public Long getIdSucursal() {
		return idSucursal;
	}

	public String getSucursalUUID() {
		return sucursalUUID;
	}

	public String getSucursalHash() {
		return sucursalHash;
	}

	public String getSucursalNombre() {
		return sucursalNombre;
	}

	public Long getIdTerminal() {
		return idTerminal;
	}

	public String getTerminalUUID() {
		return terminalUUID;
	}

	public String getTerminalHash() {
		return terminalHash;
	}

	public String getTerminalCodigo() {
		return terminalCodigo;
	}

	public String getTerminalNombre() {
		return terminalNombre;
	}

	public String getToken() {
		return token;
	}

	public void setUsuarioComercioId(Long usuarioComercioId) {
		this.usuarioComercioId = usuarioComercioId;
	}

	public void setUsuarioComercioUUID(String usuarioComercioUUID) {
		this.usuarioComercioUUID = usuarioComercioUUID;
	}

	public void setUsuarioComercioLogon(String usuarioComercioLogon) {
		this.usuarioComercioLogon = usuarioComercioLogon;
	}

	public void setUsuarioComercioAutorizador(String usuarioComercioAutorizador) {
		this.usuarioComercioAutorizador = usuarioComercioAutorizador;
	}

	public void setUsuarioComercioAnulacion(String usuarioComercioAnulacion) {
		this.usuarioComercioAnulacion = usuarioComercioAnulacion;
	}

	public void setComercioUUID(String comercioUUID) {
		this.comercioUUID = comercioUUID;
	}

	public void setComercioHash(String comercioHash) {
		this.comercioHash = comercioHash;
	}

	public void setComercioNumeroDocumento(String comercioNumeroDocumento) {
		this.comercioNumeroDocumento = comercioNumeroDocumento;
	}

	public void setComercioNombre(String comercioNombre) {
		this.comercioNombre = comercioNombre;
	}

	public void setComercioTipoOperacion(String comercioTipoOperacion) {
		this.comercioTipoOperacion = comercioTipoOperacion;
	}

	public void setUsuarioNombre(String usuarioNombre) {
		this.usuarioNombre = usuarioNombre;
	}

	public void setUsuarioNumeroDocumento(String usuarioNumeroDocumento) {
		this.usuarioNumeroDocumento = usuarioNumeroDocumento;
	}

	public void setIdSucursal(Long idSucursal) {
		this.idSucursal = idSucursal;
	}

	public void setSucursalUUID(String sucursalUUID) {
		this.sucursalUUID = sucursalUUID;
	}

	public void setSucursalHash(String sucursalHash) {
		this.sucursalHash = sucursalHash;
	}

	public void setSucursalNombre(String sucursalNombre) {
		this.sucursalNombre = sucursalNombre;
	}

	public void setIdTerminal(Long idTerminal) {
		this.idTerminal = idTerminal;
	}

	public void setTerminalUUID(String terminalUUID) {
		this.terminalUUID = terminalUUID;
	}

	public void setTerminalHash(String terminalHash) {
		this.terminalHash = terminalHash;
	}

	public void setTerminalCodigo(String terminalCodigo) {
		this.terminalCodigo = terminalCodigo;
	}

	public void setTerminalNombre(String terminalNombre) {
		this.terminalNombre = terminalNombre;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getNombreMostrar() {
		if (this.comercioTipoOperacion != null) {
			
			if (this.comercioTipoOperacion.equals(Parametros.COMERCIO_AUTORIZA_FRONTWEB)) {
				
				return (this.sucursalNombre + " - " + this.terminalCodigo);
				
			}else {
				
				return (this.comercioNombre);
			}
		}
		
		return "";
	}
	
	public String getIsCambioClave() {
		return isCambioClave;
	}

	public void setIsCambioClave(String isCambioClave) {
		this.isCambioClave = isCambioClave;
	}

	public String getLogon() {
		return logon;
	}
	
	public void setLogon(String logon) {
		this.logon = logon;
	}
	
}
