package com.pexto.monedero.apidto.core;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionRequestCompraRetiroManualV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("idComercio")
	private Long idComercio;
	
	@JsonProperty("idTerminal")
	private Long idTerminal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("valor")
	private double valor;
	
	@JsonProperty("otp")
	private String otp;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("fechaTransaccion")
	private Date fechaTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("idUsuarioComercio")
	private Long idUsuarioComercio;
	
	@JsonProperty("authorization")
	private String authorization;
	
	@JsonProperty("paramRequest")
	private ParamRequestV paramRequest;
	
	public TransaccionRequestCompraRetiroManualV() {
		this.idComercio 		= null;
		this.idTerminal 		= null;
		this.numeroCuenta 		= null;
		this.valor 				= 0;
		this.otp 				= null;
		this.tipoTransaccion 	= null;
		this.fechaTransaccion	= new Date();
		this.numeroAutorizacion	= "0";
		this.idUsuarioComercio 	= 0L;
		this.authorization		= "";
		this.paramRequest		= null;
	}
	
	public Long getIdComercio() {
		return idComercio;
	}

	public Long getIdTerminal() {
		return idTerminal;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public double getValor() {
		return valor;
	}

	public String getOtp() {
		return otp;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public Long getIdUsuarioComercio() {
		return idUsuarioComercio;
	}

	public String getAuthorization() {
		return authorization;
	}

	public ParamRequestV getParamRequest() {
		return paramRequest;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public void setIdTerminal(Long idTerminal) {
		this.idTerminal = idTerminal;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public void setIdUsuarioComercio(Long idUsuarioComercio) {
		this.idUsuarioComercio = idUsuarioComercio;
	}

	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}

	public void setParamRequest(ParamRequestV paramRequest) {
		this.paramRequest = paramRequest;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		
		if ((this.idComercio == null) || (String.valueOf(this.idComercio).equals(""))) {
			throw new Exception("IdComercio esta vacio o errado!");
		}
		
		if ((this.idTerminal == null) || (String.valueOf(this.idTerminal).equals(""))) {
			throw new Exception("IdTerminal esta vacio o errado!");
		}
		
		if ((this.numeroCuenta == null) || (this.numeroCuenta.equals(""))) {
			throw new Exception("Numero de cuenta esta vacio o errado!");
		}
		
		if ((this.otp == null) || (this.otp.equals(""))) {
			throw new Exception("OTP esta vacio o errado!");
		}
		
		if ((this.tipoTransaccion == null) || (this.tipoTransaccion.equals(""))) {
			throw new Exception("TipoTransaccion esta vacio o errado!");
		}
		
		//validate_tipoTransaccionCompraRetiro
    	if (!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_COMPRA) &&
    			!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_RETIRO) &&
    			!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_COMPRA) &&
    			!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_RETIRO)) {
    		
    		throw new Exception("Ingrese un tipo de transaccion correcto!");
    	}
    	
		if ((this.idUsuarioComercio == null) || (String.valueOf(this.idUsuarioComercio).equals(""))) {
			throw new Exception("IdUsuarioComercio esta vacio o errado!");
		}
		
		//validate_IdUsuarioComercioPositivo
    	if (this.idUsuarioComercio <= 0) {
    		throw new Exception("IdUsuarioComercio no valido!");
    	}
    	
		if ((this.fechaTransaccion == null)) {
			throw new Exception("FechaTransaccion esta vacio o errado!");
		}
				
    	if (String.valueOf(this.valor).equals("")) {
    		throw new Exception("Valor vacio o errado!");
    	}
    	
    	//validate_ValorPositivo
    	if (this.valor <= 0) {
    		throw new Exception("Ingrese un valor correcto!");
    	}
    	
		return true;
	}
	
}
