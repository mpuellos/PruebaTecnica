package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class SaldoClienteV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long IdEmisor;
	private Long IdBolsillo;	
	private String nombre_emisor;
	private String nombre_bolsillo;
	private String codigo_bolsillo;
	private String tipo_bolsillo;
	private double valor;
	
	public SaldoClienteV() {
		
	}
	
	public SaldoClienteV(Long idEmisor, String nombre_emisor, double valor) {
		this.IdEmisor = idEmisor;
		this.valor = valor;
		this.nombre_emisor = nombre_emisor;
	}
	
	public SaldoClienteV(Long idEmisor, String nombre_emisor, Long IdBolsillo, double valor) {
		this.IdEmisor = idEmisor;
		this.IdBolsillo = IdBolsillo;
		this.valor = valor;
		this.nombre_emisor = nombre_emisor;
	}
	public SaldoClienteV(Long idEmisor, String nombre_emisor, Long IdBolsillo, double valor, String nombre_bolsillo, String codigo_bolsillo,String tipo_bolsillo) {
		this.IdEmisor = idEmisor;
		this.IdBolsillo = IdBolsillo;
		this.valor = valor;
		this.nombre_emisor = nombre_emisor;
		this.nombre_bolsillo = nombre_bolsillo;
		this.codigo_bolsillo = codigo_bolsillo;
		this.tipo_bolsillo = tipo_bolsillo;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.IdEmisor = idEmisor;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public void setNombre_emisor(String nombre_emisor) {
		this.nombre_emisor = nombre_emisor;
	}
	
	public Long getIdEmisor() {
		return IdEmisor;
	}
	
	public String getNombre_emisor() {
		return nombre_emisor;
	}
	
	public double getValor() {
		return valor;
	}

	public Long getIdBolsillo() {
		return IdBolsillo;
	}

	public void setIdBolsillo(Long idBolsillo) {
		IdBolsillo = idBolsillo;
	}

	public String getNombre_bolsillo() {
		return nombre_bolsillo;
	}

	public void setNombre_bolsillo(String nombre_bolsillo) {
		this.nombre_bolsillo = nombre_bolsillo;
	}

	public String getCodigo_bolsillo() {
		return codigo_bolsillo;
	}

	public void setCodigo_bolsillo(String codigo_bolsillo) {
		this.codigo_bolsillo = codigo_bolsillo;
	}

	public String getTipo_bolsillo() {
		return tipo_bolsillo;
	}

	public void setTipo_bolsillo(String tipo_bolsillo) {
		this.tipo_bolsillo = tipo_bolsillo;
	}
	
	
}
