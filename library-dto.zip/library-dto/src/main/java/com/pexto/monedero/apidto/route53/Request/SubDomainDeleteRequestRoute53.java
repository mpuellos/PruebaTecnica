package com.pexto.monedero.apidto.route53.Request;

public class SubDomainDeleteRequestRoute53 {
    private String subdomain;
    private String type;

    public String getSubdomain() {
        return subdomain;
    }

    public void setSubdomain(String subdomain) {
        this.subdomain = subdomain;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
