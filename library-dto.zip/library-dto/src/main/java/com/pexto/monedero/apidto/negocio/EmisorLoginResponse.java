package com.pexto.monedero.apidto.negocio;

import java.util.Date;
import java.util.List;

import com.pexto.monedero.apidto.respuesta.EstadoRespuesta;
import lombok.*;

@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class EmisorLoginResponse extends EstadoRespuesta {
	
	private static final long serialVersionUID = 1L;	
	
	//DataFrom-UsuarioEmisor
	private Long idUsuarioEmisor;
	private String uuidUsuarioEmisor;
	private String tipoUsuario;
	private String token;
	private String logon;
	private String password;
	private Date vigencia;
	private Date fecha;
	private String estadoUsuarioEmisor;
	private String isCambioClave;
	private Date fechaCambioClave;
	//DataFrom-Persona
	private String nombres;
	private String apellidos;
	private String numeroDocumento;
	private String correo;
	private String telefono;
	//DataFrom-Emisor
	private Long idEmisor;
	private String tipoEmisor;
	private String descripcionTipoEmisor;
	private String tipoOperacion;
	private String descripcionTipoOperacion;
	private String nombreEntidad;
	private String documentoEntidad;
	//DataFrom-Profile
	private String profileId;
	private String nameProfile;
	private List<String> rolePermissions;
	private List<String> rolePermissionsAPI;
}