package com.pexto.monedero.apidto.interfaces;

public interface ITransaccionRequestValidator {
	
	public abstract boolean validateProperties() throws Exception;

}
