package com.pexto.monedero.apidto.negocio;

import com.pexto.monedero.apidto.core.TransaccionResponseV;
import com.pexto.monedero.apidto.respuesta.EstadoRespuesta;

public class ComercioAutorizadorResponseV extends EstadoRespuesta {
	
	private static final long serialVersionUID = 1L;
	
	private TransaccionResponseV transaccion;
	
	public ComercioAutorizadorResponseV() {
		super();
	}
	
	public ComercioAutorizadorResponseV(String estado, String mensaje) {
		super(estado, mensaje);
		this.transaccion = null;
	}
	
	public ComercioAutorizadorResponseV(String estado, String mensaje, TransaccionResponseV transaccion) {
		super(estado, mensaje);
		this.transaccion = transaccion;
	}
	
	public TransaccionResponseV getTransaccion() {
		return transaccion;
	}
	
	public void setTransaccion(TransaccionResponseV transaccion) {
		this.transaccion = transaccion;
	}
	
}
