package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class SaldoClienteEmisorCuentaBV implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idEmisor;
	private Long idCuentaBolsillo;
	private double valor;

	public SaldoClienteEmisorCuentaBV() {

	}

	public SaldoClienteEmisorCuentaBV(Long idEmisor, Long idCuentaBolsillo, double valor) {
		this.idEmisor = idEmisor;
		this.idCuentaBolsillo = idCuentaBolsillo;
		this.valor = valor;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public Long getIdCuentaBolsillo() {
		return idCuentaBolsillo;
	}

	public double getValor() {
		return valor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public void setIdCuentaBolsillo(Long idCuentaBolsillo) {
		this.idCuentaBolsillo = idCuentaBolsillo;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

}
