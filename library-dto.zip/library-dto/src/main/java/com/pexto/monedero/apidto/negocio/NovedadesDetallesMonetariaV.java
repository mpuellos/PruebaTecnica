package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;

public class NovedadesDetallesMonetariaV implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long Id;
	private String fechaEnvio;
	private String nit;
	private String consecutivo;
	private String tipoDocumento;
	private String documentoNumero;	
	private String numeroCuenta;
	private String tipoNovedad;
	private String codigoProducto;
	private double valor;	
	private String documento;
	private String estado;
	private String codigoCausal;
	private Long idTransaccion;
	private String causalTransaccion;
	private String autorizacionTransaccion;
	private Long idReversoTransaccion;
	private String estadoTransaccion;
	private String nombreArchivo;
	
	public NovedadesDetallesMonetariaV() {
		
	}
	
	public NovedadesDetallesMonetariaV(Long id, String fechaEnvio, String nit, String consecutivo, String tipoDocumento,
			String documentoNumero, String numeroCuenta, String tipoNovedad, String codigoProducto, double valor,
			String documento, String estado, String codigoCausal, Long idTransaccion, String causalTransaccion,
			String autorizacionTransaccion, Long idReversoTransaccion, String estadoTransaccion) {
		super();
		Id = id;
		this.fechaEnvio = fechaEnvio;
		this.nit = nit;
		this.consecutivo = consecutivo;
		this.tipoDocumento = tipoDocumento;
		this.documentoNumero = documentoNumero;
		this.numeroCuenta = numeroCuenta;
		this.tipoNovedad = tipoNovedad;
		this.codigoProducto = codigoProducto;
		this.valor = valor;
		this.documento = documento;
		this.estado = estado;
		this.codigoCausal = codigoCausal;
		this.idTransaccion = idTransaccion;
		this.causalTransaccion = causalTransaccion;
		this.autorizacionTransaccion = autorizacionTransaccion;
		this.idReversoTransaccion = idReversoTransaccion;
		this.estadoTransaccion = estadoTransaccion;
	}
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getFechaEnvio() {
		return fechaEnvio;
	}
	public void setFechaEnvio(String fechaEnvio) {
		this.fechaEnvio = fechaEnvio;
	}
	public String getNit() {
		return nit;
	}
	public void setNit(String nit) {
		this.nit = nit;
	}
	public String getConsecutivo() {
		return consecutivo;
	}
	public void setConsecutivo(String consecutivo) {
		this.consecutivo = consecutivo;
	}
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	public String getDocumentoNumero() {
		return documentoNumero;
	}
	public void setDocumentoNumero(String documentoNumero) {
		this.documentoNumero = documentoNumero;
	}
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	public String getTipoNovedad() {
		return tipoNovedad;
	}
	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}
	public String getCodigoProducto() {
		return codigoProducto;
	}
	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(Double valor) {
		this.valor = valor;
	}
	public String getDocumento() {
		return documento;
	}
	public void setDocumento(String documento) {
		this.documento = documento;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public Long getIdTransaccion() {
		return idTransaccion;
	}
	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}
	public String getCausalTransaccion() {
		return causalTransaccion;
	}
	public void setCausalTransaccion(String causalTransaccion) {
		this.causalTransaccion = causalTransaccion;
	}
	public String getAutorizacionTransaccion() {
		return autorizacionTransaccion;
	}
	public void setAutorizacionTransaccion(String autorizacionTransaccion) {
		this.autorizacionTransaccion = autorizacionTransaccion;
	}
	public Long getIdReversoTransaccion() {
		return idReversoTransaccion;
	}
	public void setIdReversoTransaccion(Long idReversoTransaccion) {
		this.idReversoTransaccion = idReversoTransaccion;
	}
	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}
	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}

	public String getCodigoCausal() {
		return codigoCausal;
	}

	public void setCodigoCausal(String codigoCausal) {
		this.codigoCausal = codigoCausal;
	}

	public void setValor(double valor) {
		this.valor = valor;
	}

	public String getNombreArchivo() {
		return nombreArchivo;
	}

	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}
	
	
	
}
