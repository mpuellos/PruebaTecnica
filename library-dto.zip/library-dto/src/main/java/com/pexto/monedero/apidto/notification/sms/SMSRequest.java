package com.pexto.monedero.apidto.notification.sms;

import java.io.Serializable;

public class SMSRequest implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String numero;
	private String mensaje;
	
	public String getNumero() {
		return numero;
	}
	
	public void setNumero(String numero) {
		this.numero = numero;
	}
	
	public String getMensaje() {
		return mensaje;
	}
	
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
}