package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;
import java.util.Date;

public class CierreArchivoResponseV implements Serializable {
	
	private static final long serialVersionUID = 1L;

	private Long id;
	private String uuid;
	private Date fecha;
	private String estado;
	private Date fechaCierre;
	private Date fechaCorte;
	private Date fechaInicio;
	private Date fechaFin;
	private String nombreArchivo;
	private String urlArchivo;
	private String descripcion;
	private Long idEmisor;
	private Long idTipoArchivo;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Date getFechaCierre() {
		return fechaCierre;
	}
	
	public void setFechaCierre(Date fechaCierre) {
		this.fechaCierre = fechaCierre;
	}
	
	public Date getFechaCorte() {
		return fechaCorte;
	}
	
	public void setFechaCorte(Date fechaCorte) {
		this.fechaCorte = fechaCorte;
	}
	
	public Date getFechaInicio() {
		return fechaInicio;
	}
	
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	
	public Date getFechaFin() {
		return fechaFin;
	}
	
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	
	public String getNombreArchivo() {
		return nombreArchivo;
	}
	
	public void setNombreArchivo(String nombreArchivo) {
		this.nombreArchivo = nombreArchivo;
	}
	
	public String getUrlArchivo() {
		return urlArchivo;
	}
	
	public void setUrlArchivo(String urlArchivo) {
		this.urlArchivo = urlArchivo;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public Long getIdTipoArchivo() {
		return idTipoArchivo;
	}
	
	public void setIdTipoArchivo(Long idTipoArchivo) {
		this.idTipoArchivo = idTipoArchivo;
	}
	
}
