package com.pexto.monedero.apidto.comercio.apicomercio;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.core.ParamRequestV;
import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionRequestAutomaticoARedesV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("codigoUnicoComercio")
	private String codigoUnicoComercio;
	
	@JsonProperty("codigoTerminal")
	private String codigoTerminal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;
	
	@JsonProperty("valor")
	private double valor;
	
	@JsonProperty("otp")
	private String otp;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("fechaTransaccion")
	private Date fechaTransaccion;
	
	@JsonProperty("bin")
	private String binOperador;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("authorization")
	private String authorization;
	
	@JsonProperty("paramRequest")
	private ParamRequestV paramRequest;
	
	public TransaccionRequestAutomaticoARedesV() {
		this.codigoUnicoComercio	= null;
		this.codigoTerminal			= null;
		this.numeroCuenta 			= null;
		this.valor 					= 0;
		this.otp 					= null;
		this.tipoTransaccion 		= null;
		this.fechaTransaccion		= new Date();
		this.binOperador			= null;
		
		this.numeroAutorizacion		= "0";
		this.authorization			= "";
		this.paramRequest			= null;
	}
	
	public String getCodigoUnicoComercio() {
		return codigoUnicoComercio;
	}

	public String getCodigoTerminal() {
		return codigoTerminal;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public double getValor() {
		return valor;
	}

	public String getOtp() {
		return otp;
	}
	
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public String getAuthorization() {
		return authorization;
	}
	
	public ParamRequestV getParamRequest() {
		return paramRequest;
	}
	
	public void setCodigoUnicoComercio(String codigoUnicoComercio) {
		this.codigoUnicoComercio = codigoUnicoComercio;
	}

	public void setCodigoTerminal(String codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public void setOtp(String otp) {
		this.otp = otp;
	}
	
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}
	
	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}
	
	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}
	
	public void setParamRequest(ParamRequestV paramRequest) {
		this.paramRequest = paramRequest;
	}
	
	public String getBinOperador() {
		return binOperador;
	}

	public void setBinOperador(String binOperador) {
		this.binOperador = binOperador;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		//VALIDATION NULL
		
		if (this.codigoUnicoComercio == null || this.codigoUnicoComercio.equals("")) {
			throw new Exception("Codigo Unico del Comercio - null o vacio!");
		}
		
		if (this.codigoTerminal == null || this.codigoTerminal.equals("")) {
			throw new Exception("Codigo de la Terminal - null o vacio!");
		}
		
		if (this.numeroCuenta == null || this.numeroCuenta.equals("")) {
			throw new Exception("Numero de cuenta - null o vacio!");
		}
		
		if (this.otp == null || this.otp.equals("")) {
			throw new Exception("OTP - null o vacio!");
		}
		
		if (this.tipoTransaccion == null || this.tipoTransaccion.equals("")) {
			throw new Exception("TipoTransaccion - null o vacio!");
		}
		
		if (this.fechaTransaccion == null) {
			throw new Exception("FechaTransaccion - null o vacio!");
		}
		
		if (this.binOperador == null || this.binOperador.equals("")) {
			throw new Exception("Bin del Operador - null o vacio!");
		}
		
		if (String.valueOf(this.valor).equals("")) {
    		throw new Exception("Valor vacio!");
    	}
		
    	//VALIDATION DATA_VALUES
    	
    	//validate_ValorPositivo
    	if (this.valor <= 0) {
    		throw new Exception("Ingrese un valor correcto!");
    	}
    	
    	//validate_tipoTransaccionCompraRetiro
    	if (!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_COMPRA) &&
    			!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_RETIRO) &&
    			!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_COMPRA) &&
    			!this.tipoTransaccion.equals(Parametros.TRANSACCION_TIPO_REVERSION_RETIRO)) {
    		
    		throw new Exception("Ingrese un tipo de transaccion correcto!");
    	}
		
		return valid;
	}
	
}