package com.pexto.monedero.apidto.core;

import java.io.Serializable;
import java.util.Date;

import com.pexto.monedero.apidto.negocio.ComercioAutorizadorIntegradorV;
import com.pexto.monedero.apidto.negocio.ComercioAutorizadorV;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionResponseV implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idTransaccion;
	private String uuidTransaccion;
	private String hashTransaccion;
	private Date fechaTransaccion;
	private String numeroAutorizacion;
	private double valorTransaccion;
	private String codigoCausal;
	private String descripcionCausal;
	private String idReversoTransaccion;
	private String tipoTransaccion;
	private String estadoTransaccion;
	private String descripcionEstadoTransaccion;
	private String numeroCuenta;
	private Long idBolsillo;
	private String nombreBolsillo;
	private String codigoBolsilloNegocio;
	private String descripcionBolsillo;
	private ComercioAutorizadorV comercioAutorizador;
	private ComercioAutorizadorIntegradorV comercioAutorizadorIntegrador;

	public TransaccionResponseV() {
		this.idTransaccion = null;
		this.uuidTransaccion = null;
		this.hashTransaccion = null;
		this.fechaTransaccion = new Date();
		this.numeroAutorizacion = "";
		this.valorTransaccion = 0;
		this.codigoCausal = Parametros.TRANSACCION_CAUSAL_AUTORIZADA;
		this.descripcionCausal = Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.idReversoTransaccion = null;
		this.tipoTransaccion = null;
		this.estadoTransaccion = Parametros.TRANSACCION_ESTADO_NO_AUTORIZADA;
		this.descripcionEstadoTransaccion = Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.numeroCuenta = "";
		this.idBolsillo = null;
		this.nombreBolsillo = "";
		this.codigoBolsilloNegocio = "";
		this.descripcionBolsillo = "";
		this.comercioAutorizador = null;
		this.comercioAutorizadorIntegrador = null;
	}

	public Long getIdTransaccion() {
		return idTransaccion;
	}

	public String getUuidTransaccion() {
		return uuidTransaccion;
	}

	public String getHashTransaccion() {
		return hashTransaccion;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public double getValorTransaccion() {
		return valorTransaccion;
	}

	public String getCodigoCausal() {
		return codigoCausal;
	}

	public String getDescripcionCausal() {
		return descripcionCausal;
	}

	public String getIdReversoTransaccion() {
		return idReversoTransaccion;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}

	public String getDescripcionEstadoTransaccion() {
		return descripcionEstadoTransaccion;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public String getNombreBolsillo() {
		return nombreBolsillo;
	}

	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public void setUuidTransaccion(String uuidTransaccion) {
		this.uuidTransaccion = uuidTransaccion;
	}

	public void setHashTransaccion(String hashTransaccion) {
		this.hashTransaccion = hashTransaccion;
	}

	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public void setValorTransaccion(double valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}

	public void setCodigoCausal(String codigoCausal) {
		this.codigoCausal = codigoCausal;
	}

	public void setDescripcionCausal(String descripcionCausal) {
		this.descripcionCausal = descripcionCausal;
	}

	public void setIdReversoTransaccion(String idReversoTransaccion) {
		this.idReversoTransaccion = idReversoTransaccion;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}

	public void setDescripcionEstadoTransaccion(String descripcionEstadoTransaccion) {
		this.descripcionEstadoTransaccion = descripcionEstadoTransaccion;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public void setNombreBolsillo(String nombreBolsillo) {
		this.nombreBolsillo = nombreBolsillo;
	}

	public String getCodigoBolsilloNegocio() {
		return codigoBolsilloNegocio;
	}

	public void setCodigoBolsilloNegocio(String codigoBolsilloNegocio) {
		this.codigoBolsilloNegocio = codigoBolsilloNegocio;
	}

	public String getDescripcionBolsillo() {
		return descripcionBolsillo;
	}

	public void setDescripcionBolsillo(String descripcionBolsillo) {
		this.descripcionBolsillo = descripcionBolsillo;
	}

	public ComercioAutorizadorV getComercioAutorizador() {
		return comercioAutorizador;
	}

	public ComercioAutorizadorIntegradorV getComercioAutorizadorIntegrador() {
		return comercioAutorizadorIntegrador;
	}

	public void setComercioAutorizador(ComercioAutorizadorV comercioAutorizador) {
		this.comercioAutorizador = comercioAutorizador;
	}

	public void setComercioAutorizadorIntegrador(ComercioAutorizadorIntegradorV comercioAutorizadorIntegrador) {
		this.comercioAutorizadorIntegrador = comercioAutorizadorIntegrador;
	}

}
