package com.pexto.monedero.apidto.notification.email;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Email implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	String from;
    String to;
    Collection<String> collectionTo;
    String subject;
    String content;
    String template;
    Map<String, String> model;
    List<DataAttachment> attachmentsInS3;
    
    @Getter
    @Setter
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class DataAttachment {

        String nameBucket;
        String pathFile;
        String nameFileToDownload;

    }

    public boolean validateProperties() throws Exception {
        boolean valid = true;

        //VALIDATION NULL
        if ((this.to == null || this.to.equals("")) && (this.collectionTo == null || this.collectionTo.size() == 0)) {
            throw new Exception("Error en el campo [Para] is null!");
        }

        if (this.subject == null || this.subject.equals("")) {
            throw new Exception("Error en el campo [Asunto] is null!");
        }

        return valid;
    }
	
}