package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

public class AlertaResponseV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String id;
	private String tipoAlerta;
	private String alerta;
	private String fecha;
	private String estado;
	private String nombreEmisor;
	private String numeroCuenta;
	private String estadoTransaccion;
	private String tipoTransaccion;
	private double tope;
	private double topeIndividual;
	private double valorTransaccion;
	private Long idTransaccion;
	private Long idEmisor;
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	public String getTipoAlerta() {
		return tipoAlerta;
	}
	
	public void setTipoAlerta(String tipoAlerta) {
		this.tipoAlerta = tipoAlerta;
	}
	
	public String getAlerta() {
		return alerta;
	}
	
	public void setAlerta(String alerta) {
		this.alerta = alerta;
	}
	
	public String getFecha() {
		return fecha;
	}
	
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public String getNombreEmisor() {
		return nombreEmisor;
	}
	
	public void setNombreEmisor(String nombreEmisor) {
		this.nombreEmisor = nombreEmisor;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}
	
	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}
	
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	public double getTope() {
		return tope;
	}
	
	public void setTope(double tope) {
		this.tope = tope;
	}
	
	public double getTopeIndividual() {
		return topeIndividual;
	}
	
	public void setTopeIndividual(double topeIndividual) {
		this.topeIndividual = topeIndividual;
	}
	
	public double getValorTransaccion() {
		return valorTransaccion;
	}
	
	public void setValorTransaccion(double valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}
	
	public Long getIdTransaccion() {
		return idTransaccion;
	}
	
	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
}
