package com.pexto.monedero.apidto.push;

import java.io.Serializable;

public class RequestPostNotificacionPushVO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String to;
	private NotificationVO notification;
	private DataVO data;
	
	public String getTo() {
		return to;
	}
	
	public void setTo(String to) {
		this.to = to;
	}
	
	public NotificationVO getNotification() {
		return notification;
	}
	
	public void setNotification(NotificationVO notification) {
		this.notification = notification;
	}
	
	public DataVO getData() {
		return data;
	}
	
	public void setData(DataVO data) {
		this.data = data;
	}
}