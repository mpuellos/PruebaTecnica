package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.pexto.monedero.apidto.interfaces.ITransaccionRequestValidator;

public class NovedadArchivoCargueRequestV implements Serializable, ITransaccionRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	private String nombreArchivoNovedad;
	private String tipoArchivoNovedad;
	private String codigoSeguridad;
	private String nitEmisor;
	private String ipLocal;
	private String ipOrigen;
	private String userAgent;
	private String idEmisor;
	private String idUsuarioEmisor;
	
	public String getNombreArchivoNovedad() {
		return nombreArchivoNovedad;
	}
	
	public String getTipoArchivoNovedad() {
		return tipoArchivoNovedad;
	}
	
	public String getIdEmisor() {
		return idEmisor;
	}

	public String getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}
	
	public String getNitEmisor() {
		return nitEmisor;
	}
	
	public String getIpLocal() {
		return ipLocal;
	}
	
	public String getIpOrigen() {
		return ipOrigen;
	}
	
	public String getUserAgent() {
		return userAgent;
	}
	
	public void setNombreArchivoNovedad(String nombreArchivoNovedad) {
		this.nombreArchivoNovedad = nombreArchivoNovedad;
	}
	
	public void setTipoArchivoNovedad(String tipoArchivoNovedad) {
		this.tipoArchivoNovedad = tipoArchivoNovedad;
	}
	
	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public void setIdUsuarioEmisor(String idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}
	
	public void setNitEmisor(String nitEmisor) {
		this.nitEmisor = nitEmisor;
	}
	
	public void setIpLocal(String ipLocal) {
		this.ipLocal = ipLocal;
	}
	
	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}
	
	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}
	
	public String getCodigoSeguridad() {
		return codigoSeguridad;
	}

	public void setCodigoSeguridad(String codigoSeguridad) {
		this.codigoSeguridad = codigoSeguridad;
	}

	@Override
	public boolean validateProperties() throws Exception {
		//VALIDATION_NULL
		
		if (this.nombreArchivoNovedad == null) {
			throw new Exception("Nombre de archivo Novedad - null!");
		}
		
		if (this.tipoArchivoNovedad == null) {
			throw new Exception("Tipo de archivo Novedad - null!");
		}
		
		if (this.nitEmisor == null) {
			throw new Exception("Nit Emisor - null!");
		}
		
		if (this.ipLocal == null) {
			throw new Exception("Direccion IP Local - null!");
		}
		
		if (this.ipOrigen == null) {
			throw new Exception("Direccicion IP Origen - null!");
		}
		
		if (this.userAgent == null) {
			throw new Exception("User Agent - null!");
		}
		
		if (this.codigoSeguridad == null) {
			throw new Exception("Codigo de Seguridad - null!");
		}
		
		if (this.idEmisor == null) {
			throw new Exception("Id Emisor - null!");
		}
		
		if (this.idUsuarioEmisor == null) {
			throw new Exception("Id UsuarioEmisor - null!");
		}
				
		//VALIDATION_EMPTY
		
    	if (this.nombreArchivoNovedad.equals("")) {
    		throw new Exception("Nombre de archivo Novedad vacio!");
		}
    	
    	if (this.tipoArchivoNovedad.equals("")) {
    		throw new Exception("Tipo de archivo Novedad vacio!");
    	}
    	
    	if (this.nitEmisor.equals("")) {
    		throw new Exception("Nit Emisor vacio!");
    	}
    	
    	if (this.ipLocal.equals("")) {
    		throw new Exception("IP Local vacio!");
    	}
    	
    	if (this.ipOrigen.equals("")) {
    		throw new Exception("IP Origen vacio!");
    	}
    	
    	if (this.userAgent.equals("")) {
    		throw new Exception("User Agent vacio!");
    	}
    	
    	if (this.codigoSeguridad.equals("")) {
    		throw new Exception("Codigo de Seguridad vacio!");
    	}
    	
    	if (this.idEmisor.equals("")) {
    		throw new Exception("Id Emisor vacio!");
		}
    	
    	if (this.idUsuarioEmisor.equals("")) {
    		throw new Exception("Id UsuarioEmisor vacio!");
    	}
    	
    	//VALIDATION_DATA_VALUES
    	
    	//validate_tipoArchivoNovedad
    	if (!this.tipoArchivoNovedad.equals("ENTRADA_INSCRIPCION_CUENTA") &&
    			!this.tipoArchivoNovedad.equals("ENTRADA_ABONO_CUENTA") && 
    			!this.tipoArchivoNovedad.equals("ENTRADA_CARGO_CUENTA")) {
    		
    		throw new Exception("Ingrese un tipo de archivo de novedad correcto!");
    	}
		
		return true;
	}
	
	public boolean validatePropertiesNovedadAutomatica() throws Exception {
		//VALIDATION_NULL
		
		if (this.nombreArchivoNovedad == null) {
			throw new Exception("Nombre de archivo Novedad - null!");
		}
		
		if (this.tipoArchivoNovedad == null) {
			throw new Exception("Tipo de archivo Novedad - null!");
		}
		
		if (this.nitEmisor == null) {
			throw new Exception("Nit Emisor - null!");
		}
		
		if (this.ipLocal == null) {
			throw new Exception("Direccion IP Local - null!");
		}
		
		if (this.ipOrigen == null) {
			throw new Exception("Direccicion IP Origen - null!");
		}
		
		if (this.userAgent == null) {
			throw new Exception("User Agent - null!");
		}
		
		if (this.idEmisor == null) {
			throw new Exception("Id Emisor - null!");
		}
		
		if (this.idUsuarioEmisor == null) {
			throw new Exception("Id UsuarioEmisor - null!");
		}
				
		//VALIDATION_EMPTY
		
    	if (this.nombreArchivoNovedad.equals("")) {
    		throw new Exception("Nombre de archivo Novedad vacio!");
		}
    	
    	if (this.tipoArchivoNovedad.equals("")) {
    		throw new Exception("Tipo de archivo Novedad vacio!");
    	}
    	
    	if (this.nitEmisor.equals("")) {
    		throw new Exception("Nit Emisor vacio!");
    	}
    	
    	if (this.ipLocal.equals("")) {
    		throw new Exception("IP Local vacio!");
    	}
    	
    	if (this.ipOrigen.equals("")) {
    		throw new Exception("IP Origen vacio!");
    	}
    	
    	if (this.userAgent.equals("")) {
    		throw new Exception("User Agent vacio!");
    	}
    	
    	if (this.idEmisor.equals("")) {
    		throw new Exception("Id Emisor vacio!");
		}
    	
    	if (this.idUsuarioEmisor.equals("")) {
    		throw new Exception("Id UsuarioEmisor vacio!");
    	}
    	
    	//VALIDATION_DATA_VALUES
    	
    	//validate_tipoArchivoNovedad
    	if (!this.tipoArchivoNovedad.equals("ENTRADA_INSCRIPCION_CUENTA") &&
    			!this.tipoArchivoNovedad.equals("ENTRADA_ABONO_CUENTA") && 
    			!this.tipoArchivoNovedad.equals("ENTRADA_CARGO_CUENTA")) {
    		
    		throw new Exception("Ingrese un tipo de archivo de novedad correcto!");
    	}
		
		return true;
	}
	
}
