package com.pexto.monedero.apidto.comercio.apicomercio;

import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.utils.Parametros;

public class TransaccionResponseAutomaticoAEstandarV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("transaccion")
	private String transaccion;
	
	@JsonProperty("fechaTransaccion")
	private String fechaTransaccion;
	
	@JsonProperty("numeroAutorizacion")
	private String numeroAutorizacion;
	
	@JsonProperty("valorTransaccion")
	private double valorTransaccion;
	
	@JsonProperty("tipoTransaccion")
	private String tipoTransaccion;
	
	@JsonProperty("estadoTransaccion")
	private String estadoTransaccion;
	
	@JsonProperty("descripcionEstado")
	private String descripcionEstado;
	
	@JsonProperty("causalTransaccion")
	private String causalTransaccion;
	
	@JsonProperty("descripcionCausal")
	private String descripcionCausal;
	
	@JsonProperty("numeroCuenta")
	private String numeroCuenta;

	public TransaccionResponseAutomaticoAEstandarV() {
		this.transaccion 					= "";
		this.fechaTransaccion 				= Parametros.getFechaString(new Date());
		this.numeroAutorizacion 			= "";
		this.valorTransaccion 				= 0.0;
		this.tipoTransaccion 				= "";
		this.estadoTransaccion 				= Parametros.TRANSACCION_ESTADO_NO_AUTORIZADA;
		this.descripcionEstado 				= Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.causalTransaccion 				= Parametros.TRANSACCION_CAUSAL_NO_AUTORIZADA;
		this.descripcionCausal 				= Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.numeroCuenta 					= "";
	}
	
	public TransaccionResponseAutomaticoAEstandarV(String causalTransaccion, String descripcionCausal) {
		this.transaccion 					= "";
		this.fechaTransaccion 				= Parametros.getFechaString(new Date());
		this.numeroAutorizacion 			= "";
		this.valorTransaccion 				= 0.0;
		this.tipoTransaccion 				= "";
		this.estadoTransaccion 				= Parametros.TRANSACCION_ESTADO_NO_AUTORIZADA;
		this.descripcionEstado 				= Parametros.TRANSACCION_DESCRIPCION_NO_AUTORIZADA;
		this.causalTransaccion 				= causalTransaccion;
		this.descripcionCausal 				= descripcionCausal;
		this.numeroCuenta 					= "";
	}
	
	public TransaccionResponseAutomaticoAEstandarV(String transaccion, Date fechaTransaccion, String numeroAutorizacion, double valorTransaccion, String tipoTransaccion,
			String estadoTransaccion, String descripcionEstado, String causalTransaccion, String descripcionCausal, String numeroCuenta) {
		
		this.transaccion 					= transaccion;
		this.fechaTransaccion 				= Parametros.getFechaString(fechaTransaccion);
		this.numeroAutorizacion 			= numeroAutorizacion;
		this.valorTransaccion 				= valorTransaccion;
		this.tipoTransaccion 				= tipoTransaccion;
		this.estadoTransaccion 				= estadoTransaccion;
		this.descripcionEstado 				= descripcionEstado;
		this.causalTransaccion 				= causalTransaccion;
		this.descripcionCausal 				= descripcionCausal;
		this.numeroCuenta 					= numeroCuenta;
	}
	
	public String getTransaccion() {
		return transaccion;
	}

	public String getFechaTransaccion() {
		return fechaTransaccion;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public double getValorTransaccion() {
		return valorTransaccion;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}

	public String getDescripcionEstado() {
		return descripcionEstado;
	}

	public String getCausalTransaccion() {
		return causalTransaccion;
	}

	public String getDescripcionCausal() {
		return descripcionCausal;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setTransaccion(String transaccion) {
		this.transaccion = transaccion;
	}

	public void setFechaTransaccion(String fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public void setValorTransaccion(double valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}

	public void setDescripcionEstado(String descripcionEstado) {
		this.descripcionEstado = descripcionEstado;
	}

	public void setCausalTransaccion(String causalTransaccion) {
		this.causalTransaccion = causalTransaccion;
	}

	public void setDescripcionCausal(String descripcionCausal) {
		this.descripcionCausal = descripcionCausal;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TransaccionResponseAutomaticoAEstandarV [transaccion=");
		builder.append(transaccion);
		builder.append(", fechaTransaccion=");
		builder.append(fechaTransaccion);
		builder.append(", numeroAutorizacion=");
		builder.append(numeroAutorizacion);
		builder.append(", valorTransaccion=");
		builder.append(valorTransaccion);
		builder.append(", tipoTransaccion=");
		builder.append(tipoTransaccion);
		builder.append(", estadoTransaccion=");
		builder.append(estadoTransaccion);
		builder.append(", descripcionEstado=");
		builder.append(descripcionEstado);
		builder.append(", causalTransaccion=");
		builder.append(causalTransaccion);
		builder.append(", descripcionCausal=");
		builder.append(descripcionCausal);
		builder.append(", numeroCuenta=");
		builder.append(numeroCuenta);
		builder.append("]");
		return builder.toString();
	}
	
}
