package com.pexto.monedero.apidto.respuesta;

public class StatusResponse<T> {

	private boolean status;
	private String message;
	private T data;
	
	public boolean isStatus() {
		return status;
	}
	
	public void setStatus(boolean status) {
		this.status = status;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String mensaje) {
		this.message = mensaje;
	}
	
	public T getData() {
		return data;
	}
	
	public void setData(T data) {
		this.data = data;
	}
	
	
}
