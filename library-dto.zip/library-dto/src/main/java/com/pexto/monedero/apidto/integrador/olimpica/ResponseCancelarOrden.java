package com.pexto.monedero.apidto.integrador.olimpica;

import java.io.Serializable;

public class ResponseCancelarOrden implements Serializable{
	private static final long serialVersionUID = 1L;
	private boolean estado;
	
	public boolean isEstado() {
		return estado;
	}
	public void setEstado(boolean estado) {
		this.estado = estado;
	}
	
	
}
