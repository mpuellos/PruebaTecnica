package com.pexto.monedero.apidto.transactions;

import java.time.LocalDateTime;
import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionDTO {

	Long id;
	Long accountId;
	String accountNumer;
	String transactionType;
	String transactionTypeDesc;
	Double value;
	Double previosAmount;
	Double newAmount;
	Date dateTime;
	String status;
	String descriptionStatus;
	String cause;
	String descriptionCause;
	String hash;
	String uuid;
	String authorization;
	LocalDateTime processDate;
	String originIp;
}
