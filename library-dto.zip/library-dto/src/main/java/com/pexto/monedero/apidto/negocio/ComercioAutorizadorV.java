package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class ComercioAutorizadorV implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private Long id;
	private Date fecha;
	private String ipLocal;
	private String ipOrigen;
	private String userAgent;
	private String authorization;
	private String tipoAutorizacion;
	private String tipoOperacion;
	private String tipoTransaccion;
	private String autorizacion;
	private double valor;
	private String nombreComercio;
	private String nombreSucursal;
	private String nombreTerminal;
	private String numeroCuentaHash;
	private String numeroCuenta;
	private String numeroOtpHash;
	private String numeroOtp;
	private String transaccionHash;
	private Long idCuenta;
	private Long idComercio;
	private Long idSucursal;
	private Long idTerminal;
	private Long idUsuarioComercio;
	private Long idTransaccion;
	private Long idOtp;
	private String hash;
	
	public Long getId() {
		return id;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public String getIpLocal() {
		return ipLocal;
	}
	
	public String getIpOrigen() {
		return ipOrigen;
	}
	
	public String getUserAgent() {
		return userAgent;
	}
	
	public String getAuthorization() {
		return authorization;
	}
	
	public String getTipoAutorizacion() {
		return tipoAutorizacion;
	}
	
	public String getTipoOperacion() {
		return tipoOperacion;
	}
	
	public String getTipoTransaccion() {
		return tipoTransaccion;
	}
	
	public String getAutorizacion() {
		return autorizacion;
	}
	
	public double getValor() {
		return valor;
	}
	
	public String getNombreComercio() {
		return nombreComercio;
	}
	
	public String getNombreSucursal() {
		return nombreSucursal;
	}
	
	public String getNombreTerminal() {
		return nombreTerminal;
	}
	
	public String getNumeroCuentaHash() {
		return numeroCuentaHash;
	}
	
	public String getNumeroCuenta() {
		return numeroCuenta;
	}
	
	public String getNumeroOtpHash() {
		return numeroOtpHash;
	}
	
	public String getNumeroOtp() {
		return numeroOtp;
	}
	
	public String getTransaccionHash() {
		return transaccionHash;
	}
	
	public Long getIdCuenta() {
		return idCuenta;
	}
	
	public Long getIdComercio() {
		return idComercio;
	}
	
	public Long getIdSucursal() {
		return idSucursal;
	}
	
	public Long getIdTerminal() {
		return idTerminal;
	}
	
	public Long getIdUsuarioComercio() {
		return idUsuarioComercio;
	}
	
	public Long getIdTransaccion() {
		return idTransaccion;
	}
	
	public Long getIdOtp() {
		return idOtp;
	}
	
	public String getHash() {
		return hash;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public void setIpLocal(String ipLocal) {
		this.ipLocal = ipLocal;
	}
	
	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}
	
	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}
	
	public void setAuthorization(String authorization) {
		this.authorization = authorization;
	}
	
	public void setTipoAutorizacion(String tipoAutorizacion) {
		this.tipoAutorizacion = tipoAutorizacion;
	}
	
	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}
	
	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}
	
	public void setAutorizacion(String autorizacion) {
		this.autorizacion = autorizacion;
	}
	
	public void setValor(double valor) {
		this.valor = valor;
	}
	
	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}
	
	public void setNombreSucursal(String nombreSucursal) {
		this.nombreSucursal = nombreSucursal;
	}
	
	public void setNombreTerminal(String nombreTerminal) {
		this.nombreTerminal = nombreTerminal;
	}
	
	public void setNumeroCuentaHash(String numeroCuentaHash) {
		this.numeroCuentaHash = numeroCuentaHash;
	}
	
	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}
	
	public void setNumeroOtpHash(String numeroOtpHash) {
		this.numeroOtpHash = numeroOtpHash;
	}
	
	public void setNumeroOtp(String numeroOtp) {
		this.numeroOtp = numeroOtp;
	}
	
	public void setTransaccionHash(String transaccionHash) {
		this.transaccionHash = transaccionHash;
	}
	
	public void setIdCuenta(Long idCuenta) {
		this.idCuenta = idCuenta;
	}
	
	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}
	
	public void setIdSucursal(Long idSucursal) {
		this.idSucursal = idSucursal;
	}
	
	public void setIdTerminal(Long idTerminal) {
		this.idTerminal = idTerminal;
	}
	
	public void setIdUsuarioComercio(Long idUsuarioComercio) {
		this.idUsuarioComercio = idUsuarioComercio;
	}
	
	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}
	
	public void setIdOtp(Long idOtp) {
		this.idOtp = idOtp;
	}
	
	public void setHash(String hash) {
		this.hash = hash;
	}
	
}
