package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class AlertaRequestV implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("idEmisor")
	private Long idEmisor;
	
	@JsonProperty("fechaInicio")
	private String fechaInicio;
	
	@JsonProperty("fechaFinal")
	private String fechaFinal;
	
	public Long getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public String getFechaInicio() {
		return fechaInicio;
	}
	
	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	
	public String getFechaFinal() {
		return fechaFinal;
	}
	
	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	
	@Override
	public boolean validateProperties() throws Exception {
		
		if ((this.idEmisor == null) || (String.valueOf(this.idEmisor).trim().equals(""))) {
			throw new Exception ("Campo Id Emisor is null or empty!");
		}
		
		if ((this.fechaInicio == null) || (this.fechaInicio.trim().equals(""))) {
			throw new Exception ("Campo Fecha de Inicio is null or empty!");
		}
		
		if ((this.fechaFinal == null) || (this.fechaFinal.trim().equals(""))) {
			throw new Exception ("Campo Fecha Final is null or empty!");
		}
		
		if (this.idEmisor <= 0) {
			throw new Exception ("Ingrese un valor correcto para el campo Id Emisor!");
		}
		
		return true;
	}
}
