package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

public class NovedadRegistroConsultaRequestV implements Serializable {

	private static final long serialVersionUID = 1L;

	private String idEmisor;
	private String tipoDocumento;
	private String numeroDocumento;
	private String numeroCelular;
	private String nombres;
	private String apellidos;

	public String getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public boolean validateProperties() throws Exception {
		boolean valid = true;

		if ((tipoDocumento == null) || (tipoDocumento.trim().length() == 0)) {
			throw new Exception("El campo Tipo Documento esta vacio o errado!");
		}

		if ((numeroDocumento == null) || (numeroDocumento.trim().length() == 0)) {
			throw new Exception("El campo Numero Documento esta vacio o errado!");
		}

		return valid;
	}

	public boolean validatePropertiesNumeroCelular() throws Exception {
		boolean valid = true;

		if ((numeroCelular == null) || (numeroCelular.trim().length() == 0)) {
			throw new Exception("El campo Numero de celular esta vacio o errado!");
		}

		return valid;
	}

	public boolean validatePropertiesNombresYApellidos() throws Exception {
		boolean valid = true;

		if ((nombres == null) || (nombres.trim().length() == 0)) {
			throw new Exception("El campo Nombres esta vacio o errado!");
		}

		if ((apellidos == null) || (apellidos.trim().length() == 0)) {
			throw new Exception("El campo Apellidos esta vacio o errado!");
		}

		return valid;
	}
}