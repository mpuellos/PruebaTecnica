package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class PersonaV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String numeroDocumento;
	private String nombres;
	private String apellidos;
	private String correo;
	private String telefono;
	private String cargo;
	private Date fecha;
	private String estado;
	private Long idTipoDocumento;
	
	public PersonaV() {
		
	}

	public Long getId() {
		return id;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public String getCorreo() {
		return correo;
	}

	public String getTelefono() {
		return telefono;
	}

	public String getCargo() {
		return cargo;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getEstado() {
		return estado;
	}

	public Long getIdTipoDocumento() {
		return idTipoDocumento;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public void setIdTipoDocumento(Long idTipoDocumento) {
		this.idTipoDocumento = idTipoDocumento;
	}
		
}
