package com.pexto.monedero.apidto.admin.request;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class RequestPutComercio implements Serializable, IRequestValidator {
	
	private static final long serialVersionUID = 1L;

	@JsonProperty("entidadId")
	private Long entidadId;
	
	@JsonProperty("entidadTipoDocumento")
	private String entidadTipoDocumento;
	
	@JsonProperty("entidadNumeroDocumento")
	private String entidadNumeroDocumento;
	
	@JsonProperty("entidadNombre")
	private String entidadNombre;
	
	@JsonProperty("entidadDireccion")
	private String entidadDireccion;
	
	@JsonProperty("entidadTelefono1")
	private String entidadTelefono1;
	
	@JsonProperty("entidadTelefono2")
	private String entidadTelefono2;
	
	@JsonProperty("entidadCorreo")
	private String entidadCorreo;
	
	@JsonProperty("entidadRNumeroDocumento")
	private String entidadRNumeroDocumento;
	
	@JsonProperty("entidadRNombre")
	private String entidadRNombre;
	
	@JsonProperty("entidadRCorreo")
	private String entidadRCorreo;
	
	@JsonProperty("entidadCNombre")
	private String entidadCNombre;
	
	@JsonProperty("entidadCTelefono")
	private String entidadCTelefono;
	
	@JsonProperty("entidadCCorreo")
	private String entidadCCorreo;
	
	@JsonProperty("comercioId")
	private Long comercioId;
	
	@JsonProperty("comercioNombreCorto")
	private String comercioNombreCorto;
	
	@JsonProperty("comercioVigencia")
	private String comercioVigencia;
	
	@JsonProperty("comercioAutorizacionApp")
	private String comercioAutorizacionApp;
	
	@JsonProperty("comercioTokenApp")
	private String comercioTokenApp;
	
	@JsonProperty("comercioNumeroCuenta")
	private String comercioNumeroCuenta;
	
	@JsonProperty("comercioTipoCompensacion")
	private String comercioTipoCompensacion;
	
	@JsonProperty("comercioTipoComercio")
	private String comercioTipoComercio;
	
	@JsonProperty("comercioTipoOperacion")
	private String comercioTipoOperacion;
	
	@JsonProperty("idUsuarioAdmin")
	private Long idUsuarioAdmin;

	public String getEntidadTipoDocumento() {
		return entidadTipoDocumento;
	}

	public void setEntidadTipoDocumento(String entidadTipoDocumento) {
		this.entidadTipoDocumento = entidadTipoDocumento;
	}

	public String getEntidadNumeroDocumento() {
		return entidadNumeroDocumento;
	}

	public void setEntidadNumeroDocumento(String entidadNumeroDocumento) {
		this.entidadNumeroDocumento = entidadNumeroDocumento;
	}

	public String getEntidadNombre() {
		return entidadNombre;
	}

	public void setEntidadNombre(String entidadNombre) {
		this.entidadNombre = entidadNombre;
	}

	public String getEntidadDireccion() {
		return entidadDireccion;
	}

	public void setEntidadDireccion(String entidadDireccion) {
		this.entidadDireccion = entidadDireccion;
	}

	public String getEntidadTelefono1() {
		return entidadTelefono1;
	}

	public void setEntidadTelefono1(String entidadTelefono1) {
		this.entidadTelefono1 = entidadTelefono1;
	}

	public String getEntidadTelefono2() {
		return entidadTelefono2;
	}

	public void setEntidadTelefono2(String entidadTelefono2) {
		this.entidadTelefono2 = entidadTelefono2;
	}

	public String getEntidadCorreo() {
		return entidadCorreo;
	}

	public void setEntidadCorreo(String entidadCorreo) {
		this.entidadCorreo = entidadCorreo;
	}

	public String getEntidadRNumeroDocumento() {
		return entidadRNumeroDocumento;
	}

	public void setEntidadRNumeroDocumento(String entidadRNumeroDocumento) {
		this.entidadRNumeroDocumento = entidadRNumeroDocumento;
	}

	public String getEntidadRNombre() {
		return entidadRNombre;
	}

	public void setEntidadRNombre(String entidadRNombre) {
		this.entidadRNombre = entidadRNombre;
	}

	public String getEntidadRCorreo() {
		return entidadRCorreo;
	}

	public void setEntidadRCorreo(String entidadRCorreo) {
		this.entidadRCorreo = entidadRCorreo;
	}

	public String getEntidadCNombre() {
		return entidadCNombre;
	}

	public void setEntidadCNombre(String entidadCNombre) {
		this.entidadCNombre = entidadCNombre;
	}

	public String getEntidadCTelefono() {
		return entidadCTelefono;
	}

	public void setEntidadCTelefono(String entidadCTelefono) {
		this.entidadCTelefono = entidadCTelefono;
	}

	public String getEntidadCCorreo() {
		return entidadCCorreo;
	}

	public void setEntidadCCorreo(String entidadCCorreo) {
		this.entidadCCorreo = entidadCCorreo;
	}

	public String getComercioNombreCorto() {
		return comercioNombreCorto;
	}

	public void setComercioNombreCorto(String comercioNombreCorto) {
		this.comercioNombreCorto = comercioNombreCorto;
	}

	public String getComercioVigencia() {
		return comercioVigencia;
	}

	public void setComercioVigencia(String comercioVigencia) {
		this.comercioVigencia = comercioVigencia;
	}

	public String getComercioAutorizacionApp() {
		return comercioAutorizacionApp;
	}

	public void setComercioAutorizacionApp(String comercioAutorizacionApp) {
		this.comercioAutorizacionApp = comercioAutorizacionApp;
	}

	public String getComercioTokenApp() {
		return comercioTokenApp;
	}

	public void setComercioTokenApp(String comercioTokenApp) {
		this.comercioTokenApp = comercioTokenApp;
	}

	public String getComercioTipoCompensacion() {
		return comercioTipoCompensacion;
	}

	public void setComercioTipoCompensacion(String comercioTipoCompensacion) {
		this.comercioTipoCompensacion = comercioTipoCompensacion;
	}

	public String getComercioTipoComercio() {
		return comercioTipoComercio;
	}

	public void setComercioTipoComercio(String comercioTipoComercio) {
		this.comercioTipoComercio = comercioTipoComercio;
	}

	public Long getIdUsuarioAdmin() {
		return idUsuarioAdmin;
	}

	public void setIdUsuarioAdmin(Long idUsuarioAdmin) {
		this.idUsuarioAdmin = idUsuarioAdmin;
	}
	
	public String getComercioTipoOperacion() {
		return comercioTipoOperacion;
	}

	public void setComercioTipoOperacion(String comercioTipoOperacion) {
		this.comercioTipoOperacion = comercioTipoOperacion;
	}
	
	public String getComercioNumeroCuenta() {
		return comercioNumeroCuenta;
	}

	public void setComercioNumeroCuenta(String comercioNumeroCuenta) {
		this.comercioNumeroCuenta = comercioNumeroCuenta;
	}
	
	public Long getEntidadId() {
		return entidadId;
	}

	public void setEntidadId(Long entidadId) {
		this.entidadId = entidadId;
	}

	public Long getComercioId() {
		return comercioId;
	}

	public void setComercioId(Long comercioId) {
		this.comercioId = comercioId;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((this.entidadId == null)) {
			throw new Exception ("Entidad Id esta vacio o errado!");
		}
		
		if ((this.entidadTipoDocumento == null) || (this.entidadTipoDocumento.trim().equals(""))) {
			throw new Exception ("Tipo de documento esta vacio o errado!");
		}
		
		if ((this.entidadNumeroDocumento == null) || (this.entidadNumeroDocumento.trim().equals(""))) {
			throw new Exception ("Número de documento esta vacio o errado!");
		}
		
		if ((this.entidadNombre == null) || (this.entidadNombre.trim().equals(""))) {
			throw new Exception ("Razon Social esta vacio o errado!");
		}
		
		if ((this.entidadDireccion == null) || (this.entidadDireccion.trim().equals(""))) {
			throw new Exception ("Dirección esta vacio o errado!");
		}
		
		if ((this.entidadTelefono1 == null) || (this.entidadTelefono1.trim().equals(""))) {
			throw new Exception ("Número de Telefono esta vacio o errado!");
		}
		
		if ((this.entidadCorreo == null) || (this.entidadCorreo.trim().equals(""))) {
			throw new Exception ("Correo electronico esta vacio o errado!");
		}
		
		if ((this.entidadRNumeroDocumento == null) || (this.entidadRNumeroDocumento.trim().equals(""))) {
			throw new Exception ("Rep Legal Número de documento del esta vacio o errado!");
		}
		
		if ((this.entidadRNombre == null) || (this.entidadRNombre.trim().equals(""))) {
			throw new Exception ("Rep Legal Nombre esta vacio o errado!");
		}
		
		if ((this.entidadRCorreo == null) || (this.entidadNombre.trim().equals(""))) {
			throw new Exception ("Rep Legal Correo esta vacio o errado!");
		}
		
		if ((this.comercioId == null)) {
			throw new Exception ("Comercio Id esta vacio o errado!");
		}
		
		if ((this.comercioNombreCorto == null) || (this.comercioNombreCorto.trim().equals(""))) {
			throw new Exception ("Nombre de comercio esta vacio o errado!");
		}
		
		if ((this.comercioTipoComercio == null) || (this.comercioTipoComercio.trim().equals(""))) {
			throw new Exception ("Tipo de comercio esta vacio o errado!");
		}
		
		if ((this.comercioTipoCompensacion == null) || (this.comercioTipoCompensacion.trim().equals(""))) {
			throw new Exception ("Tipo de compensación esta vacio o errado!");
		}
		
		if ((this.comercioTipoOperacion == null) || (this.comercioTipoOperacion.trim().equals(""))) {
			throw new Exception ("Tipo de compensación esta vacio o errado!");
		}
		
		return valid;
	}	
}