package com.pexto.monedero.apidto.comercio.pcomercio;

import java.io.Serializable;
import java.util.Date;

public class ComercioOTPV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String numeroOTP;
	private Date vigencia;
	private String ipLocal;
	private String ipOrigen;
	private String userAgent;
	private Date fecha;
	private String estado;
	private Date fechaProceso;
	private Long idUsuarioComercio;
	
	public ComercioOTPV() {
		
	}

	public Long getId() {
		return id;
	}

	public String getNumeroOTP() {
		return numeroOTP;
	}

	public Date getVigencia() {
		return vigencia;
	}

	public String getIpLocal() {
		return ipLocal;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getEstado() {
		return estado;
	}

	public Date getFechaProceso() {
		return fechaProceso;
	}

	public Long getIdUsuarioComercio() {
		return idUsuarioComercio;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public void setNumeroOTP(String numeroOTP) {
		this.numeroOTP = numeroOTP;
	}

	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}

	public void setIpLocal(String ipLocal) {
		this.ipLocal = ipLocal;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}

	public void setIdUsuarioComercio(Long idUsuarioComercio) {
		this.idUsuarioComercio = idUsuarioComercio;
	}
	
}
