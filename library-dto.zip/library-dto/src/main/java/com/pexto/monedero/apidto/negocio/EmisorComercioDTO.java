package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class EmisorComercioDTO implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String uuid;
	private Date fecha;
	private ComercioDTO comercio;
	private Long idTipoPeriodicidad;
	private Long idUsuarioAdmin;
	
	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public ComercioDTO getComercio() {
		return comercio;
	}
	
	public void setComercio(ComercioDTO comercio) {
		this.comercio = comercio;
	}
	
	public Long getIdTipoPeriodicidad() {
		return idTipoPeriodicidad;
	}
	
	public void setIdTipoPeriodicidad(Long idTipoPeriodicidad) {
		this.idTipoPeriodicidad = idTipoPeriodicidad;
	}
	
	public Long getIdUsuarioAdmin() {
		return idUsuarioAdmin;
	}
	
	public void setIdUsuarioAdmin(Long idUsuarioAdmin) {
		this.idUsuarioAdmin = idUsuarioAdmin;
	}
	
}