package com.pexto.monedero.apidto.sacresponse;

import java.util.Date;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Value;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SacClient {
  Long clientId;
  String name;
  String lastName;
  String document;
  String documentType;
  String documentTypeDescription;
  String cellphone;
  String email;
  String address;
  
  Long accountId;
  String status;
  Integer logginAttemps;
  Date lockedUntil;

  Date lastLoggin;// ????????
  String workPlaceBankCode;
  Boolean reexpedicion; //ta26 novedades unitarias 
}
