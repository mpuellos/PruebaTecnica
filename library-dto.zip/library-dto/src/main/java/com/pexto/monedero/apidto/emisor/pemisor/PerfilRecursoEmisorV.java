package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;
import java.sql.Date;

public class PerfilRecursoEmisorV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String descripcion;
	private Date fecha;
	private String estado;
	private PerfilEmisorV perfilEmisor;
	private RecursoEmisorV recursoEmisor;
	private Long usuarioAdmin;
	
	public Long getId() {
		return id;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public String getDescripcion() {
		return descripcion;
	}
	
	public Date getFecha() {
		return fecha;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public PerfilEmisorV getPerfilEmisor() {
		return perfilEmisor;
	}
	
	public RecursoEmisorV getRecursoEmisor() {
		return recursoEmisor;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public void setPerfilEmisor(PerfilEmisorV perfilEmisor) {
		this.perfilEmisor = perfilEmisor;
	}
	
	public void setRecursoEmisor(RecursoEmisorV recursoEmisor) {
		this.recursoEmisor = recursoEmisor;
	}

	public Long getUsuarioAdmin() {
		return usuarioAdmin;
	}

	public void setUsuarioAdmin(Long usuarioAdmin) {
		this.usuarioAdmin = usuarioAdmin;
	}
	
}
