package com.pexto.monedero.apidto.negocio;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

public class TransaccionNovedadDetalleEmpresas implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "tipoDocumentoBeneficiario cannot be null")
    private String tipoDocumentoBeneficiario;

    @NotNull(message = "nitBeneficiario cannot be null")
    private String nitBeneficiario;

    @NotNull(message = "nombreBeneficiario cannot be null")
    private String nombreBeneficiario;

    @NotNull(message = "tipoTransaccion cannot be null")
    private String tipoTransaccion;

    @NotNull(message = "codigoBanco cannot be null")
    private String codigoBanco;

    @NotNull(message = "numeroCuentaBeneficiario cannot be null")
    private String numeroCuentaBeneficiario;

    @NotNull(message = "email cannot be null")
    private String email;

    @NotNull(message = "documentoAutorizado cannot be null")
    private String documentoAutorizado;

    @NotNull(message = "referencia cannot be null")
    private String referencia;

    @NotNull(message = "oficinaEntrega cannot be null")
    private String oficinaEntrega;

    @NotNull(message = "valorTransaccion cannot be null")
    private String valorTransaccion;

    @NotNull(message = "fechaAplicacion cannot be null")
    private String fechaAplicacion;


    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(TransaccionNovedadDetalleEmpresas.class + " [tipoDocumentoBeneficiario=");
        builder.append(tipoDocumentoBeneficiario + ", nitBeneficiario=");
        builder.append(nitBeneficiario + ", nombreBeneficiario=");
        builder.append(nombreBeneficiario + ", tipoTransaccion=");
        builder.append(tipoTransaccion + ", codigoBanco=");
        builder.append(codigoBanco + ", numeroCuentaBeneficiario=");
        builder.append(numeroCuentaBeneficiario + ", email=");
        builder.append(email + ", documentoAutorizado=");
        builder.append(documentoAutorizado + ", referencia=");
        builder.append(referencia + ", oficinaEntrega=");
        builder.append(oficinaEntrega + ", valorTransaccion=");
        builder.append(valorTransaccion + ", fechaAplicacion=");
        builder.append(fechaAplicacion);
        builder.append("]");

        return builder.toString();
    }


    public String getTipoDocumentoBeneficiario() {
      return tipoDocumentoBeneficiario;
    }


    public void setTipoDocumentoBeneficiario(String tipoDocumentoBeneficiario) {
      this.tipoDocumentoBeneficiario = tipoDocumentoBeneficiario;
    }


    public String getNitBeneficiario() {
      return nitBeneficiario;
    }


    public void setNitBeneficiario(String nitBeneficiario) {
      this.nitBeneficiario = nitBeneficiario;
    }


    public String getNombreBeneficiario() {
      return nombreBeneficiario;
    }


    public void setNombreBeneficiario(String nombreBeneficiario) {
      this.nombreBeneficiario = nombreBeneficiario;
    }


    public String getTipoTransaccion() {
      return tipoTransaccion;
    }


    public void setTipoTransaccion(String tipoTransaccion) {
      this.tipoTransaccion = tipoTransaccion;
    }


    public String getCodigoBanco() {
      return codigoBanco;
    }


    public void setCodigoBanco(String codigoBanco) {
      this.codigoBanco = codigoBanco;
    }


    public String getNumeroCuentaBeneficiario() {
      return numeroCuentaBeneficiario;
    }


    public void setNumeroCuentaBeneficiario(String numeroCuentaBeneficiario) {
      this.numeroCuentaBeneficiario = numeroCuentaBeneficiario;
    }


    public String getEmail() {
      return email;
    }


    public void setEmail(String email) {
      this.email = email;
    }


    public String getDocumentoAutorizado() {
      return documentoAutorizado;
    }


    public void setDocumentoAutorizado(String documentoAutorizado) {
      this.documentoAutorizado = documentoAutorizado;
    }


    public String getReferencia() {
      return referencia;
    }


    public void setReferencia(String referencia) {
      this.referencia = referencia;
    }


    public String getOficinaEntrega() {
      return oficinaEntrega;
    }


    public void setOficinaEntrega(String oficinaEntrega) {
      this.oficinaEntrega = oficinaEntrega;
    }


    public String getValorTransaccion() {
      return valorTransaccion;
    }


    public void setValorTransaccion(String valorTransaccion) {
      this.valorTransaccion = valorTransaccion;
    }


    public String getFechaAplicacion() {
      return fechaAplicacion;
    }


    public void setFechaAplicacion(String fechaAplicacion) {
      this.fechaAplicacion = fechaAplicacion;
    }
    
}
