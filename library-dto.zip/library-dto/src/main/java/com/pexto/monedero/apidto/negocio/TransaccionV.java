package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class TransaccionV implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idTransaccion;
	private String uuidTransaccion;
	private String descripcionBolsillo;
	private String numeroDocumento;
	private String nombreEntidad;
	private String codigoUnicoComercio;
	private String nombreComercio;
	private String codigoSucursal;
	private String nombreSucursal;
	private String direccionSucursal;
	private String telefonoSucursal;
	private String codigoTerminal;
	private String nombreTerminal;
	private Date fechaTransaccion;
	private String numeroAutorizacion;
	private double valorTransaccion;
	private double valorEmisor;
	private String tipoTransaccion;
	private String estadoTransaccion;
	private String emisorNombreCorto;

	private String codigoCausal;
	private Long idTransaccionReverso;
	private String descripcionTransaccion;
	private String codigoProducto;

	// Datos Adicionales para generar archivo de Movimientos
	private String nit;
	private String fecha;
	private String hora;
	private String numeroCuenta;
	private String codigoTransaccion;
	// valorTransaccion
	private double valorComision;
	// numeroAutorizacion
	private String codigoComercio;// Id tabla sucursal
	private Long idComercio;
	private Long idTerminal;
	// codigoTerminal
	// estadoTransaccion
	// codigoCausal: Solo dejar los ultimos 2 digitos
	// codigoProducto

	private String clienteTipoDocumento;
	private String clienteNumeroDocumento;
	private String clienteNombreCompleto;

	public TransaccionV() {
	}

	public TransaccionV(String nit, Date fechaTransaccional, String numeroCuenta, String codigoTransaccion,
			double valorTransaccion, double valorComision, String numeroAutorizacion, Long idComercio, Long idTerminal,
			String estadoTransaccion, String codigoCausal, String codigoProducto, String codigoUnicoComercio,
			String codigoTerminal, String emisorNombreCorto) {

		Calendar calendario = Calendar.getInstance();
		calendario.setTime(fechaTransaccional);

		String dia = String.valueOf(calendario.get(Calendar.DATE));
		String mes = String.valueOf(calendario.get(Calendar.MONTH) + 1);
		String ano = String.valueOf(calendario.get(Calendar.YEAR));
		String hora = String.valueOf(calendario.get(Calendar.HOUR_OF_DAY));
		String minuto = String.valueOf(calendario.get(Calendar.MINUTE));
		String segundo = String.valueOf(calendario.get(Calendar.SECOND));

		mes = (mes.length() == 1) ? "0" + mes : mes;
		dia = (dia.length() == 1) ? "0" + dia : dia;
		hora = (hora.length() == 1) ? "0" + hora : hora;
		minuto = (minuto.length() == 1) ? "0" + minuto : minuto;
		segundo = (segundo.length() == 1) ? "0" + segundo : segundo;

		this.nit = nit;
		this.fecha = ano + mes + dia;
		this.hora = hora + ":" + minuto + ":" + segundo;
		this.numeroCuenta = numeroCuenta;
		this.codigoTransaccion = codigoTransaccion;
		this.valorTransaccion = valorTransaccion;
		this.valorComision = valorComision;
		this.numeroAutorizacion = numeroAutorizacion;
		this.estadoTransaccion = estadoTransaccion;
		this.codigoCausal = codigoCausal;
		this.codigoProducto = codigoProducto;

		this.idComercio = idComercio;
		this.codigoUnicoComercio = codigoUnicoComercio;
		this.idTerminal = idTerminal;
		this.codigoTerminal = codigoTerminal;
		this.emisorNombreCorto = emisorNombreCorto;
	}

	public TransaccionV(Long idTransaccion, String uuidTransaccion, Date fechaTransaccional, String numeroAutorizacion,
			double valorTransaccion, double valorEmisor, String codigoCausal, Long idTransaccionReverso,
			String tipoTransaccion, String descripcionTransaccion, String estadoTransaccion, String codigoProducto) {

		this.idTransaccion = idTransaccion;
		this.uuidTransaccion = uuidTransaccion;
		this.fechaTransaccion = fechaTransaccional;
		this.numeroAutorizacion = numeroAutorizacion;
		this.valorTransaccion = valorTransaccion;
		this.codigoCausal = codigoCausal;
		this.idTransaccionReverso = idTransaccionReverso;
		this.tipoTransaccion = tipoTransaccion;
		this.descripcionTransaccion = descripcionTransaccion;
		this.estadoTransaccion = estadoTransaccion;
		this.codigoProducto = codigoProducto;
		this.valorEmisor = valorEmisor;
	}

	public TransaccionV(Long idTransaccion, String uuidTransaccion, String numeroCuenta, String descripcionBolsillo,
			String numeroDocumento, String nombreEntidad, String nombreSucursal, String direccionSucursal,
			String telefonoSucursal, String codigoTerminal, Date fechaTransaccion, String numeroAutorizacion,
			double valorTransaccion, String tipoTransaccion, String estadoTransaccion) {

		this.idTransaccion = idTransaccion;
		this.uuidTransaccion = uuidTransaccion;
		this.numeroCuenta = numeroCuenta;
		this.descripcionBolsillo = descripcionBolsillo;
		this.numeroDocumento = numeroDocumento;
		this.nombreEntidad = nombreEntidad;
		this.nombreSucursal = nombreSucursal;
		this.direccionSucursal = direccionSucursal;
		this.telefonoSucursal = telefonoSucursal;
		this.codigoTerminal = codigoTerminal;
		this.fechaTransaccion = fechaTransaccion;
		this.numeroAutorizacion = numeroAutorizacion;
		this.valorTransaccion = valorTransaccion;
		this.tipoTransaccion = tipoTransaccion;
		this.estadoTransaccion = estadoTransaccion;
	}

	public TransaccionV(Long idTransaccion, String uuidTransaccion, String numeroCuenta, String descripcionBolsillo,
			String numeroDocumento, String nombreEntidad, String nombreSucursal, String direccionSucursal,
			String telefonoSucursal, String codigoTerminal, Date fechaTransaccion, String numeroAutorizacion,
			double valorTransaccion, String tipoTransaccion, String estadoTransaccion, String clienteTipoDocumento,
			String clienteNumeroDocumento, String clienteNombres, String clienteApellidos) {

		this.idTransaccion = idTransaccion;
		this.uuidTransaccion = uuidTransaccion;
		this.numeroCuenta = numeroCuenta;
		this.descripcionBolsillo = descripcionBolsillo;
		this.numeroDocumento = numeroDocumento;
		this.nombreEntidad = nombreEntidad;
		this.nombreSucursal = nombreSucursal;
		this.direccionSucursal = direccionSucursal;
		this.telefonoSucursal = telefonoSucursal;
		this.codigoTerminal = codigoTerminal;
		this.fechaTransaccion = fechaTransaccion;
		this.numeroAutorizacion = numeroAutorizacion;
		this.valorTransaccion = valorTransaccion;
		this.tipoTransaccion = tipoTransaccion;
		this.estadoTransaccion = estadoTransaccion;
		this.clienteTipoDocumento = clienteTipoDocumento;
		this.clienteNumeroDocumento = clienteNumeroDocumento;
		this.clienteNombreCompleto = clienteNombres + " " + clienteApellidos;
	}

	public Long getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getUuidTransaccion() {
		return uuidTransaccion;
	}

	public void setUuidTransaccion(String uuidTransaccion) {
		this.uuidTransaccion = uuidTransaccion;
	}

	public Date getFechaTransaccion() {
		return fechaTransaccion;
	}

	public void setFechaTransaccion(Date fechaTransaccion) {
		this.fechaTransaccion = fechaTransaccion;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombreEntidad() {
		return nombreEntidad;
	}

	public void setNombreEntidad(String nombreEntidad) {
		this.nombreEntidad = nombreEntidad;
	}

	public String getNombreSucursal() {
		return nombreSucursal;
	}

	public void setNombreSucursal(String nombreSucursal) {
		this.nombreSucursal = nombreSucursal;
	}

	public String getCodigoTerminal() {
		return codigoTerminal;
	}

	public void setCodigoTerminal(String codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}

	public String getNumeroAutorizacion() {
		return numeroAutorizacion;
	}

	public void setNumeroAutorizacion(String numeroAutorizacion) {
		this.numeroAutorizacion = numeroAutorizacion;
	}

	public String getTipoTransaccion() {
		return tipoTransaccion;
	}

	public void setTipoTransaccion(String tipoTransaccion) {
		this.tipoTransaccion = tipoTransaccion;
	}

	public String getEstadoTransaccion() {
		return estadoTransaccion;
	}

	public void setEstadoTransaccion(String estadoTransaccion) {
		this.estadoTransaccion = estadoTransaccion;
	}

	public double getValorTransaccion() {
		return valorTransaccion;
	}

	public void setValorTransaccion(double valorTransaccion) {
		this.valorTransaccion = valorTransaccion;
	}

	public String getDireccionSucursal() {
		return direccionSucursal;
	}

	public void setDireccionSucursal(String direccionSucursal) {
		this.direccionSucursal = direccionSucursal;
	}

	public String getTelefonoSucursal() {
		return telefonoSucursal;
	}

	public void setTelefonoSucursal(String telefonoSucursal) {
		this.telefonoSucursal = telefonoSucursal;
	}

	public String getCodigoCausal() {
		return codigoCausal;
	}

	public void setCodigoCausal(String codigoCausal) {
		this.codigoCausal = codigoCausal;
	}

	public Long getIdTransaccionReverso() {
		return idTransaccionReverso;
	}

	public void setIdTransaccionReverso(Long idTransaccionReverso) {
		this.idTransaccionReverso = idTransaccionReverso;
	}

	public String getDescripcionTransaccion() {
		return descripcionTransaccion;
	}

	public void setDescripcionTransaccion(String descripcionTransaccion) {
		this.descripcionTransaccion = descripcionTransaccion;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public String getNit() {
		return nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getCodigoTransaccion() {
		return codigoTransaccion;
	}

	public void setCodigoTransaccion(String codigoTransaccion) {
		this.codigoTransaccion = codigoTransaccion;
	}

	public double getValorComision() {
		return valorComision;
	}

	public void setValorComision(double valorComision) {
		this.valorComision = valorComision;
	}

	public String getCodigoComercio() {
		return codigoComercio;
	}

	public void setCodigoComercio(String codigoComercio) {
		this.codigoComercio = codigoComercio;
	}

	public Long getIdComercio() {
		return idComercio;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public Long getIdTerminal() {
		return idTerminal;
	}

	public void setIdTerminal(Long idTerminal) {
		this.idTerminal = idTerminal;
	}

	public String getDescripcionBolsillo() {
		return descripcionBolsillo;
	}

	public void setDescripcionBolsillo(String descripcionBolsillo) {
		this.descripcionBolsillo = descripcionBolsillo;
	}

	public double getValorEmisor() {
		return valorEmisor;
	}

	public void setValorEmisor(double valorEmisor) {
		this.valorEmisor = valorEmisor;
	}

	public String getCodigoUnicoComercio() {
		return codigoUnicoComercio;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}

	public String getCodigoSucursal() {
		return codigoSucursal;
	}

	public String getNombreTerminal() {
		return nombreTerminal;
	}

	public void setCodigoUnicoComercio(String codigoUnicoComercio) {
		this.codigoUnicoComercio = codigoUnicoComercio;
	}

	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public void setCodigoSucursal(String codigoSucursal) {
		this.codigoSucursal = codigoSucursal;
	}

	public void setNombreTerminal(String nombreTerminal) {
		this.nombreTerminal = nombreTerminal;
	}

	public String getEmisorNombreCorto() {
		return emisorNombreCorto;
	}

	public void setEmisorNombreCorto(String emisorNombreCorto) {
		this.emisorNombreCorto = emisorNombreCorto;
	}

	public String getClienteTipoDocumento() {
		return clienteTipoDocumento;
	}

	public void setClienteTipoDocumento(String clienteTipoDocumento) {
		this.clienteTipoDocumento = clienteTipoDocumento;
	}

	public String getClienteNumeroDocumento() {
		return clienteNumeroDocumento;
	}

	public void setClienteNumeroDocumento(String clienteNumeroDocumento) {
		this.clienteNumeroDocumento = clienteNumeroDocumento;
	}

	public String getClienteNombreCompleto() {
		return clienteNombreCompleto;
	}

	public void setClienteNombreCompleto(String clienteNombreCompleto) {
		this.clienteNombreCompleto = clienteNombreCompleto;
	}

}
