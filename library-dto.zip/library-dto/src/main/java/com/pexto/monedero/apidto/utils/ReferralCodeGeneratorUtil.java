package com.pexto.monedero.apidto.utils;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class ReferralCodeGeneratorUtil {

	private static List<String> blockedWordsList = Arrays.asList("ANAL", "CULO", "PENE");

	public static String generateReferralCode(String firstName, String surName) {

		firstName = firstName.replaceAll(" ", "").trim().toUpperCase();
		surName = surName.replaceAll(" ", "").trim().toUpperCase();

		String referralCodeFinal = "";
		int referralCodeLongitude = 4;
		int randomNumber = ThreadLocalRandom.current().nextInt(9999);
		String alias = "";
		String findCode = "";
		int n = 0;

		do {

			if (firstName.length() >= 4 + n) {
				alias = firstName.substring(n, 4 + n);
			} else if ((4 - firstName.length()) > 1) {
				alias = firstName + surName.substring(n, n + (4 - firstName.length()));
			} else {
				if (firstName.length() >= 4) {
					alias = firstName.substring(0, 3) + surName.charAt(n);
				} else {
					alias = firstName + surName.charAt(n);
				}
			}

			final String findingWord = alias;

			findCode = blockedWordsList.stream().filter(palabra -> findingWord.equals(palabra)).findAny().orElse(null);
			
			n++;

		} while (findCode != null);

		String inputString = String.valueOf(randomNumber);
		String outputString = inputString;
		int fill = referralCodeLongitude - (inputString.length());

		if (inputString.length() > referralCodeLongitude) {

			referralCodeFinal = alias + inputString.substring(0, referralCodeLongitude);

		} else if (fill == 0) {

			referralCodeFinal = alias + outputString;

		} else {

			for (int i = 1; i <= fill; i++) {
				outputString = "0" + outputString;
			}

			referralCodeFinal = alias + outputString;
		}

		return referralCodeFinal;

	}

}
