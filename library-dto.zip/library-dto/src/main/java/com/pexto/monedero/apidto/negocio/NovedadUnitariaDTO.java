package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class NovedadUnitariaDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String uuid;
	private Date fechaRegistro;
	private Date fechaProceso;
	private String ipOrigen;
	private String numeroDocumento;
	private String tipoDocumento;
	private String nombres;
	private String apellidos;
	private String correo;
	private Date fechaNacimiento;
	private Date fechaExpedicion;
	private String numeroCuenta;
	private String numeroCuentaHash;
	private String numeroCuentaEncode;
	private String numeroCuentaNuevo;
	private String numeroCuentaHashNuevo;
	private String numeroCuentaEncodeNuevo;
	private String codigoProducto;
	private String validacionBiometrica;
	private String validacionSeguridad;
	private Double valor;
	private Date fecha;
	private String estado;
	private String tipoNovedad;
	private String tipoOperacion;
	private Long idTipoNovedad;
	private Long idEmisor;
	private Long idBolsillo;
	private Long idCliente;
	private Long idCuenta;
	private Long idTransaccion;
	private String codigoCausalOrigen;
	private String codigoCausalProceso;
	private Long idUsuarioEmisor;
	private String hash;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public Date getFechaProceso() {
		return fechaProceso;
	}

	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNombres() {
		return nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getApellidos() {
		return apellidos;
	}

	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public Date getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(Date fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getNumeroCuenta() {
		return numeroCuenta;
	}

	public void setNumeroCuenta(String numeroCuenta) {
		this.numeroCuenta = numeroCuenta;
	}

	public String getNumeroCuentaHash() {
		return numeroCuentaHash;
	}

	public void setNumeroCuentaHash(String numeroCuentaHash) {
		this.numeroCuentaHash = numeroCuentaHash;
	}

	public String getNumeroCuentaEncode() {
		return numeroCuentaEncode;
	}

	public void setNumeroCuentaEncode(String numeroCuentaEncode) {
		this.numeroCuentaEncode = numeroCuentaEncode;
	}

	public String getNumeroCuentaNuevo() {
		return numeroCuentaNuevo;
	}

	public void setNumeroCuentaNuevo(String numeroCuentaNuevo) {
		this.numeroCuentaNuevo = numeroCuentaNuevo;
	}

	public String getNumeroCuentaHashNuevo() {
		return numeroCuentaHashNuevo;
	}

	public void setNumeroCuentaHashNuevo(String numeroCuentaHashNuevo) {
		this.numeroCuentaHashNuevo = numeroCuentaHashNuevo;
	}

	public String getNumeroCuentaEncodeNuevo() {
		return numeroCuentaEncodeNuevo;
	}

	public void setNumeroCuentaEncodeNuevo(String numeroCuentaEncodeNuevo) {
		this.numeroCuentaEncodeNuevo = numeroCuentaEncodeNuevo;
	}

	public String getCodigoProducto() {
		return codigoProducto;
	}

	public void setCodigoProducto(String codigoProducto) {
		this.codigoProducto = codigoProducto;
	}

	public String getValidacionBiometrica() {
		return validacionBiometrica;
	}

	public void setValidacionBiometrica(String validacionBiometrica) {
		this.validacionBiometrica = validacionBiometrica;
	}

	public String getValidacionSeguridad() {
		return validacionSeguridad;
	}

	public void setValidacionSeguridad(String validacionSeguridad) {
		this.validacionSeguridad = validacionSeguridad;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getTipoNovedad() {
		return tipoNovedad;
	}

	public void setTipoNovedad(String tipoNovedad) {
		this.tipoNovedad = tipoNovedad;
	}

	public String getTipoOperacion() {
		return tipoOperacion;
	}

	public void setTipoOperacion(String tipoOperacion) {
		this.tipoOperacion = tipoOperacion;
	}

	public Long getIdTipoNovedad() {
		return idTipoNovedad;
	}

	public void setIdTipoNovedad(Long idTipoNovedad) {
		this.idTipoNovedad = idTipoNovedad;
	}

	public Long getIdEmisor() {
		return idEmisor;
	}

	public void setIdEmisor(Long idEmisor) {
		this.idEmisor = idEmisor;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}

	public Long getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(Long idCliente) {
		this.idCliente = idCliente;
	}

	public Long getIdCuenta() {
		return idCuenta;
	}

	public void setIdCuenta(Long idCuenta) {
		this.idCuenta = idCuenta;
	}

	public Long getIdTransaccion() {
		return idTransaccion;
	}

	public void setIdTransaccion(Long idTransaccion) {
		this.idTransaccion = idTransaccion;
	}

	public String getCodigoCausalOrigen() {
		return codigoCausalOrigen;
	}

	public void setCodigoCausalOrigen(String codigoCausalOrigen) {
		this.codigoCausalOrigen = codigoCausalOrigen;
	}

	public String getCodigoCausalProceso() {
		return codigoCausalProceso;
	}

	public void setCodigoCausalProceso(String codigoCausalProceso) {
		this.codigoCausalProceso = codigoCausalProceso;
	}

	public Long getIdUsuarioEmisor() {
		return idUsuarioEmisor;
	}

	public void setIdUsuarioEmisor(Long idUsuarioEmisor) {
		this.idUsuarioEmisor = idUsuarioEmisor;
	}

	public String getHash() {
		return hash;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

}