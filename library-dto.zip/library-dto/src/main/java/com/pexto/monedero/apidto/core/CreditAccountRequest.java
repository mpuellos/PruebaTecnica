package com.pexto.monedero.apidto.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Value;

@Value
@Builder(toBuilder = true)
@AllArgsConstructor
public class CreditAccountRequest {
  String accountNumber;
  Double amount;
  String transactionType;
  String transactionDate;
  Long walletId;
  String walletCode;
  String localIp;
  String originIp;
  String origin;
  String transactionInfo;
  String userAgent;
  String checksum;

}
