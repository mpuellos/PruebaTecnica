package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class ComercioV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	protected Long idComercio;
	protected String uuidComercio;
	protected String hash;
	protected String token;
	protected String nombreComercio;
	protected Date fecha;
	protected String estado;
	
	public ComercioV() {
		
	}

	public Long getIdComercio() {
		return idComercio;
	}

	public String getUuidComercio() {
		return uuidComercio;
	}

	public String getHash() {
		return hash;
	}

	public String getToken() {
		return token;
	}

	public String getNombreComercio() {
		return nombreComercio;
	}

	public Date getFecha() {
		return fecha;
	}

	public String getEstado() {
		return estado;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public void setUuidComercio(String uuidComercio) {
		this.uuidComercio = uuidComercio;
	}

	public void setHash(String hash) {
		this.hash = hash;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public void setNombreComercio(String nombreComercio) {
		this.nombreComercio = nombreComercio;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
}
