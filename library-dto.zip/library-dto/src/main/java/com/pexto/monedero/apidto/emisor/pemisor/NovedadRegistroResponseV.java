package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;
import java.util.Date;

public class NovedadRegistroResponseV implements Serializable { 	
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private String ipOrigen;
	private Date fechaRegistro;
	private Date fechaProceso;
	private String tipoDocumento;
	private String numeroDocumento;
	private String nombre1;
	private String nombre2;
	private String apellido1;
	private String apellido2;
	private Date fechaNacimiento;
	private Date fechaNacimientoEmisor;
	private Date fechaExpedicion;
	private String fechaExpedicionApp;
	private Date fechaExpedicionEmisor;
	private String correo;
	private String correoApp;
	private String correoEmisor;
	private String numeroCelular;
	private String numeroCelularApp;
	private String numeroCelularEmisor;
	private String numeroTelefonoEmisor;
	private String numeroCelularHash;
	private String numeroCelularEncode;
	private String estado;
	private String motivo;
	private String numeroOtp;
	private String appCodeVersion;
	private String apiCodeVersion;
	private String lastEventCode;
	private String lastEventMessage;
	private String newUtilEnrollmentUUID;
	private Date vigenciaOtp;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getIpOrigen() {
		return ipOrigen;
	}

	public void setIpOrigen(String ipOrigen) {
		this.ipOrigen = ipOrigen;
	}

	public Date getFechaRegistro() {
		return fechaRegistro;
	}

	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}

	public Date getFechaProceso() {
		return fechaProceso;
	}

	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}

	public String getTipoDocumento() {
		return tipoDocumento;
	}

	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}

	public String getNumeroDocumento() {
		return numeroDocumento;
	}

	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}

	public String getNombre1() {
		return nombre1;
	}

	public void setNombre1(String nombre1) {
		this.nombre1 = nombre1;
	}

	public String getNombre2() {
		return nombre2;
	}

	public void setNombre2(String nombre2) {
		this.nombre2 = nombre2;
	}

	public String getApellido1() {
		return apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}

	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}

	public Date getFechaExpedicion() {
		return fechaExpedicion;
	}

	public void setFechaExpedicion(Date fechaExpedicion) {
		this.fechaExpedicion = fechaExpedicion;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getNumeroCelular() {
		return numeroCelular;
	}

	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	public String getNumeroCelularHash() {
		return numeroCelularHash;
	}

	public void setNumeroCelularHash(String numeroCelularHash) {
		this.numeroCelularHash = numeroCelularHash;
	}

	public String getNumeroCelularEncode() {
		return numeroCelularEncode;
	}

	public void setNumeroCelularEncode(String numeroCelularEncode) {
		this.numeroCelularEncode = numeroCelularEncode;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public String getMotivo() {
		return motivo;
	}

	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}

	public String getNumeroOtp() {
		return numeroOtp;
	}

	public void setNumeroOtp(String numeroOtp) {
		this.numeroOtp = numeroOtp;
	}

	public Date getVigenciaOtp() {
		return vigenciaOtp;
	}

	public void setVigenciaOtp(Date vigenciaOtp) {
		this.vigenciaOtp = vigenciaOtp;
	}

	public Date getFechaNacimientoEmisor() {
		return fechaNacimientoEmisor;
	}

	public void setFechaNacimientoEmisor(Date fechaNacimientoEmisor) {
		this.fechaNacimientoEmisor = fechaNacimientoEmisor;
	}

	public Date getFechaExpedicionEmisor() {
		return fechaExpedicionEmisor;
	}

	public void setFechaExpedicionEmisor(Date fechaExpedicionEmisor) {
		this.fechaExpedicionEmisor = fechaExpedicionEmisor;
	}

	public String getCorreoApp() {
		return correoApp;
	}

	public void setCorreoApp(String correoApp) {
		this.correoApp = correoApp;
	}

	public String getCorreoEmisor() {
		return correoEmisor;
	}

	public void setCorreoEmisor(String correoEmisor) {
		this.correoEmisor = correoEmisor;
	}

	public String getNumeroCelularApp() {
		return numeroCelularApp;
	}

	public void setNumeroCelularApp(String numeroCelularApp) {
		this.numeroCelularApp = numeroCelularApp;
	}

	public String getNumeroCelularEmisor() {
		return numeroCelularEmisor;
	}

	public void setNumeroCelularEmisor(String numeroCelularEmisor) {
		this.numeroCelularEmisor = numeroCelularEmisor;
	}

	public String getNumeroTelefonoEmisor() {
		return numeroTelefonoEmisor;
	}

	public void setNumeroTelefonoEmisor(String numeroTelefonoEmisor) {
		this.numeroTelefonoEmisor = numeroTelefonoEmisor;
	}

	public String getAppCodeVersion() {
		return appCodeVersion;
	}

	public void setAppCodeVersion(String appCodeVersion) {
		this.appCodeVersion = appCodeVersion;
	}

	public String getApiCodeVersion() {
		return apiCodeVersion;
	}

	public void setApiCodeVersion(String apiCodeVersion) {
		this.apiCodeVersion = apiCodeVersion;
	}

	public String getFechaExpedicionApp() {
		return fechaExpedicionApp;
	}

	public void setFechaExpedicionApp(String fechaExpedicionApp) {
		this.fechaExpedicionApp = fechaExpedicionApp;
	}

	public String getLastEventCode() {
		return lastEventCode;
	}

	public void setLastEventCode(String lastEventCode) {
		this.lastEventCode = lastEventCode;
	}

	public String getLastEventMessage() {
		return lastEventMessage;
	}

	public void setLastEventMessage(String lastEventMessage) {
		this.lastEventMessage = lastEventMessage;
	}

	public String getNewUtilEnrollmentUUID() {
		return newUtilEnrollmentUUID;
	}

	public void setNewUtilEnrollmentUUID(String newUtilEnrollmentUUID) {
		this.newUtilEnrollmentUUID = newUtilEnrollmentUUID;
	}

}
