package com.pexto.monedero.apidto.enterprises;

import com.pexto.monedero.apidto.enterprises.options.TypeMethodOfPay;
import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@Builder(toBuilder = true)
@ToString
public class EnterpriseUnitPayment {

    TypeMethodOfPay typeMethodOfPay;
    EnterpriseUnitPayment.Client client;
    EnterpriseUnitPayment.Bank bank;
    String value;

    public EnterpriseUnitPayment() {
        this.bank = new EnterpriseUnitPayment.Bank();
    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder(toBuilder = true)
    @ToString
    public static class Client {

        String typeDocument;
        String numberDocument;
        String email;

    }

    @Getter
    @Setter
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder(toBuilder = true)
    @ToString
    public static class Bank {

        String bankId;
        String accountTypeId;
        String bankCode;
        String accountTypeCode;
        String accountNumber;

    }

}
