package com.pexto.monedero.apidto.enterprises.options;

import lombok.Getter;

@Getter
public enum TypeMethodOfPay {

    COBRE_DEFAULT,
    BANK_ACCOUNT;

}
