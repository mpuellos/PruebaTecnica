package com.pexto.monedero.apidto.comercio.insurance;

import lombok.Builder;
import lombok.Value;

@Value
@Builder
public class CreateInsuranceRequest {

  String workplaceBankCode;
  String insuranceTypeName;
  String insurancePlan;
  String insurancePaymentMode;
  String startInsuranceDate;
  Integer insuranceValue;
  String insuredDocumentType;
  String insuredDocumentNumber;
  String insuredFirstName;
  String insuredLastName;
  String insuredSurname1;
  String insuredSurname2;
  String insuredGender;
  String insuredBirthDate;
  String insuredEmail;
  String insuredCellphone;
  String insuredCity;
  String insuredAddress;
  Boolean isPersonalDataAuthorization;
  Boolean isEmailAuthorization;
  Boolean isSmsAuthorization;
  String workplaceBankAuthorizationNumber;
  String cobreAuthorizationNumber;

}
