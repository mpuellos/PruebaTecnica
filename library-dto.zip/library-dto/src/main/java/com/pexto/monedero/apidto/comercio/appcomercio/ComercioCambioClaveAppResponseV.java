package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.pexto.monedero.apidto.negocio.UsuarioComercioDTO;

public class ComercioCambioClaveAppResponseV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("logon")
	private String logon;
	
	@JsonProperty("usuarioComercio")
	private UsuarioComercioDTO usuarioComercio;

	public String getLogon() {
		return logon;
	}

	public void setLogon(String logon) {
		this.logon = logon;
	}

	public UsuarioComercioDTO getUsuarioComercio() {
		return usuarioComercio;
	}

	public void setUsuarioComercio(UsuarioComercioDTO usuarioComercio) {
		this.usuarioComercio = usuarioComercio;
	}
	
}
