package com.pexto.monedero.apidto.emisor.pemisor.afiliado;

import java.io.Serializable;
import com.pexto.monedero.apidto.negocio.IRequestValidator;
import com.pexto.monedero.apidto.utils.Parametros;

public class CrearCuentaBolsilloRequest implements Serializable, IRequestValidator {

    /**
    *
    */
    private static final long serialVersionUID = 739401004899477628L;

    
    private String clientDocumentId;
    private String clientDocumentType;
    private String workplaceBankCode;
    private String walletType;

    @Override
    public boolean validateProperties() throws Exception {
        if(clientDocumentType == null){
            clientDocumentType="0";
        }
		if ((clientDocumentType == null) || (clientDocumentType.trim().length() == 0)) {
			throw new Exception ("El campo Tipo Documento esta vacio o errado!");
		}

		if ((clientDocumentId == null) || (clientDocumentId.trim().length() == 0)) {
			throw new Exception ("El campo Numero Documento esta vacio o errado!");
		}
		
		if ((workplaceBankCode == null) || (workplaceBankCode.trim().length() == 0)) {
			throw new Exception ("El campo Workplace Bank Code esta vacio o errado!");
		}
		
		if ((walletType == null) || (walletType.trim().length() == 0)) {
			throw new Exception ("El campo Wallet Type esta vacio!");
		}

        if(!walletType.equals(Parametros.PRESTAMOS_WALLET_TYPE_PRIMARY) && !walletType.equals(Parametros.PRESTAMOS_WALLET_TYPE_LOAN)){
			throw new Exception ("Campo Wallet Type no permitido!");
        }
        return false;
    }

    public String getClientDocumentId() {
        return clientDocumentId;
    }

    public void setClientDocumentId(String clientDocumentId) {
        this.clientDocumentId = clientDocumentId;
    }

    public String getWorkplaceBankCode() {
        return workplaceBankCode;
    }

    public void setWorkplaceBankCode(String workplaceBankCode) {
        this.workplaceBankCode = workplaceBankCode;
    }

    public String getWalletType() {
        return walletType;
    }

    public void setWalletType(String walletType) {
        this.walletType = walletType;
    }

    public String getClientDocumentType() {
        return clientDocumentType;
    }

    public void setClientDocumentType(String clientDocumentType) {
        this.clientDocumentType = clientDocumentType;
    }
    
}
