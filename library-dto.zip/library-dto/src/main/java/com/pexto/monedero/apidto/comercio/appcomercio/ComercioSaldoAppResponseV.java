package com.pexto.monedero.apidto.comercio.appcomercio;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ComercioSaldoAppResponseV implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("idBolsillo")
	private Long idBolsillo;
	
	@JsonProperty("saldoCuenta")
	private double saldoCuenta;
	
	public ComercioSaldoAppResponseV() {
	}
	
	public ComercioSaldoAppResponseV(Long idBolsillo, double saldoCuenta) {
		super();
		
		this.idBolsillo = idBolsillo;
		this.saldoCuenta = saldoCuenta;
	}

	public double getSaldoCuenta() {
		return saldoCuenta;
	}

	public void setSaldoCuenta(double saldoCuenta) {
		this.saldoCuenta = saldoCuenta;
	}

	public Long getIdBolsillo() {
		return idBolsillo;
	}

	public void setIdBolsillo(Long idBolsillo) {
		this.idBolsillo = idBolsillo;
	}
		
}
