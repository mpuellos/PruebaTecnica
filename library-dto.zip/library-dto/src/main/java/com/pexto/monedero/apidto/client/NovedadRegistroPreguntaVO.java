package com.pexto.monedero.apidto.client;

import java.io.Serializable;
import java.util.Date;

public class NovedadRegistroPreguntaVO implements Serializable { 	
	
	private static final long serialVersionUID = 1L;
	
	private Long id;
	private String uuid;
	private Date fechaRegistro;
	private Date fechaProceso;
	private String tipoDocumento;
	private String numeroDocumento;
	private String pregunta1;
	private String pregunta2;
	private String pregunta3;
	private String pregunta4;
	private String pregunta5;
	private String pregunta6;
	private String respuesta1;
	private String respuesta2;
	private String respuesta3;
	private String respuesta4;
	private String respuesta5;
	private String respuesta6;
	private String validacion;
	private String estado;
	private Date vigencia;
	private Long idNovedadRegistro;
	
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}
	
	public String getUuid() {
		return uuid;
	}
	
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	
	public Date getFechaRegistro() {
		return fechaRegistro;
	}
	
	public void setFechaRegistro(Date fechaRegistro) {
		this.fechaRegistro = fechaRegistro;
	}
	
	public Date getFechaProceso() {
		return fechaProceso;
	}
	
	public void setFechaProceso(Date fechaProceso) {
		this.fechaProceso = fechaProceso;
	}
	
	public String getTipoDocumento() {
		return tipoDocumento;
	}
	
	public void setTipoDocumento(String tipoDocumento) {
		this.tipoDocumento = tipoDocumento;
	}
	
	public String getNumeroDocumento() {
		return numeroDocumento;
	}
	
	public void setNumeroDocumento(String numeroDocumento) {
		this.numeroDocumento = numeroDocumento;
	}
	
	public String getPregunta1() {
		return pregunta1;
	}
	
	public void setPregunta1(String pregunta1) {
		this.pregunta1 = pregunta1;
	}
	
	public String getPregunta2() {
		return pregunta2;
	}
	
	public void setPregunta2(String pregunta2) {
		this.pregunta2 = pregunta2;
	}
	
	public String getPregunta3() {
		return pregunta3;
	}
	
	public void setPregunta3(String pregunta3) {
		this.pregunta3 = pregunta3;
	}
	
	public String getPregunta4() {
		return pregunta4;
	}
	
	public void setPregunta4(String pregunta4) {
		this.pregunta4 = pregunta4;
	}
	
	public String getPregunta5() {
		return pregunta5;
	}
	
	public void setPregunta5(String pregunta5) {
		this.pregunta5 = pregunta5;
	}
	
	public String getPregunta6() {
		return pregunta6;
	}
	
	public void setPregunta6(String pregunta6) {
		this.pregunta6 = pregunta6;
	}
	
	public String getRespuesta1() {
		return respuesta1;
	}
	
	public void setRespuesta1(String respuesta1) {
		this.respuesta1 = respuesta1;
	}
	
	public String getRespuesta2() {
		return respuesta2;
	}
	
	public void setRespuesta2(String respuesta2) {
		this.respuesta2 = respuesta2;
	}
	
	public String getRespuesta3() {
		return respuesta3;
	}
	
	public void setRespuesta3(String respuesta3) {
		this.respuesta3 = respuesta3;
	}
	
	public String getRespuesta4() {
		return respuesta4;
	}
	
	public void setRespuesta4(String respuesta4) {
		this.respuesta4 = respuesta4;
	}
	
	public String getRespuesta5() {
		return respuesta5;
	}
	
	public void setRespuesta5(String respuesta5) {
		this.respuesta5 = respuesta5;
	}
	
	public String getRespuesta6() {
		return respuesta6;
	}
	
	public void setRespuesta6(String respuesta6) {
		this.respuesta6 = respuesta6;
	}
	
	public String getValidacion() {
		return validacion;
	}
	
	public void setValidacion(String validacion) {
		this.validacion = validacion;
	}
	
	public String getEstado() {
		return estado;
	}
	
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	public Date getVigencia() {
		return vigencia;
	}
	
	public void setVigencia(Date vigencia) {
		this.vigencia = vigencia;
	}
	
	public Long getIdNovedadRegistro() {
		return idNovedadRegistro;
	}
	
	public void setIdNovedadRegistro(Long idNovedadRegistro) {
		this.idNovedadRegistro = idNovedadRegistro;
	}
	
}
