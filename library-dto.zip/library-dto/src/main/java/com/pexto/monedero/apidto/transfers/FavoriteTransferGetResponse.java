package com.pexto.monedero.apidto.transfers;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FavoriteTransferGetResponse {

    Long id;
    FavoriteTransferGetResponse.Bank bank;
    FavoriteTransferGetResponse.AccountType accountType;
    FavoriteTransferGetResponse.Beneficiary beneficiary;
    FavoriteTransferGetResponse.Account account;
    String favoriteTransferType;

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Bank {
        String id;
        String name;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class AccountType {
        String id;
        String name;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Beneficiary {
        String typeId;
        String numberId;
        String name;
    }

    @Data
    @AllArgsConstructor
    @NoArgsConstructor
    @Builder
    public static class Account {
        String name;
        String number;
    }

}
