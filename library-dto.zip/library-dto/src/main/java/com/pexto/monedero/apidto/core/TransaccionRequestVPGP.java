package com.pexto.monedero.apidto.core;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class TransaccionRequestVPGP implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@JsonProperty("objeto")
	private String objeto;
	
	@JsonProperty("mensaje")
	private String mensaje;
	
	@JsonProperty("id")
	private String id;
	
	public String getObjeto() {
		return objeto;
	}
	
	public void setObjeto(String objeto) {
		this.objeto = objeto;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("TransaccionRequestVPGP [objeto=");
		builder.append(objeto);
		builder.append(", mensaje=");
		builder.append(mensaje);
		builder.append(", id=");
		builder.append(id);
		builder.append("]");
		return builder.toString();
	}
	
	
	
}
