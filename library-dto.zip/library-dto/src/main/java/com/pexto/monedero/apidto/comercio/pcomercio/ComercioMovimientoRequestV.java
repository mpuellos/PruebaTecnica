package com.pexto.monedero.apidto.comercio.pcomercio;

import java.io.Serializable;
import java.util.Date;

public class ComercioMovimientoRequestV implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long idComercio;
	private String uuidComercio;
	private Date fechaInicio;
	private Date fechaFinal;
	private boolean download;

	private String formatoReporte;
	private String fechaInicioStr;
	private String fechaFinalStr;

	public Long getIdComercio() {
		return idComercio;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public Date getFechaFinal() {
		return fechaFinal;
	}

	public void setIdComercio(Long idComercio) {
		this.idComercio = idComercio;
	}

	public String getUuidComercio() {
		return uuidComercio;
	}

	public void setUuidComercio(String uuidComercio) {
		this.uuidComercio = uuidComercio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public void setFechaFinal(Date fechaFinal) {
		this.fechaFinal = fechaFinal;
	}

	public boolean isDownload() {
		return download;
	}

	public void setDownload(boolean download) {
		this.download = download;
	}

	public String getFechaInicioStr() {
		return fechaInicioStr;
	}

	public void setFechaInicioStr(String fechaInicioStr) {
		this.fechaInicioStr = fechaInicioStr;
	}

	public String getFechaFinalStr() {
		return fechaFinalStr;
	}

	public void setFechaFinalStr(String fechafinalStr) {
		this.fechaFinalStr = fechafinalStr;
	}

	public String getFormatoReporte() {
		return formatoReporte;
	}

	public void setFormatoReporte(String formatoReporte) {
		this.formatoReporte = formatoReporte;
	}

	public boolean validatePropertiesId() throws Exception {
		if (idComercio == null) {
			throw new Exception("IdComercio is null");
		}

		if (fechaInicio == null) {
			throw new Exception("Fecha de Inicio is null");
		}

		if (fechaFinal == null) {
			throw new Exception("Fecha Final is null");
		}

		if (String.valueOf(idComercio).equals("")) {
			throw new Exception("IdComercio esta vacio!");
		}

		if (idComercio <= 0) {
			throw new Exception("IdComercio valor errado!");
		}

		return true;
	}

	public boolean validatePropertiesUUID() throws Exception {

		if (uuidComercio == null) {
			throw new Exception("UUIDComercio is null");
		}

		if (fechaInicio == null) {
			throw new Exception("Fecha de Inicio is null");
		}

		if (fechaFinal == null) {
			throw new Exception("Fecha Final is null");
		}

		if (fechaInicioStr == null) {
			throw new Exception("Fecha de Inicio is null");
		}

		if (fechaFinalStr == null) {
			throw new Exception("Fecha Final is null");
		}

		return true;
	}

}
