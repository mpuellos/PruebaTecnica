package com.pexto.monedero.apidto.route53;

public class SubDomainCustom {
    private String name;
    private String type;
    private String nameSub;
    private Long ttl;
    private String mainRegistry;
    private String aliasTargetName;
    private String aliasTargetId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNameSub() {
        return nameSub;
    }

    public void setNameSub(String nameSub) {
        this.nameSub = nameSub;
    }

    public Long getTtl() {
        return ttl;
    }

    public void setTtl(Long ttl) {
        this.ttl = ttl;
    }

    public String getMainRegistry() {
        return mainRegistry;
    }

    public void setMainRegistry(String mainRegistry) {
        this.mainRegistry = mainRegistry;
    }

    public String getAliasTargetName() {
        return aliasTargetName;
    }

    public void setAliasTargetName(String aliasTargetName) {
        this.aliasTargetName = aliasTargetName;
    }

    public String getAliasTargetId() {
        return aliasTargetId;
    }

    public void setAliasTargetId(String aliasTargetId) {
        this.aliasTargetId = aliasTargetId;
    }

}
