package com.pexto.monedero.apidto.enrollment;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ValidateEnrollmentOtpRequest {
    public String otp;
}
