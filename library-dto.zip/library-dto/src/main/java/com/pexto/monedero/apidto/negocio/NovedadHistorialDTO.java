package com.pexto.monedero.apidto.negocio;

import java.io.Serializable;
import java.util.Date;

public class NovedadHistorialDTO implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long id;
	private String bolsillo;
	private int cantidadRegistro;
	private double valorTotal;
	private Date fechaSolicitud;
	private String solicitante;
	private String aprobador;
	private Date fechaAprobacion;

	private NovedadHistorialDTO() {

	}

	public NovedadHistorialDTO(Long id, String bolsillo, int cantidadRegistros, double valorTotal, Date fecha,
			Date fechaAprobacion, String solicitante, String aprobador) {
		super();
		this.id = id;
		this.bolsillo = bolsillo;
		this.cantidadRegistro = cantidadRegistros;
		this.valorTotal = valorTotal;
		this.fechaSolicitud = fecha;
		this.solicitante = solicitante;
		this.aprobador = aprobador;
		this.fechaAprobacion = fechaAprobacion;

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBolsillo() {
		return bolsillo;
	}

	public void setBolsillo(String bolsillo) {
		this.bolsillo = bolsillo;
	}

	public int getCantidadRegistro() {
		return cantidadRegistro;
	}

	public void setCantidadRegistro(int cantidadRegistro) {
		this.cantidadRegistro = cantidadRegistro;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

	public Date getFechaSolicitud() {
		return fechaSolicitud;
	}

	public void setFechaSolicitud(Date fechaSolicitud) {
		this.fechaSolicitud = fechaSolicitud;
	}

	public String getSolicitante() {
		return solicitante;
	}

	public void setSolicitante(String solicitante) {
		this.solicitante = solicitante;
	}

	public String getAprobador() {
		return aprobador;
	}

	public void setAprobador(String aprobador) {
		this.aprobador = aprobador;
	}

	public Date getFechaAprobacion() {
		return fechaAprobacion;
	}

	public void setFechaAprobacion(Date fechaAprobacion) {
		this.fechaAprobacion = fechaAprobacion;
	}

}
