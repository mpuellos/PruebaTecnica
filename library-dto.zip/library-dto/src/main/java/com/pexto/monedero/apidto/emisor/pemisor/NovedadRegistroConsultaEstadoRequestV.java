package com.pexto.monedero.apidto.emisor.pemisor;

import java.io.Serializable;

import com.pexto.monedero.apidto.negocio.IRequestValidator;

public class NovedadRegistroConsultaEstadoRequestV implements Serializable, IRequestValidator { 	
	
	private static final long serialVersionUID = 1L;
	
	private String idEmisor;
	private String estado;
	private String fechaInicio;
	private String fechaFinal;
	
	public String getIdEmisor() {
		return idEmisor;
	}
	
	public void setIdEmisor(String idEmisor) {
		this.idEmisor = idEmisor;
	}
	
	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	
	public String getFechaFinal() {
		return fechaFinal;
	}
	
	public void setFechaFinal(String fechaFinal) {
		this.fechaFinal = fechaFinal;
	}
	
	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Override
	public boolean validateProperties() throws Exception {
		boolean valid = true;
		
		if ((fechaInicio == null) || (fechaInicio.trim().length() == 0) || (fechaInicio.length() != 10)) {
			throw new Exception ("El campo Fecha Inicio esta vacio o errado!");
		}
		
		if ((fechaFinal == null) || (fechaFinal.trim().length() == 0) || (fechaFinal.length() != 10)) {
			throw new Exception ("El campo Fecha Final esta vacio o errado!");
		}
		
		return valid;
	}	
}