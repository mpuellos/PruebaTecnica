package com.pexto.monedero.apidto.integrador.olimpica;

import java.io.Serializable;

public class ResponseSaldos implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private Long saldoDisponible;
	private Long saldoExtracupo;
	private Long cupoAsignado;
	
	public Long getSaldoDisponible() {
		return saldoDisponible;
	}
	
	public void setSaldoDisponible(Long saldoDisponible) {
		this.saldoDisponible = saldoDisponible;
	}
	
	public Long getSaldoExtracupo() {
		return saldoExtracupo;
	}
	
	public void setSaldoExtracupo(Long saldoExtracupo) {
		this.saldoExtracupo = saldoExtracupo;
	}
	
	public Long getCupoAsignado() {
		return cupoAsignado;
	}
	
	public void setCupoAsignado(Long cupoAsignado) {
		this.cupoAsignado = cupoAsignado;
	}
	
}
