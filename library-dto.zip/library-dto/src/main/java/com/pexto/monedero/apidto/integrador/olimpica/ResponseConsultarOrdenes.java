package com.pexto.monedero.apidto.integrador.olimpica;

import java.io.Serializable;

public class ResponseConsultarOrdenes implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String aufecharea;
	private String auhorareal;
	private String aucodiauto;
	private String audoccli;
	private String autrnoap;
	private Long autransa;
	private Long aucredcli;
	private Long aunumtar;
	
	public String getAufecharea() {
		return aufecharea;
	}
	public void setAufecharea(String aufecharea) {
		this.aufecharea = aufecharea;
	}
	public String getAuhorareal() {
		return auhorareal;
	}
	public void setAuhorareal(String auhorareal) {
		this.auhorareal = auhorareal;
	}
	public String getAucodiauto() {
		return aucodiauto;
	}
	public void setAucodiauto(String aucodiauto) {
		this.aucodiauto = aucodiauto;
	}
	public String getAudoccli() {
		return audoccli;
	}
	public void setAudoccli(String audoccli) {
		this.audoccli = audoccli;
	}
	public String getAutrnoap() {
		return autrnoap;
	}
	public void setAutrnoap(String autrnoap) {
		this.autrnoap = autrnoap;
	}
	public Long getAutransa() {
		return autransa;
	}
	public void setAutransa(Long autransa) {
		this.autransa = autransa;
	}
	public Long getAucredcli() {
		return aucredcli;
	}
	public void setAucredcli(Long aucredcli) {
		this.aucredcli = aucredcli;
	}
	public Long getAunumtar() {
		return aunumtar;
	}
	public void setAunumtar(Long aunumtar) {
		this.aunumtar = aunumtar;
	}
	
	
}
