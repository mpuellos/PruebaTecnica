package com.pexto.monedero.apidto.utils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.UUID;

import javax.crypto.SecretKey;

import org.apache.commons.lang.time.DateUtils;
import org.json.JSONException;
import org.json.JSONObject;

import com.pexto.monedero.apidto.negocio.ClienteDTO;
import com.pexto.monedero.apidto.negocio.CuentaDTO;
import com.pexto.monedero.apidto.negocio.EmisorDTO;
import com.pexto.monedero.apidto.negocio.UsuarioJWTDTO;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

public class Hasher {

    // TODO: Get this apps codes from JPA
    static HashMap<String, String> secureApps = new HashMap<String, String>();
    static String keyToken = "Y28uY29icmUuYmlsbGV0ZXJhLnJhbmQuN1RhUno5MEVMUw=="; // co.cobre.billetera.rand.7TaRz90ELS
    static {
        secureApps.put("52738914", "p8QridNTG65q28X");
    }

    public static String hashWith256(String textToHash) {
        MessageDigest digest;
        String encoded = "";
        try {
            digest = MessageDigest.getInstance("SHA-256");
            byte[] byteOfTextToHash = textToHash.getBytes(StandardCharsets.UTF_8);
            byte[] hashedByetArray = digest.digest(byteOfTextToHash);
            encoded = Base64.getEncoder().encodeToString(hashedByetArray);
        } catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return encoded;
    }

    public static UsuarioJWTDTO getUserRequest(String jwsString) throws JSONException {
        String json = "";
        try {
            json = validAuthRequest(jwsString, false, true);
        } catch (Exception e) {
        }
        UsuarioJWTDTO user = null;
        if(!json.equals("") && json.startsWith("{")){
            JSONObject objectDecode = new JSONObject(json);
            user = new UsuarioJWTDTO(objectDecode.getString("token"), objectDecode.getString("cuenta"), objectDecode.getString("cuentaUUID"), objectDecode.getLong("clienteId"), objectDecode.getString("clienteDocumento"), objectDecode.getString("clienteCorreo"), objectDecode.getString("clienteCelular"), objectDecode.getString("clienteNombreCompleto"));
        }
        return user;
    }
    public static String validAuthRequest(String jwsString, boolean throwEx, boolean getJSON) throws Exception {
        Jws<Claims> jws;
        SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(keyToken));

        try {
            jws = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jwsString);
            Date current = new Date();
            if (jws.getBody().getExpiration().before(current)) {
                throw new Exception("Expired token");
            }
            if(jws.getBody().getSubject().startsWith("JWT-TOKEN-INIT-")){
                jws = Jwts.parserBuilder().setSigningKey(key).build().parseClaimsJws(jws.getBody().getSubject().replace("JWT-TOKEN-INIT-", ""));
                if (jws.getBody().getExpiration().before(current)) {
                    throw new Exception("Expired token");
                }
            }
            String subject = jws.getBody().getSubject();
            if(!getJSON && subject.startsWith("{")){
                JSONObject objectDecode = new JSONObject(jws.getBody().getSubject());
                subject = objectDecode.getString("token");
            }
            return subject;
        } catch (Exception ex) {
            if (throwEx) {
                throw new Exception("Unauthenticated");
            }
            return "";
        }
    }

    public static String validAuthRequest(String jwsString, boolean throwEx) throws Exception {
        return validAuthRequest(jwsString, throwEx, false);
    }

    public static String validAuthRequest(String jwsString) throws Exception {
        return validAuthRequest(jwsString, false, false);
    }

    public static String genJWT(String tokenAuth, String accountNumber) {
        Date current = new Date();
        SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(keyToken));
        return Jwts.builder().setIssuer("co.cobre.billetera").setSubject(tokenAuth).signWith(key)
        .setExpiration(DateUtils.addMinutes(current, 20)).setIssuedAt(current)
        .setId(UUID.randomUUID().toString()).compact();
    }

    public static String genJWTUser(String tokenAuth, CuentaDTO account, ClienteDTO client, EmisorDTO emisor) throws JSONException {
        Date current = new Date();
        JSONObject objectEncode = new JSONObject();
        objectEncode.put("token", tokenAuth);
        objectEncode.put("cuenta", account.getNumeroCuenta());
        objectEncode.put("cuentaUUID", account.getUuid());
        objectEncode.put("clienteId", client.getId());
        objectEncode.put("clienteDocumento", client.getNumeroDocumento());
        objectEncode.put("clienteCorreo", client.getCorreo());
        objectEncode.put("clienteCelular", client.getCelular());
        objectEncode.put("clienteNombreCompleto", String.format("%s %s", client.getNombres(), client.getApellidos()));
        if(emisor!=null){
            objectEncode.put("workplacebankName", emisor.getNombre());
            objectEncode.put("workplacebankCode", emisor.getNombreCorto());
        }
        SecretKey key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(keyToken));
        return Jwts.builder().setIssuer("co.cobre.billetera").setSubject(objectEncode.toString()).signWith(key)
        .setExpiration(DateUtils.addMinutes(current, 20)).setIssuedAt(current)
        .setId(UUID.randomUUID().toString()).compact();
    }

    public static boolean validPublicRequest(String authorization, String app_code) throws Exception {

        if (secureApps.get(app_code) != null) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd~HH");
            String dateString = format.format(new Date());
            String hash = Hasher.hashWith256(String.format("%s~%s", dateString, secureApps.get(app_code)));
            System.out.println("validPublicRequest - HASH: " + hash);
            System.out.println("validPublicRequest - RETRIVED: " + authorization);
            if (!hash.equals(authorization)) {
                throw new Exception("Unauthenticated");
            }
        } else {
            throw new Exception("App not found");
        }
        return true;
    }
}
