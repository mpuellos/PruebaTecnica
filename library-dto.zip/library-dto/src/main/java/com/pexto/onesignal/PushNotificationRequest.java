package com.pexto.onesignal;

import java.io.Serializable;

public class PushNotificationRequest implements Serializable {

	private static final long serialVersionUID = 1L;

	private String userId;
	private String message;
	private String segments;
	
	public String getUserId() {
		return userId;
	}
	
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public String getMessage() {
		return message;
	}
	
	public void setMessage(String message) {
		this.message = message;
	}
	
	public String getSegments() {
		return segments;
	}

	public void setSegments(String segments) {
		this.segments = segments;
	}
}