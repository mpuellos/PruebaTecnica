# Library-DTO

Libreria utilizada por las capas Core y API. No tiene deploy separado; en vez, se compila y el artifacto se guarda en AWS CodeArtifact para utilizar como dependecia en otros repositorios.
